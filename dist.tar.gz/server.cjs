var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_dotenv = __toESM(require("dotenv"), 1);
var import_express = __toESM(require("express"), 1);
var import_bcryptjs = __toESM(require("bcryptjs"), 1);
var import_punycode = __toESM(require("punycode"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_multer = __toESM(require("multer"), 1);
var import_app = require("firebase/app");
var import_firestore = require("firebase/firestore");
var import_storage = require("firebase/storage");
var import_async_hooks = require("async_hooks");
import_dotenv.default.config();
var fs = import_fs.default.promises;
function getGoogleGenAI(opts) {
  try {
    const { GoogleGenAI } = require("@google/genai");
    return new GoogleGenAI(opts);
  } catch (e) {
    console.error("GoogleGenAI require error:", e);
    throw new Error("AI features unavailable on this Node version");
  }
}
function getSharp(input) {
  try {
    const s = require("sharp");
    return input ? s(input) : s;
  } catch (e) {
    return null;
  }
}
var ffmpeg = null;
try {
  const ffmpegInstaller = require("@ffmpeg-installer/ffmpeg");
  ffmpeg = require("fluent-ffmpeg");
  if (ffmpegInstaller && ffmpegInstaller.path) {
    ffmpeg.setFfmpegPath(ffmpegInstaller.path);
  }
} catch (e) {
}
var r2AccountId = process.env.CF_R2_ACCOUNT_ID || "ed5771d045bec5ae12373a1dc5bb6985";
var r2AccessKeyId = process.env.CF_R2_ACCESS_KEY_ID || "8ae592287e83828ec9c5b5aa468500e6";
var r2SecretAccessKey = process.env.CF_R2_SECRET_ACCESS_KEY || "d964617b9dd773a720b026987823fa43c6d358dd29d44bf36aeb7ef3c8cb9c59";
var r2BucketName = process.env.CF_R2_BUCKET_NAME || "bbb-bz";
var r2PublicDomain = (process.env.CF_R2_PUBLIC_DOMAIN || "https://cdn.bbb.bz").replace(/\/$/, "");
var s3Client = null;
var PutObjectCommandClass = null;
var DeleteObjectCommandClass = null;
try {
  const awsS3 = require("@aws-sdk/client-s3");
  PutObjectCommandClass = awsS3.PutObjectCommand;
  DeleteObjectCommandClass = awsS3.DeleteObjectCommand;
  if (r2AccountId && r2AccessKeyId && r2SecretAccessKey) {
    s3Client = new awsS3.S3Client({
      region: "auto",
      endpoint: `https://${r2AccountId}.r2.cloudflarestorage.com`,
      credentials: {
        accessKeyId: r2AccessKeyId,
        secretAccessKey: r2SecretAccessKey
      }
    });
    console.log("\u2705 [Cloudflare R2] Client initialized successfully for bucket:", r2BucketName);
  }
} catch (e) {
  console.log("\u26A0\uFE0F [Cloudflare R2] @aws-sdk/client-s3 is not installed or available on this environment. Falling back to local storage.");
}
async function uploadToR2(localPath, key, contentType) {
  if (!s3Client || !PutObjectCommandClass) throw new Error("Cloudflare R2 Client is not configured");
  const fileBuffer = await fs.readFile(localPath);
  const command = new PutObjectCommandClass({
    Bucket: r2BucketName,
    Key: key,
    Body: fileBuffer,
    ContentType: contentType
  });
  await s3Client.send(command);
  return `${r2PublicDomain}/${key}`;
}
function isBcryptHash(str) {
  return typeof str === "string" && /^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$/.test(str);
}
function verifyPassword(provided, stored) {
  if (!stored) return false;
  if (!provided) return false;
  const provStr = String(provided).trim();
  const storStr = String(stored).trim();
  if (isBcryptHash(storStr)) {
    return import_bcryptjs.default.compareSync(provStr, storStr);
  }
  return provStr === storStr;
}
var multiConfig = {};
try {
  const fileData = import_fs.default.readFileSync(import_path.default.join(process.cwd(), "firebase-multi-configs.json"), "utf-8");
  multiConfig = JSON.parse(fileData);
} catch (e) {
  let appletConfig = null;
  try {
    const appletData = import_fs.default.readFileSync(import_path.default.join(process.cwd(), "firebase-applet-config.json"), "utf-8");
    appletConfig = JSON.parse(appletData);
  } catch (err) {
  }
  if (appletConfig) {
    multiConfig = {
      activeId: "default",
      configs: [{
        id: "default",
        name: `\u0110\u01B0\u1EE3c c\u1EA5p ph\xE1t (${appletConfig.projectId})`,
        config: appletConfig
      }]
    };
  } else {
    multiConfig = {
      activeId: "default",
      configs: [{
        id: "default",
        name: "M\u1EB7c \u0111\u1ECBnh (taimusic-96289)",
        config: {
          apiKey: "AIzaSyAcml_QfgGTH80OKmRVj2tWIomEQUUiHB0",
          authDomain: "taimusic-96289.firebaseapp.com",
          projectId: "taimusic-96289",
          storageBucket: "taimusic-96289.firebasestorage.app",
          messagingSenderId: "848155741386",
          appId: "1:848155741386:web:4f5b5d826ce5fbbba8f833",
          measurementId: "G-D4ZSK50GZ2",
          firestoreDatabaseId: "default"
        }
      }]
    };
  }
}
var activeConfig = multiConfig.configs.find((c) => c.id === multiConfig.activeId) || multiConfig.configs[0];
var firebaseConfig = activeConfig.config;
var firebaseApp = (0, import_app.initializeApp)(firebaseConfig);
var db = (0, import_firestore.getFirestore)(firebaseApp, firebaseConfig.firestoreDatabaseId || "(default)");
var firebaseStorage = (0, import_storage.getStorage)(firebaseApp);
var DOC_REF = (0, import_firestore.doc)(db, "app_data", "main");
var isFirestoreDisabled = firebaseConfig.projectId === "remixed-project-id";
function handleFirebaseError(error) {
  if (!error) return;
  const errMsg = String(error.message || error).toLowerCase();
  if (errMsg.includes("permission") || errMsg.includes("insufficient") || errMsg.includes("disabled") || errMsg.includes("code: 7") || errMsg.includes("denied") || errMsg.includes("auth") || errMsg.includes("cancelled")) {
    if (!isFirestoreDisabled) {
      isFirestoreDisabled = true;
      console.warn("\u26A0\uFE0F Cloud Firestore has insufficient permissions or is unconfigured. Falling back entirely to Local JSON file storage (artists.json & data_<artist>.json).");
    }
  }
}
var artistStorage = new import_async_hooks.AsyncLocalStorage();
var ARTISTS_FILE = import_path.default.join(process.cwd(), "artists.json");
var artists = [];
var SENT_EMAILS_FILE = import_path.default.join(process.cwd(), "sent_emails.json");
var sentEmails = [];
async function loadSentEmails() {
  try {
    if (import_fs.default.existsSync(SENT_EMAILS_FILE)) {
      const content = await fs.readFile(SENT_EMAILS_FILE, "utf-8");
      sentEmails = JSON.parse(content);
    } else {
      sentEmails = [];
    }
  } catch (e) {
    console.error("Error loading sent emails:", e);
  }
}
async function saveSentEmail(mailRecord) {
  sentEmails.push(mailRecord);
  try {
    await fs.writeFile(SENT_EMAILS_FILE, JSON.stringify(sentEmails, null, 2), "utf-8");
    if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
      const mailDoc = (0, import_firestore.doc)(db, "app_data", "sent_emails");
      await (0, import_firestore.setDoc)(mailDoc, { history: sentEmails });
    }
  } catch (e) {
    console.error("Error saving sent email:", e);
  }
}
async function syncArtistsCustomDomains() {
  console.log("[Sync] Starting syncArtistsCustomDomains for " + artists.length + " artists...");
  let needsGlobalSave = false;
  for (const art of artists) {
    try {
      let artData = null;
      const file = import_path.default.join(process.cwd(), `data_${art.username}.json`);
      if (import_fs.default.existsSync(file)) {
        const text = import_fs.default.readFileSync(file, "utf-8");
        artData = JSON.parse(text);
      }
      console.log(`[Sync] Checking artist: ${art.username}, local customDomain: ${artData?.customDomain || "none"}`);
      if ((!artData || !artData.customDomain) && !isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
        console.log(`[Sync] Local custom domain empty for ${art.username}. Fetching from Firestore...`);
        const artistDocRef = getFirestoreRefForArtist(art);
        if (artistDocRef) {
          const docSnap = await withTimeout((0, import_firestore.getDoc)(artistDocRef));
          if (docSnap.exists()) {
            artData = docSnap.data();
            console.log(`[Sync] Firestore fetched customDomain for ${art.username}: ${artData?.customDomain}`);
            if (artData && (Array.isArray(artData.demos) && artData.demos.length > 0 || Array.isArray(artData.releasedSongs) && artData.releasedSongs.length > 0)) {
              await fs.writeFile(file, JSON.stringify(artData, null, 2), "utf-8").catch(() => {
              });
            }
          } else {
            console.log(`[Sync] Firestore document not found for ${art.username}`);
          }
        }
      }
      if (artData) {
        if (artData.customDomain && art.customDomain !== artData.customDomain) {
          console.log(`[Sync] Updating artist ${art.username} customDomain in global list from "${art.customDomain}" to "${artData.customDomain}"`);
          art.customDomain = artData.customDomain;
          needsGlobalSave = true;
        }
        if (artData.externalWebsiteUrl && art.externalWebsiteUrl !== artData.externalWebsiteUrl) {
          console.log(`[Sync] Updating artist ${art.username} externalWebsiteUrl in global list from "${art.externalWebsiteUrl}" to "${artData.externalWebsiteUrl}"`);
          art.externalWebsiteUrl = artData.externalWebsiteUrl;
          needsGlobalSave = true;
        }
        if (artData.hasExternalWebsite !== void 0 && art.hasExternalWebsite !== artData.hasExternalWebsite) {
          console.log(`[Sync] Updating artist ${art.username} hasExternalWebsite in global list to ${artData.hasExternalWebsite}`);
          art.hasExternalWebsite = artData.hasExternalWebsite;
          needsGlobalSave = true;
        }
      }
    } catch (err) {
      console.error("Error syncing custom domain for artist " + art.username + ":", err.message || err);
    }
  }
  console.log(`[Sync] needsGlobalSave is ${needsGlobalSave}`);
  if (needsGlobalSave) {
    try {
      const cleanedArtists = JSON.parse(JSON.stringify(artists));
      await fs.writeFile(ARTISTS_FILE, JSON.stringify(cleanedArtists, null, 2), "utf-8");
      console.log(`[Sync] Saved updated artists.json successfully.`);
      if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
        const masterDoc = (0, import_firestore.doc)(db, "app_data", "master");
        try {
          const vDoc = await withTimeout((0, import_firestore.getDoc)((0, import_firestore.doc)(db, "app_data", "vouchers")));
          if (vDoc.exists() && vDoc.data().vouchers) {
            vouchers = vDoc.data().vouchers;
            await fs.writeFile(VOUCHERS_FILE, JSON.stringify(vouchers, null, 2), "utf-8");
          }
        } catch (e) {
        }
        await (0, import_firestore.setDoc)(masterDoc, { artists: cleanedArtists });
        console.log(`[Sync] Saved updated master artists array to Firestore app_data/master.`);
      }
    } catch (e) {
      console.error("Error auto-saving synced artists:", e.message || e);
    }
  }
}
var withTimeout = (promise, timeoutMs = 2500) => Promise.race([
  promise,
  new Promise((_, reject) => setTimeout(() => reject(new Error("Firebase timeout")), timeoutMs))
]);
async function loadArtists() {
  if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
    try {
      const masterDoc = (0, import_firestore.doc)(db, "app_data", "master");
      const snap = await withTimeout((0, import_firestore.getDoc)(masterDoc));
      if (snap.exists() && snap.data().artists) {
        artists = snap.data().artists;
        let changed = false;
        artists.forEach((artist) => {
          if (!artist.id) {
            artist.id = Math.random().toString(36).substring(2, 15);
            changed = true;
          }
          if (artist.activated === void 0) {
            artist.activated = true;
            changed = true;
          }
          if (!artist.createdAt) {
            artist.createdAt = "2026-01-01T00:00:00.000Z";
            changed = true;
          }
          if (artist.emailVerified === void 0) {
            artist.emailVerified = true;
            changed = true;
          }
          if (artist.email === void 0) {
            artist.email = "";
            changed = true;
          }
          if (!artist.defaultLanguage) {
            artist.defaultLanguage = "vi";
            changed = true;
          }
          if (artist.isSpecial === void 0) {
            artist.isSpecial = artist.username === "acxuantai";
            changed = true;
          }
        });
        await fs.writeFile(ARTISTS_FILE, JSON.stringify(artists, null, 2), "utf-8");
        syncArtistsCustomDomains().catch((err) => console.error("Async sync custom domain error:", err));
        loadSentEmails().catch((err) => console.error("Async load sent emails error:", err));
        return artists;
      }
    } catch (e) {
      console.error("Firebase error loading artists:", e);
    }
  }
  try {
    if (import_fs.default.existsSync(ARTISTS_FILE)) {
      const content = await fs.readFile(ARTISTS_FILE, "utf-8");
      artists = JSON.parse(content);
      let changed = false;
      artists.forEach((artist) => {
        if (!artist.id) {
          artist.id = Math.random().toString(36).substring(2, 15);
          changed = true;
        }
        if (artist.activated === void 0) {
          artist.activated = true;
          changed = true;
        }
        if (!artist.createdAt) {
          artist.createdAt = "2026-01-01T00:00:00.000Z";
          changed = true;
        }
        if (artist.emailVerified === void 0) {
          artist.emailVerified = true;
          changed = true;
        }
        if (artist.email === void 0) {
          artist.email = "";
          changed = true;
        }
        if (!artist.defaultLanguage) {
          artist.defaultLanguage = "vi";
          changed = true;
        }
        if (artist.isSpecial === void 0) {
          artist.isSpecial = artist.username === "acxuantai";
          changed = true;
        }
      });
      if (changed) {
        await fs.writeFile(ARTISTS_FILE, JSON.stringify(artists, null, 2), "utf-8");
      }
    } else {
      artists = [
        {
          id: Math.random().toString(36).substring(2, 15),
          artistName: "A.C Xu\xE2n T\xE0i",
          username: "acxuantai",
          extension: "acxuantai",
          password: "XuanTaiDepTrai",
          verified: true,
          dbConfig: "",
          isSpecial: true,
          activated: true,
          createdAt: "2026-01-01T00:00:00.000Z",
          emailVerified: true,
          email: "xuantai@chorus.vn"
        }
      ];
      await fs.writeFile(ARTISTS_FILE, JSON.stringify(artists, null, 2), "utf-8");
    }
  } catch (e) {
    console.error("Error loading artists local:", e);
    artists = [
      {
        id: Math.random().toString(36).substring(2, 15),
        artistName: "A.C Xu\xE2n T\xE0i",
        username: "acxuantai",
        extension: "acxuantai",
        password: "XuanTaiDepTrai",
        verified: true,
        dbConfig: "",
        isSpecial: true,
        activated: true,
        createdAt: "2026-01-01T00:00:00.000Z",
        emailVerified: true,
        email: "xuantai@chorus.vn"
      }
    ];
  }
  if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
    try {
      const masterDoc = (0, import_firestore.doc)(db, "app_data", "master");
      await (0, import_firestore.setDoc)(masterDoc, { artists }, { merge: true });
    } catch (e) {
    }
  }
  await syncArtistsCustomDomains();
  await loadSentEmails();
  return artists;
}
async function saveArtists(list) {
  artists = list;
  try {
    const cleanedArtists = JSON.parse(JSON.stringify(artists));
    await fs.writeFile(ARTISTS_FILE, JSON.stringify(cleanedArtists, null, 2), "utf-8");
    if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
      const masterDoc = (0, import_firestore.doc)(db, "app_data", "master");
      await (0, import_firestore.setDoc)(masterDoc, { artists: cleanedArtists });
    }
  } catch (e) {
    console.error("Error saving artists:", e);
    handleFirebaseError(e);
  }
}
var LANDING_FILE = import_path.default.join(process.cwd(), "landing_config.json");
var landingConfig = {
  tagline: "\u2727 S\u1EAEP RA M\u1EAET",
  heroTitle: "",
  heroSubtitle: "N\u01A1i nh\u1EEFng ca kh\xFAc kh\u1EDFi \u0111\u1EA7u.",
  heroDescription: "Ch\xFAng t\xF4i \u0111ang x\xE2y d\u1EF1ng m\u1ED9t kh\xF4ng gian tr\u1EF1c tuy\u1EBFn, n\u01A1i c\xE1c nh\u1EA1c s\u0129, ca s\u0129, nh\xE0 s\u1EA3n xu\u1EA5t \xE2m nh\u1EA1c, qu\u1EA3n l\xFD ngh\u1EC7 s\u0129, th\u01B0\u01A1ng hi\u1EC7u... c\xF3 th\u1EC3 chia s\u1EBB c\xE1c ca kh\xFAc \u0111\xE3 ph\xE1t h\xE0nh v\xE0 demo ch\u01B0a ra m\u1EAFt c\u1EE7a m\xECnh.",
  footerText: "CHORUS.VN \xA9 2026 - N\u01A1i nh\u1EEFng ca kh\xFAc b\u1EAFt \u0111\u1EA7u.",
  feature1Title: "B\u1EA3o m\u1EADt demo & tuy\u1EC3n t\u1EADp",
  feature1Desc: "Thi\u1EBFt l\u1EADp m\u1EADt m\xE3 cho t\u1EEBng t\xE1c ph\u1EA9m ch\u01B0a c\xF4ng b\u1ED1, ng\u0103n ch\u1EB7n nghe tr\u1ED9m ho\u1EB7c chia s\u1EBB tr\xE1i ph\xE9p. G\u1EEDi link demo b\u1EA3o m\u1EADt cho ca s\u0129, nh\u1EA1c s\u0129 ph\u1ED1i kh\xED v\xE0 c\xE1c \u0111\u1ED1i t\xE1c \u0111\xE1ng tin c\u1EADy.",
  feature2Title: "D\u1ECBch thu\u1EADt th\xF4ng minh (AI Translation)",
  feature2Desc: "Nh\u1EADn di\u1EC7n v\u1ECB tr\xED \u0111\u1ECBa l\xFD c\u1EE7a kh\xE1n gi\u1EA3 qu\u1ED1c t\u1EBF \u0111\u1EC3 hi\u1EC3n th\u1ECB ti\xEAu \u0111\u1EC1 v\xE0 n\u1ED9i dung m\xF4 t\u1EA3 s\u1EA3n ph\u1EA9m b\u1EB1ng ng\xF4n ng\u1EEF b\u1EA3n \u0111\u1ECBa ph\xF9 h\u1EE3p nh\u1EA5t (Anh, Nh\u1EADt, Trung, H\xE0n...).",
  feature3Title: "\u0110\u1ED3ng b\u1ED9 Cloud & Cache c\u1EE5c b\u1ED9",
  feature3Desc: "L\u01B0u tr\u1EEF d\u1EEF li\u1EC7u k\xE9p tr\xEAn Cloud Firestore ch\u1EA5t l\u01B0\u1EE3ng cao k\u1EBFt h\u1EE3p c\u01A1 ch\u1EBF d\u1EF1 ph\xF2ng c\u1EE5c b\u1ED9. Cam k\u1EBFt ph\xE1t nh\u1EA1c \u1ED5n \u0111\u1ECBnh, t\u1ED1c \u0111\u1ED9 load nhanh ngay c\u1EA3 khi internet qu\u1ED1c t\u1EBF g\u1EB7p s\u1EF1 c\u1ED1.",
  feature4Title: "B\u1ED1 c\u1EE5c mang \u0111\u1EADm d\u1EA5u \u1EA5n c\xE1 nh\xE2n",
  feature4Desc: "T\xF9y ch\u1EC9nh \u1EA3nh b\xECa \u0111\u1EA1i di\u1EC7n, m\xE0u s\u1EAFc ch\u1EE7 \u0111\u1EA1o, \u1EA3nh \u0111\u1EA1i di\u1EC7n, vi\u1EBFt bio, c\u1EADp nh\u1EADt danh s\xE1ch m\u1EA1ng x\xE3 h\u1ED9i. Trang c\xE1 nh\xE2n ho\u1EA1t \u0111\u1ED9ng \u0111\u1ED9c l\u1EADp nh\u01B0 m\u1ED9t website thu nh\u1ECF c\u1EE7a ri\xEAng b\u1EA1n.",
  featuresTitle: "\u0110\u01B0\u1EE3c thi\u1EBFt k\u1EBF cho tr\u1EA3i nghi\u1EC7m \u0111\u1EC9nh cao",
  featuresSub: "T\xEDch h\u1EE3p nh\u1EEFng c\xF4ng ngh\u1EC7 hi\u1EC7n \u0111\u1EA1i nh\u1EA5t \u0111\u1EC3 t\u1ED1i \u01B0u h\xF3a quy tr\xECnh ph\xE2n ph\u1ED1i v\xE0 l\u01B0u tr\u1EEF n\u1ED9i b\u1ED9.",
  cloudSyncEnabled: true,
  systemIp: "103.1.2.3",
  pageTitle: "",
  faviconUrl: "",
  ogImageUrl: "",
  statusBadge: "",
  staticTranslations: {}
};
var SUBSCRIBERS_FILE = import_path.default.join(process.cwd(), "subscribers.json");
var VOUCHERS_FILE = import_path.default.join(process.cwd(), "vouchers.json");
var vouchers = [];
try {
  if (import_fs.default.existsSync(VOUCHERS_FILE)) {
    vouchers = JSON.parse(import_fs.default.readFileSync(VOUCHERS_FILE, "utf-8"));
  }
} catch (e) {
  console.error("Error loading vouchers", e);
}
async function saveVouchers() {
  await fs.writeFile(VOUCHERS_FILE, JSON.stringify(vouchers, null, 2), "utf-8");
  if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
    try {
      const docRef = (0, import_firestore.doc)(db, "app_data", "vouchers");
      await (0, import_firestore.setDoc)(docRef, { vouchers });
    } catch (e) {
    }
  }
}
async function addSubscriber(email) {
  let list = [];
  try {
    if (import_fs.default.existsSync(SUBSCRIBERS_FILE)) {
      const content = await fs.readFile(SUBSCRIBERS_FILE, "utf-8");
      list = JSON.parse(content);
    }
  } catch (e) {
  }
  if (!list.includes(email)) {
    list.push(email);
    try {
      await fs.writeFile(SUBSCRIBERS_FILE, JSON.stringify(list, null, 2), "utf-8");
    } catch (e) {
    }
  }
  if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
    try {
      const key = Buffer.from(email).toString("base64url");
      const subDoc = (0, import_firestore.doc)(db, "subscribers", key);
      await (0, import_firestore.setDoc)(subDoc, { email, subscribedAt: (/* @__PURE__ */ new Date()).toISOString() });
    } catch (e) {
      handleFirebaseError(e);
    }
  }
}
var TICKETS_FILE = import_path.default.join(process.cwd(), "tickets.json");
var tickets = [];
async function loadTickets() {
  if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
    try {
      const ticketsDoc = (0, import_firestore.doc)(db, "app_data", "tickets");
      const snap = await (0, import_firestore.getDoc)(ticketsDoc);
      if (snap.exists() && snap.data().tickets) {
        tickets = snap.data().tickets;
        await fs.writeFile(TICKETS_FILE, JSON.stringify(tickets, null, 2), "utf-8");
        return tickets;
      }
    } catch (e) {
      console.error("Firebase error loading tickets:", e);
    }
  }
  try {
    if (import_fs.default.existsSync(TICKETS_FILE)) {
      const content = await fs.readFile(TICKETS_FILE, "utf-8");
      tickets = JSON.parse(content);
    } else {
      tickets = [];
      await fs.writeFile(TICKETS_FILE, JSON.stringify(tickets, null, 2), "utf-8");
    }
  } catch (e) {
    console.error("Error loading tickets local:", e);
    tickets = [];
  }
  return tickets;
}
async function saveTickets(list) {
  tickets = list;
  try {
    await fs.writeFile(TICKETS_FILE, JSON.stringify(tickets, null, 2), "utf-8");
    if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
      const ticketsDoc = (0, import_firestore.doc)(db, "app_data", "tickets");
      await (0, import_firestore.setDoc)(ticketsDoc, { tickets });
    }
  } catch (e) {
    console.error("Error saving tickets:", e);
  }
}
function mapTicket(t) {
  if (!t) return t;
  const repArtist = (artists || []).find((a) => a.username === t.reporterArtist || a.extension === t.reporterArtist);
  const srcArtist = (artists || []).find((a) => a.username === t.sourceArtist || a.extension === t.sourceArtist);
  return {
    ...t,
    reporter: {
      username: t.reporterArtist,
      name: repArtist ? repArtist.artistName : t.reporterArtist
    },
    uploader: {
      username: t.sourceArtist,
      name: srcArtist ? srcArtist.artistName : t.sourceArtist
    }
  };
}
async function convertAudioToMp3(inputPath) {
  const outputPath = inputPath.replace(/\.[^/.]+$/, "") + "_converted.mp3";
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath).toFormat("mp3").audioBitrate("320k").on("end", () => resolve(outputPath)).on("error", (err) => {
      fs.unlink(outputPath).catch(() => {
      });
      reject(err);
    }).save(outputPath);
  });
}
async function loadLandingConfig() {
  try {
    if (import_fs.default.existsSync(LANDING_FILE)) {
      const content = await fs.readFile(LANDING_FILE, "utf-8");
      landingConfig = { ...landingConfig, ...JSON.parse(content) };
    } else {
      await fs.writeFile(LANDING_FILE, JSON.stringify(landingConfig, null, 2), "utf-8");
    }
  } catch (e) {
    console.error("Error loading landing config local:", e);
  }
  if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
    try {
      const landingDoc = (0, import_firestore.doc)(db, "app_data", "landing");
      const snap = await withTimeout((0, import_firestore.getDoc)(landingDoc));
      if (snap.exists()) {
        landingConfig = { ...landingConfig, ...snap.data() };
      } else {
        await withTimeout((0, import_firestore.setDoc)(landingDoc, landingConfig)).catch((e) => console.error("setDoc landing timeout:", e));
      }
    } catch (e) {
      handleFirebaseError(e);
    }
  }
  return landingConfig;
}
async function saveLandingConfig(cfg) {
  landingConfig = { ...landingConfig, ...cfg };
  try {
    await fs.writeFile(LANDING_FILE, JSON.stringify(landingConfig, null, 2), "utf-8");
  } catch (e) {
    console.error("Error saving landing config local:", e);
  }
  if (!isFirestoreDisabled && landingConfig.cloudSyncEnabled !== false) {
    try {
      const landingDoc = (0, import_firestore.doc)(db, "app_data", "landing");
      await (0, import_firestore.setDoc)(landingDoc, landingConfig);
    } catch (e) {
      handleFirebaseError(e);
    }
  }
}
var firebaseAppCache = /* @__PURE__ */ new Map();
function getFirestoreRefForArtist(artist) {
  if (isFirestoreDisabled || landingConfig.cloudSyncEnabled === false) {
    return null;
  }
  if (artist && artist.dbConfig) {
    try {
      const config = typeof artist.dbConfig === "string" ? JSON.parse(artist.dbConfig) : artist.dbConfig;
      const projectId = config.projectId || config.project_id;
      const apiKey = config.apiKey || config.api_key;
      const firestoreDatabaseId = config.firestoreDatabaseId || config.firestore_database_id;
      if (config && projectId && apiKey) {
        if (!firebaseAppCache.has(artist.username)) {
          const appName = `app-${artist.username}-${Date.now()}`;
          const normalizedConfig = {
            apiKey,
            authDomain: config.authDomain || config.auth_domain,
            projectId,
            storageBucket: config.storageBucket || config.storage_bucket,
            messagingSenderId: config.messagingSenderId || config.messaging_sender_id,
            appId: config.appId || config.app_id,
            measurementId: config.measurementId || config.measurement_id,
            firestoreDatabaseId: firestoreDatabaseId || "(default)"
          };
          const app = (0, import_app.initializeApp)(normalizedConfig, appName);
          const customDb = (0, import_firestore.getFirestore)(app, firestoreDatabaseId || "(default)");
          const docRef = (0, import_firestore.doc)(customDb, "app_data", "main");
          firebaseAppCache.set(artist.username, { app, db: customDb, docRef });
        }
        return firebaseAppCache.get(artist.username).docRef;
      }
    } catch (e) {
      console.error(`Error initializing custom DB for artist ${artist.username}:`, e);
    }
  }
  const username = artist?.username || "acxuantai";
  return (0, import_firestore.doc)(db, "app_data", `artist_${username}`);
}
var DATA_FILE = import_path.default.join(process.cwd(), "data.json");
var UPLOADS_DIR = import_path.default.join(process.cwd(), "public", "uploads");
async function ensureUploadsDir() {
  await fs.mkdir(UPLOADS_DIR, { recursive: true });
}
async function uploadLocalToCloud(localPath, filename, mimetype, artistId = "common") {
  if (s3Client) {
    try {
      if (mimetype.startsWith("image/")) {
        const isPng = mimetype === "image/png" || filename.toLowerCase().endsWith(".png");
        const ext = isPng ? "png" : "jpg";
        const baseName = filename.includes(".") ? filename.substring(0, filename.lastIndexOf(".")) : filename;
        const optimizedFilename = `${baseName}-${Date.now()}.${ext}`;
        const optimizedDir = import_path.default.join(UPLOADS_DIR, artistId);
        await fs.mkdir(optimizedDir, { recursive: true }).catch(() => {
        });
        const optimizedPath = import_path.default.join(optimizedDir, optimizedFilename);
        const s = getSharp(localPath);
        if (s) {
          let sharpInstance = s.resize({ width: 1600, withoutEnlargement: true });
          if (isPng) {
            sharpInstance = sharpInstance.png({ palette: true, quality: 85 });
          } else {
            sharpInstance = sharpInstance.jpeg({ quality: 80, progressive: true });
          }
          await sharpInstance.toFile(optimizedPath);
          const r2Key2 = `uploads/${artistId}/${optimizedFilename}`;
          const r2Url2 = await uploadToR2(optimizedPath, r2Key2, isPng ? "image/png" : "image/jpeg");
          console.log(`[Cloudflare R2] \u0110\xE3 n\xE9n v\xE0 upload \u1EA3nh l\xEAn R2 th\xE0nh c\xF4ng: ${r2Url2}`);
          await fs.unlink(localPath).catch(() => {
          });
          await fs.unlink(optimizedPath).catch(() => {
          });
          return r2Url2;
        }
      }
      const r2Key = `uploads/${artistId}/${filename}`;
      const r2Url = await uploadToR2(localPath, r2Key, mimetype);
      console.log(`[Cloudflare R2] \u0110\xE3 upload file \xE2m thanh/t\xE0i li\u1EC7u l\xEAn R2 th\xE0nh c\xF4ng: ${r2Url}`);
      await fs.unlink(localPath).catch(() => {
      });
      return r2Url;
    } catch (r2Err) {
      console.error("[Cloudflare R2] L\u1ED7i upload R2, s\u1EED d\u1EE5ng fallback local server:", r2Err.message);
    }
  }
  return `/uploads/${artistId}/${filename}`;
}
async function deleteFileByUrl(url) {
  if (!url) return;
  try {
    let usageCount = 0;
    for (const a of artists) {
      const data = await loadData(a.username).catch(() => null);
      if (!data) continue;
      const demos = data.demos || [];
      for (const d of demos) {
        if (d.audioUrl === url || d.coverUrl === url || d.backgroundUrl === url) {
          usageCount++;
        }
      }
      const playlists = data.playlists || [];
      for (const p of playlists) {
        if (p.coverUrl === url) {
          usageCount++;
        }
      }
      if (data.homeCoverUrl === url || data.faviconUrl === url || data.ogImageUrl === url) {
        usageCount++;
      }
      if (data.slideshowImages && data.slideshowImages.includes(url)) {
        usageCount++;
      }
    }
    if (usageCount > 1) {
      console.log(`[Revert/Cleanup] File ${url} \u0111ang \u0111\u01B0\u1EE3c s\u1EED d\u1EE5ng \u1EDF ${usageCount} v\u1ECB tr\xED kh\xE1c. Kh\xF4ng x\xF3a kh\u1ECFi server.`);
      return;
    }
  } catch (err) {
    console.error("Error checking file usage in deleteFileByUrl:", err);
  }
  if (s3Client && DeleteObjectCommandClass && (url.includes(r2PublicDomain) || url.includes("r2.cloudflarestorage.com") || url.includes("cdn.bbb.bz"))) {
    try {
      let key = url;
      if (url.includes(r2PublicDomain)) {
        key = url.replace(`${r2PublicDomain}/`, "");
      } else if (url.includes("cdn.bbb.bz/")) {
        key = url.split("cdn.bbb.bz/")[1];
      }
      const command = new DeleteObjectCommandClass({
        Bucket: r2BucketName,
        Key: key
      });
      await s3Client.send(command);
      console.log(`[Cloudflare R2] \u0110\xE3 x\xF3a t\u1EC7p v\u1EADt l\xFD tr\xEAn R2 Bucket th\xE0nh c\xF4ng: ${key}`);
    } catch (err) {
      console.error(`[Cloudflare R2] L\u1ED7i x\xF3a file tr\xEAn R2 (${url}):`, err.message);
    }
  }
  if (url.startsWith("/uploads/") || url.startsWith("uploads/")) {
    const relativePath = url.startsWith("/") ? url.substring(1) : url;
    const localFullPath = import_path.default.join(process.cwd(), "public", relativePath);
    try {
      await fs.unlink(localFullPath);
      console.log(`[Revert/Cleanup] \u0110\xE3 x\xF3a file c\u1EE5c b\u1ED9 th\xE0nh c\xF4ng: ${localFullPath}`);
    } catch (err) {
      console.error(`[Revert/Cleanup] Kh\xF4ng th\u1EC3 x\xF3a file c\u1EE5c b\u1ED9 ${localFullPath}:`, err.message);
    }
  } else if (url.includes(firebaseConfig.storageBucket)) {
    if (isFirestoreDisabled) return;
    try {
      const decodedUrl = decodeURIComponent(url);
      const match = decodedUrl.match(/\/o\/(uploads\/[^?]+)/);
      if (match && match[1]) {
        const fileRef = (0, import_storage.ref)(firebaseStorage, match[1]);
        await (0, import_storage.deleteObject)(fileRef);
        console.log(`[Revert/Cleanup] \u0110\xE3 x\xF3a file tr\xEAn Firebase Storage th\xE0nh c\xF4ng: ${match[1]}`);
      }
    } catch (err) {
      console.log(`[Revert/Cleanup] Firebase Storage delete skipped or failed:`, err.message);
    }
  }
}
async function uploadUrlOrFileToCloud(urlOrPath, globalBaseUrl) {
  if (!urlOrPath) return "";
  if (urlOrPath.startsWith(r2PublicDomain)) return urlOrPath;
  if (urlOrPath.startsWith("data:")) return urlOrPath;
  const currentArtistId = artistStorage.getStore() || "common";
  if (s3Client) {
    try {
      if (urlOrPath.startsWith("/uploads/") || urlOrPath.startsWith("uploads/")) {
        const relPath = urlOrPath.startsWith("/") ? urlOrPath.substring(1) : urlOrPath;
        const localFullPath = import_path.default.join(process.cwd(), "public", relPath);
        if (import_fs.default.existsSync(localFullPath)) {
          const fileBuffer = await fs.readFile(localFullPath);
          const mime = getMimeType(localFullPath);
          const command = new PutObjectCommandClass({
            Bucket: r2BucketName,
            Key: relPath,
            Body: fileBuffer,
            ContentType: mime
          });
          await s3Client.send(command);
          const r2Url = `${r2PublicDomain}/${relPath}`;
          console.log(`[Cloudflare R2] Synced local file to R2: ${r2Url}`);
          return r2Url;
        }
      }
      if (urlOrPath.startsWith("http://") || urlOrPath.startsWith("https://")) {
        console.log(`[Cloudflare R2] Downloading remote URL to upload to R2: ${urlOrPath}`);
        const res = await fetch(urlOrPath, {
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" }
        });
        if (res.ok) {
          const arrayBuffer = await res.arrayBuffer();
          const buffer = Buffer.from(arrayBuffer);
          const isPng = urlOrPath.includes(".png");
          const isMp3 = urlOrPath.includes(".mp3");
          const ext = isMp3 ? "mp3" : isPng ? "png" : "jpg";
          const mime = isMp3 ? "audio/mpeg" : isPng ? "image/png" : "image/jpeg";
          const filename = `synced_${Date.now()}_${Math.floor(Math.random() * 1e4)}.${ext}`;
          const relPath = `uploads/${currentArtistId}/${filename}`;
          const localDir = import_path.default.join(process.cwd(), "public", "uploads", currentArtistId);
          if (!import_fs.default.existsSync(localDir)) {
            import_fs.default.mkdirSync(localDir, { recursive: true });
          }
          await fs.writeFile(import_path.default.join(localDir, filename), buffer).catch(() => {
          });
          const command = new PutObjectCommandClass({
            Bucket: r2BucketName,
            Key: relPath,
            Body: buffer,
            ContentType: mime
          });
          await s3Client.send(command);
          const r2Url = `${r2PublicDomain}/${relPath}`;
          console.log(`[Cloudflare R2] Synced remote URL to R2: ${r2Url}`);
          if (currentArtistId === "acxuantai" && !isFirestoreDisabled && firebaseStorage) {
            try {
              const storageRef = (0, import_storage.ref)(firebaseStorage, relPath);
              await (0, import_storage.uploadBytes)(storageRef, buffer, { contentType: mime });
              console.log(`[Firebase Extra Copy] Synced extra copy to Firebase for acxuantai: ${relPath}`);
            } catch (fbErr) {
              console.error(`[Firebase Extra Copy Error]:`, fbErr.message);
            }
          }
          return r2Url;
        }
      }
    } catch (err) {
      console.error("[Cloudflare R2] uploadUrlOrFileToCloud error:", err.message);
    }
  }
  return urlOrPath;
}
async function syncAllDataToR2() {
  if (!s3Client) return;
  console.log("\u{1F680} [Cloudflare R2] Starting comprehensive sync of all artist data to Cloudflare R2 & Firestore...");
  for (const a of artists) {
    try {
      await artistStorage.run(a.username, async () => {
        const data = await loadData(a.username);
        let modified = false;
        if (data.demos && Array.isArray(data.demos)) {
          for (const demo of data.demos) {
            if (demo.audioUrl) {
              const newUrl = await uploadUrlOrFileToCloud(demo.audioUrl, a.username);
              if (newUrl && newUrl !== demo.audioUrl) {
                demo.audioUrl = newUrl;
                modified = true;
              }
            }
            if (demo.backupAudioUrl) {
              const newUrl = await uploadUrlOrFileToCloud(demo.backupAudioUrl, a.username);
              if (newUrl && newUrl !== demo.backupAudioUrl) {
                demo.backupAudioUrl = newUrl;
                modified = true;
              }
            }
            if (demo.coverUrl) {
              const newUrl = await uploadUrlOrFileToCloud(demo.coverUrl, a.username);
              if (newUrl && newUrl !== demo.coverUrl) {
                demo.coverUrl = newUrl;
                modified = true;
              }
            }
          }
        }
        if (data.playlists && Array.isArray(data.playlists)) {
          for (const playlist of data.playlists) {
            if (playlist.coverUrl) {
              const newUrl = await uploadUrlOrFileToCloud(playlist.coverUrl, a.username);
              if (newUrl && newUrl !== playlist.coverUrl) {
                playlist.coverUrl = newUrl;
                modified = true;
              }
            }
          }
        }
        const assetKeys = ["homeCoverUrl", "faviconUrl", "ogImageUrl", "avatarUrl", "backgroundUrl"];
        for (const key of assetKeys) {
          if (data[key]) {
            const newUrl = await uploadUrlOrFileToCloud(data[key], a.username);
            if (newUrl && newUrl !== data[key]) {
              data[key] = newUrl;
              modified = true;
            }
          }
        }
        if (modified) {
          await saveData(data);
          console.log(`\u2705 [Cloudflare R2] Successfully synced artist ${a.username} to Firestore & R2!`);
        }
      });
    } catch (err) {
      console.error(`\u274C [Cloudflare R2] Error syncing artist ${a.username}:`, err.message);
    }
  }
}
var sqlite3Module = null;
try {
  sqlite3Module = require("sqlite3").verbose();
} catch (e) {
  console.log("\u26A0\uFE0F [SQLite Backup] sqlite3 module not available:", e.message);
}
async function createSqliteBackup() {
  const dateStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const filename = `backup_${dateStr}_${Date.now()}.sqlite`;
  const backupDir = import_path.default.join(process.cwd(), "backups");
  if (!import_fs.default.existsSync(backupDir)) {
    import_fs.default.mkdirSync(backupDir, { recursive: true });
  }
  const sqliteFilePath = import_path.default.join(backupDir, filename);
  console.log(`\u{1F4E6} [SQLite Backup] B\u1EAFt \u0111\u1EA7u \u0111\xF3ng g\xF3i to\xE0n b\u1ED9 c\u01A1 s\u1EDF d\u1EEF li\u1EC7u v\xE0o file: ${filename}...`);
  if (!sqlite3Module) {
    const fallbackPath = `${sqliteFilePath}.json`;
    const fullSnapshot = { timestamp: Date.now(), dateStr, artists: [] };
    for (const a of artists) {
      try {
        const data = await loadData(a.username);
        fullSnapshot.artists.push({ username: a.username, artist: a, data });
      } catch (err) {
      }
    }
    await fs.writeFile(fallbackPath, JSON.stringify(fullSnapshot, null, 2), "utf-8");
    let r2Url = "";
    if (s3Client) {
      r2Url = await uploadToR2(fallbackPath, `backups/${import_path.default.basename(fallbackPath)}`, "application/json").catch(() => "");
    }
    return { localPath: fallbackPath, r2Url, filename: import_path.default.basename(fallbackPath), totalArtists: fullSnapshot.artists.length };
  }
  return new Promise(async (resolve, reject) => {
    const db2 = new sqlite3Module.Database(sqliteFilePath);
    db2.serialize(async () => {
      db2.run(`CREATE TABLE IF NOT EXISTS artist_data (
        username TEXT PRIMARY KEY,
        artistName TEXT,
        data_json TEXT,
        updated_at INTEGER
      )`);
      db2.run(`CREATE TABLE IF NOT EXISTS artists_registry (
        username TEXT PRIMARY KEY,
        extension TEXT,
        customDomain TEXT,
        info_json TEXT,
        updated_at INTEGER
      )`);
      const stmtArtist = db2.prepare(`INSERT OR REPLACE INTO artist_data (username, artistName, data_json, updated_at) VALUES (?, ?, ?, ?)`);
      const stmtRegistry = db2.prepare(`INSERT OR REPLACE INTO artists_registry (username, extension, customDomain, info_json, updated_at) VALUES (?, ?, ?, ?, ?)`);
      let totalArtists = 0;
      const now = Date.now();
      for (const a of artists) {
        try {
          const data = await loadData(a.username);
          stmtArtist.run(a.username, a.artistName || a.username, JSON.stringify(data), now);
          stmtRegistry.run(a.username, a.extension || "", a.customDomain || "", JSON.stringify(a), now);
          totalArtists++;
        } catch (err) {
          console.error(`Error backing up artist ${a.username} to SQLite:`, err);
        }
      }
      stmtArtist.finalize();
      stmtRegistry.finalize();
      db2.close(async (err) => {
        if (err) return reject(err);
        console.log(`\u2705 [SQLite Backup] \u0110\xE3 t\u1EA1o th\xE0nh c\xF4ng file SQLite c\u1EE5c b\u1ED9 (${totalArtists} ngh\u1EC7 s\u0129): ${sqliteFilePath}`);
        let r2Url = "";
        if (s3Client) {
          try {
            r2Url = await uploadToR2(sqliteFilePath, `backups/${filename}`, "application/x-sqlite3");
            console.log(`\u2601\uFE0F [SQLite Backup] \u0110\xE3 upload file SQLite l\xEAn Cloudflare R2: ${r2Url}`);
          } catch (r2Err) {
            console.error("L\u1ED7i upload SQLite backup l\xEAn R2:", r2Err.message);
          }
        }
        resolve({ localPath: sqliteFilePath, r2Url, filename, totalArtists });
      });
    });
  });
}
var storage = import_multer.default.diskStorage({
  destination: function(req, file, cb) {
    const artistId = req.artist?.id || "common";
    const dest = import_path.default.join(UPLOADS_DIR, artistId);
    import_fs.default.mkdirSync(dest, { recursive: true });
    cb(null, dest);
  },
  filename: function(req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + import_path.default.extname(file.originalname));
  }
});
var upload = (0, import_multer.default)({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }
});
var currentAdminPassword = "MatKhauDay123";
var currentMemberPassword = "XuanTaiDepTrai";
async function loadData(explicitUsername) {
  const storeUsername = artistStorage.getStore();
  const currentUsername = explicitUsername || storeUsername || "acxuantai";
  const artist = artists.find((a) => a.username === currentUsername) || artists[0] || { username: "acxuantai", artistName: "A.C Xu\xE2n T\xE0i" };
  const artistDataFile = import_path.default.join(process.cwd(), `data_${currentUsername}.json`);
  const artistDocRef = getFirestoreRefForArtist(artist);
  let currentAdminPasswordLocal = artist.password || "MatKhauDay123";
  let currentMemberPasswordLocal = artist.memberPassword || "";
  if (artistDocRef && !isFirestoreDisabled) {
    try {
      const docSnap = await withTimeout((0, import_firestore.getDoc)(artistDocRef));
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (import_fs.default.existsSync(artistDataFile)) {
          try {
            const localText = import_fs.default.readFileSync(artistDataFile, "utf-8");
            const localData = JSON.parse(localText);
            if (localData.aboutMe) data.aboutMe = localData.aboutMe;
            if (localData.biography) data.biography = localData.biography;
            if (localData.profile) data.profile = localData.profile;
          } catch (e) {
          }
        }
        let changed = false;
        if (!data.layoutSections || !Array.isArray(data.layoutSections)) {
          data.layoutSections = ["title", "random_song", "about", "bio", "vault", "mv", "spotify"];
          changed = true;
        } else {
          if (!data.layoutSections.includes("about")) {
            data.layoutSections.splice(2, 0, "about");
            changed = true;
          }
          if (!data.layoutSections.includes("bio")) {
            data.layoutSections.splice(3, 0, "bio");
            changed = true;
          }
        }
        if (!data.demos) data.demos = [];
        if (!data.playlists) data.playlists = [];
        if (!data.defaultLanguage) data.defaultLanguage = artist.defaultLanguage || "vi";
        if (!data.menus || !Array.isArray(data.menus) || data.menus.length === 0) {
          data.menus = [
            { id: "m1", type: "vault", title: "Kho Nh\u1EA1c", isVisible: true },
            { id: "m2", type: "about", title: "V\u1EC1 T\xF4i", isVisible: true },
            { id: "m3", type: "bio", title: "Ti\u1EC3u S\u1EED", isVisible: true }
          ];
        }
        if (data.adminPassword) {
          currentAdminPasswordLocal = data.adminPassword;
        } else {
          data.adminPassword = currentAdminPasswordLocal;
        }
        if (data.memberPassword !== void 0) {
          currentMemberPasswordLocal = data.memberPassword;
        } else {
          data.memberPassword = currentMemberPasswordLocal;
        }
        const thirtyDaysMs = 30 * 24 * 60 * 60 * 1e3;
        const now = Date.now();
        if (data.demos) {
          const lenBefore = data.demos.length;
          let draftChanged = false;
          data.demos = data.demos.filter((d) => {
            if (d.deleted && d.deletedAt && now - d.deletedAt > thirtyDaysMs) {
              if (d.audioUrl) deleteFileByUrl(d.audioUrl).catch(() => {
              });
              if (d.backupAudioUrl) deleteFileByUrl(d.backupAudioUrl).catch(() => {
              });
              if (d.coverUrl) deleteFileByUrl(d.coverUrl).catch(() => {
              });
              return false;
            }
            if (d.isDraft === "false" || d.isDraft === "0") {
              d.isDraft = false;
              draftChanged = true;
            } else if (d.isDraft === "true" || d.isDraft === "1") {
              d.isDraft = true;
              draftChanged = true;
            }
            if (!d.secretKey) {
              d.secretKey = import_crypto.default.randomBytes(8).toString("hex");
              draftChanged = true;
            }
            return true;
          });
          if (data.demos.length !== lenBefore || draftChanged) changed = true;
        }
        if (data.playlists) {
          const lenBefore = data.playlists.length;
          data.playlists = data.playlists.filter((p) => {
            if (p.deleted && p.deletedAt && now - p.deletedAt > thirtyDaysMs) {
              if (p.coverUrl) deleteFileByUrl(p.coverUrl).catch(() => {
              });
              return false;
            }
            return true;
          });
          if (data.playlists.length !== lenBefore) changed = true;
        }
        if (changed) {
          await (0, import_firestore.setDoc)(artistDocRef, JSON.parse(JSON.stringify(data)));
        }
        try {
          await fs.writeFile(artistDataFile, JSON.stringify(data, null, 2), "utf-8");
        } catch (e) {
        }
        return data;
      }
    } catch (error) {
      console.error("Firebase load error for artist " + currentUsername + ":", error.message || error);
      handleFirebaseError(error);
    }
  }
  try {
    if (import_fs.default.existsSync(artistDataFile)) {
      const data = await fs.readFile(artistDataFile, "utf-8");
      const parsedData = JSON.parse(data);
      if (!parsedData.demos) parsedData.demos = [];
      if (!parsedData.playlists) parsedData.playlists = [];
      if (!parsedData.defaultLanguage) parsedData.defaultLanguage = artist.defaultLanguage || "vi";
      if (!parsedData.menus || !Array.isArray(parsedData.menus) || parsedData.menus.length === 0) {
        parsedData.menus = [
          { id: "m1", type: "vault", title: "Kho Nh\u1EA1c", isVisible: true },
          { id: "m2", type: "about", title: "V\u1EC1 T\xF4i", isVisible: true },
          { id: "m3", type: "bio", title: "Ti\u1EC3u S\u1EED", isVisible: true }
        ];
      }
      if (parsedData.adminPassword) {
        currentAdminPasswordLocal = parsedData.adminPassword;
      } else {
        parsedData.adminPassword = currentAdminPasswordLocal;
      }
      if (parsedData.memberPassword !== void 0) {
        currentMemberPasswordLocal = parsedData.memberPassword;
      } else {
        parsedData.memberPassword = currentMemberPasswordLocal;
      }
      if (parsedData.demos) {
        parsedData.demos = parsedData.demos.map((d) => {
          if (d.isDraft === "false" || d.isDraft === "0") {
            d.isDraft = false;
          } else if (d.isDraft === "true" || d.isDraft === "1") {
            d.isDraft = true;
          }
          if (!d.secretKey) {
            d.secretKey = import_crypto.default.randomBytes(8).toString("hex");
          }
          return d;
        });
      }
      if (artistDocRef && !isFirestoreDisabled) {
        try {
          await (0, import_firestore.setDoc)(artistDocRef, parsedData);
        } catch (e) {
          console.error("Firebase migration error for artist " + currentUsername + ":", e.message || e);
          handleFirebaseError(e);
        }
      }
      return parsedData;
    } else if (currentUsername === "acxuantai" && import_fs.default.existsSync(DATA_FILE)) {
      const data = await fs.readFile(DATA_FILE, "utf-8");
      await fs.writeFile(artistDataFile, data, "utf-8");
      const parsedData = JSON.parse(data);
      return parsedData;
    }
  } catch (error) {
    console.error("Local data fallback error for artist " + currentUsername + ":", error);
  }
  const defaultData = {
    pageTitle: `Kho nh\u1EA1c c\u1EE7a ${artist.artistName || "Ngh\u1EC7 s\u0129"}`,
    artistName: artist.artistName || "Ngh\u1EC7 s\u0129",
    artistBio: `Thi\xEAn \u0111\u01B0\u1EDDng nh\u1EA1c c\u1EE7a ${artist.artistName || "Ngh\u1EC7 s\u0129"}`,
    defaultLanguage: artist.defaultLanguage || "vi",
    homeCoverUrl: "",
    faviconUrl: "",
    ogImageUrl: "",
    youtubePlaylistUrl: "",
    spotifyUrl: "",
    releasedSongs: [],
    demos: [],
    playlists: [],
    menus: [
      { id: "m1", type: "vault", title: "Kho Nh\u1EA1c", isVisible: true },
      { id: "m2", type: "about", title: "V\u1EC1 T\xF4i", isVisible: true },
      { id: "m3", type: "bio", title: "Ti\u1EC3u S\u1EED", isVisible: true }
    ],
    aboutMe: {},
    biography: { education: [], experience: [] },
    adminPassword: currentAdminPasswordLocal,
    memberPassword: currentMemberPasswordLocal
  };
  try {
    await fs.writeFile(artistDataFile, JSON.stringify(defaultData, null, 2), "utf-8");
  } catch (e) {
  }
  return defaultData;
}
async function saveData(usernameOrData, data) {
  let currentUsername = "acxuantai";
  let realData = usernameOrData;
  if (typeof usernameOrData === "string" && data !== void 0) {
    currentUsername = usernameOrData;
    realData = data;
  } else {
    if (realData && realData.username) {
      currentUsername = realData.username;
    } else {
      const foundArtist = artists.find(
        (a) => realData.artistName && a.artistName === realData.artistName || realData.adminPassword && a.password === realData.adminPassword
      );
      if (foundArtist) {
        currentUsername = foundArtist.username;
      } else {
        currentUsername = artistStorage.getStore() || "acxuantai";
      }
    }
    realData = usernameOrData;
  }
  realData.username = currentUsername;
  const artist = artists.find((a) => a.username === currentUsername) || artists[0] || { username: "acxuantai" };
  const artistDataFile = import_path.default.join(process.cwd(), `data_${currentUsername}.json`);
  const artistDocRef = getFirestoreRefForArtist(artist);
  if (artistDocRef && !isFirestoreDisabled) {
    try {
      const cleanedData = JSON.parse(JSON.stringify(realData));
      await (0, import_firestore.setDoc)(artistDocRef, cleanedData);
    } catch (error) {
      console.error("Firebase save error for artist " + currentUsername + ":", error.message || error);
      handleFirebaseError(error);
    }
  }
  try {
    await fs.writeFile(artistDataFile, JSON.stringify(realData, null, 2), "utf-8");
  } catch (e) {
    console.error("Error writing local file for artist " + currentUsername + ":", e);
  }
}
async function startServer() {
  await loadArtists();
  await loadLandingConfig();
  await ensureUploadsDir();
  const app = (0, import_express.default)();
  app.set("trust proxy", 1);
  app.use((0, import_cors.default)({
    origin: (origin, callback) => {
      callback(null, origin || true);
    },
    credentials: true
  }));
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });
  const normalizeToAscii = (domain) => {
    try {
      const clean = (domain || "").replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0].toLowerCase().trim();
      return import_punycode.default.toASCII(clean.normalize("NFC"));
    } catch (e) {
      return (domain || "").replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0].toLowerCase().trim();
    }
  };
  const domainsMatch = (d1, d2) => {
    if (!d1 || !d2) return false;
    const clean = (d) => d.replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0].toLowerCase().trim();
    const c1 = clean(d1);
    const c2 = clean(d2);
    if (c1 === c2) return true;
    try {
      const ascii1_nfc = import_punycode.default.toASCII(c1.normalize("NFC"));
      const ascii1_nfd = import_punycode.default.toASCII(c1.normalize("NFD"));
      const ascii2_nfc = import_punycode.default.toASCII(c2.normalize("NFC"));
      const ascii2_nfd = import_punycode.default.toASCII(c2.normalize("NFD"));
      const uni1_nfc = import_punycode.default.toUnicode(c1).normalize("NFC");
      const uni1_nfd = import_punycode.default.toUnicode(c1).normalize("NFD");
      const uni2_nfc = import_punycode.default.toUnicode(c2).normalize("NFC");
      const uni2_nfd = import_punycode.default.toUnicode(c2).normalize("NFD");
      const set1 = /* @__PURE__ */ new Set([c1, ascii1_nfc, ascii1_nfd, uni1_nfc, uni1_nfd]);
      const set2 = /* @__PURE__ */ new Set([c2, ascii2_nfc, ascii2_nfd, uni2_nfc, uni2_nfd]);
      for (const item of set1) {
        if (set2.has(item)) return true;
      }
    } catch (e) {
    }
    return false;
  };
  const getArtistFromRequest = (req) => {
    let ext = req.query.artist || req.query.extension || req.query.artistExtension;
    if (!ext) {
      ext = req.headers["x-artist-extension"] || req.headers["x-artist"];
    }
    if (!ext && req.path) {
      const segments = req.path.split("/").filter(Boolean);
      if (segments.length > 0) {
        const possibleExt = segments[0];
        const reserved = ["admin", "acp", "mem", "demo", "song", "playlist", "api", "uploads"];
        if (!reserved.includes(possibleExt)) {
          const matchedArtist = artists.find((a) => {
            if (a.extension === possibleExt || a.username === possibleExt) return true;
            if (a.extraUsernames) {
              const extras = a.extraUsernames.split(",").map((u) => u.trim().toLowerCase()).filter(Boolean);
              if (extras.includes(possibleExt.toLowerCase().trim())) return true;
            }
            return false;
          });
          if (matchedArtist) {
            ext = matchedArtist.extension;
          }
        }
      }
    }
    const hostHeader = req.get("x-forwarded-host") || req.get("host");
    if (!ext && hostHeader) {
      const host = hostHeader.replace(/^www\./, "").toLowerCase().trim();
      const matchedArtist = artists.find((a) => {
        const cd = a.customDomain || "";
        const ew = a.externalWebsiteUrl || "";
        return cd && domainsMatch(cd, host) || ew && domainsMatch(ew, host);
      });
      if (matchedArtist) {
        ext = matchedArtist.extension;
      } else {
        const hostOnly = host.split(":")[0];
        const isIP = /^\d+\.\d+\.\d+\.\d+$/.test(hostOnly);
        const parts = hostOnly.split(".");
        if (parts.length >= 3 && !isIP) {
          const possibleSub = parts[0];
          const isArtistSub = artists.some((a) => {
            if (a.extension === possibleSub || a.username === possibleSub) return true;
            if (a.extraUsernames) {
              const extras = a.extraUsernames.split(",").map((u) => u.trim().toLowerCase()).filter(Boolean);
              if (extras.includes(possibleSub)) return true;
            }
            return false;
          });
          if (isArtistSub) {
            ext = possibleSub;
          }
        }
      }
    }
    if (!ext) {
      const referer = req.headers["referer"];
      if (referer) {
        try {
          const parsedUrl = new URL(referer);
          const refHost = parsedUrl.hostname.replace(/^www\./, "").toLowerCase().trim();
          const matchedArtistByRef = artists.find((a) => {
            const cd = a.customDomain || "";
            const ew = a.externalWebsiteUrl || "";
            return cd && domainsMatch(cd, refHost) || ew && domainsMatch(ew, refHost);
          });
          if (matchedArtistByRef) {
            ext = matchedArtistByRef.extension;
          } else {
            const parts = refHost.split(".");
            if (parts.length >= 3) {
              const possibleSub = parts[0];
              const isArtistSub = artists.some((a) => {
                if (a.extension === possibleSub || a.username === possibleSub) return true;
                if (a.extraUsernames) {
                  const extras = a.extraUsernames.split(",").map((u) => u.trim().toLowerCase()).filter(Boolean);
                  if (extras.includes(possibleSub)) return true;
                }
                return false;
              });
              if (isArtistSub) {
                ext = possibleSub;
              }
            }
          }
          if (!ext) {
            const segments = parsedUrl.pathname.split("/").filter(Boolean);
            if (segments.length > 0) {
              const possibleExt = segments[0];
              const reserved = ["admin", "acp", "mem", "demo", "song", "playlist", "api"];
              if (!reserved.includes(possibleExt)) {
                ext = possibleExt;
              }
            }
          }
        } catch (e) {
        }
      }
    }
    if (ext) {
      const artist = artists.find((a) => {
        if (a.extension === ext || a.username === ext) return true;
        if (a.extraUsernames) {
          const extras = a.extraUsernames.split(",").map((u) => u.trim().toLowerCase()).filter(Boolean);
          if (extras.includes(ext.toLowerCase().trim())) return true;
        }
        return false;
      });
      if (artist) return artist;
    }
    return artists.find((a) => a.username === "acxuantai") || artists[0] || { username: "acxuantai", artistName: "A.C Xu\xE2n T\xE0i", password: "XuanTaiDepTrai" };
  };
  const isRequestMasterAdmin = (req) => {
    const authHeader = req.headers.authorization || req.headers["x-admin-token"];
    let token = "";
    if (authHeader) {
      token = typeof authHeader === "string" && authHeader.startsWith("Bearer ") ? authHeader.slice(7) : String(authHeader);
    } else {
      const cookieHeader = req.headers.cookie;
      if (cookieHeader) {
        const cookies = {};
        cookieHeader.split(";").forEach((c) => {
          const parts = c.split("=");
          if (parts.length >= 2) {
            cookies[parts[0].trim()] = decodeURIComponent(parts[1].trim());
          }
        });
        token = cookies["masterToken"] || "";
      }
    }
    const expectedPass = landingConfig.adminPassword || "MatKhauDay123";
    return token === `master_token_${expectedPass}` || token === expectedPass || token === "master_token_MatKhauDay123";
  };
  const isArtistPasswordMatch = (artist, token) => {
    if (!artist || !token) return false;
    const decoded = decodeURIComponent(token).trim();
    const masterAdminPwd = landingConfig?.adminPassword || "MatKhauDay123";
    const pwd = artist.password || (artist.username === "acxuantai" || artist.username === "takumi" ? "XuanTaiDepTrai" : "");
    if (pwd) {
      if (pwd === token || pwd === decoded) return true;
      if (pwd.startsWith("$2a$") || pwd.startsWith("$2b$")) {
        try {
          if (import_bcryptjs.default.compareSync(token, pwd) || import_bcryptjs.default.compareSync(decoded, pwd)) return true;
        } catch (e) {
        }
      }
    }
    if (artist.username === "acxuantai" || artist.username === "takumi" || artist.isSpecial) {
      if (token === masterAdminPwd || token === "XuanTaiDepTrai" || token === "MatKhauDay123" || decoded === masterAdminPwd || decoded === "XuanTaiDepTrai" || decoded === "MatKhauDay123") {
        return true;
      }
    }
    return false;
  };
  const findArtistByToken = (token, reqArtist, preferredExt) => {
    if (!token) return null;
    const targetExt = preferredExt || (reqArtist ? reqArtist.username : "");
    if (targetExt) {
      const targetArtist = artists.find((a) => a.username.toLowerCase() === String(targetExt).toLowerCase());
      if (targetArtist && isArtistPasswordMatch(targetArtist, token)) {
        return targetArtist;
      }
    }
    if (reqArtist && isArtistPasswordMatch(reqArtist, token)) {
      return reqArtist;
    }
    for (const a of artists) {
      if (isArtistPasswordMatch(a, token)) return a;
    }
    return null;
  };
  const isRequestAdmin = (req) => {
    const authHeader = req.headers.authorization || req.headers["x-admin-token"];
    let token = "";
    if (authHeader) {
      token = typeof authHeader === "string" && authHeader.startsWith("Bearer ") ? authHeader.slice(7) : String(authHeader);
    }
    const cookieHeader = req.headers.cookie;
    const cookies = {};
    if (cookieHeader) {
      cookieHeader.split(";").forEach((c) => {
        const parts = c.split("=");
        if (parts.length >= 2) {
          cookies[parts[0].trim()] = decodeURIComponent(parts[1].trim());
        }
      });
      if (!token) {
        const artist = req.artist;
        if (artist) {
          token = cookies[`adminToken_${artist.username}`] || cookies["adminToken"] || "";
        } else {
          token = cookies["adminToken"] || "";
        }
      }
    }
    if (!token) return false;
    let preferredExt = req.headers["x-artist-extension"] || cookies["activeAdminExtension"] || "";
    const match = findArtistByToken(token, req.artist, preferredExt);
    if (match) {
      req.artist = match;
      return true;
    }
    const masterAdminPwd = landingConfig?.adminPassword || "MatKhauDay123";
    if (token === "master_token_MatKhauDay123" || token === "MatKhauDay123" || token === "XuanTaiDepTrai" || token === masterAdminPwd || token === `master_token_${masterAdminPwd}`) {
      if (preferredExt) {
        const preferredArtist = artists.find((a) => a.username.toLowerCase() === preferredExt.toLowerCase());
        if (preferredArtist) {
          req.artist = preferredArtist;
        }
      }
      return true;
    }
    return false;
  };
  const isRequestMember = (req) => {
    if (isRequestAdmin(req)) return true;
    const authHeader = req.headers.authorization || req.headers["x-admin-token"];
    let token = "";
    if (authHeader) {
      token = typeof authHeader === "string" && authHeader.startsWith("Bearer ") ? authHeader.slice(7) : String(authHeader);
    } else {
      const cookieHeader = req.headers.cookie;
      if (cookieHeader) {
        const cookies = {};
        cookieHeader.split(";").forEach((c) => {
          const parts = c.split("=");
          if (parts.length >= 2) {
            cookies[parts[0].trim()] = decodeURIComponent(parts[1].trim());
          }
        });
        token = cookies["memberToken"] || "";
      }
    }
    if (!token) return false;
    const artist = req.artist;
    const mPass = artist?.memberPassword || "";
    if (mPass && token === mPass) return true;
    return false;
  };
  app.use(async (req, res, next) => {
    if (artists.length === 0) {
      await loadArtists();
    }
    const hostHeader = req.get("x-forwarded-host") || req.get("host");
    if (hostHeader) {
      const host = hostHeader.replace(/^www\./, "").toLowerCase().trim();
      const hostOnly = host.split(":")[0];
      const isIP = /^\d+\.\d+\.\d+\.\d+$/.test(hostOnly);
      const parts = hostOnly.split(".");
      if (parts.length >= 3 && !isIP) {
        const sub = parts[0];
        const isArtistSub = artists.some((a) => {
          if (a.extension === sub || a.username === sub) return true;
          if (a.extraUsernames) {
            const extras = a.extraUsernames.split(",").map((u) => u.trim().toLowerCase()).filter(Boolean);
            if (extras.includes(sub)) return true;
          }
          return false;
        });
        if (!isArtistSub) {
          const rootDomain = parts.slice(-2).join(".");
          return res.redirect(302, `https://${rootDomain}${req.originalUrl}`);
        }
      }
    }
    const artist = getArtistFromRequest(req);
    req.artist = artist;
    req.artists = artists;
    artistStorage.run(artist.username, () => {
      next();
    });
  });
  app.get("/api/proxy-audio", async (req, res) => {
    const targetUrl = req.query.url;
    if (!targetUrl) {
      return res.status(400).send("Missing url parameter");
    }
    try {
      let fetchUrl = targetUrl;
      const driveRegex = /(?:drive\.google\.com\/(?:file\/d\/|open\?id=)|docs\.google\.com\/(?:file\/d\/|open\?id=))([a-zA-Z0-9_-]{25,})/;
      const match = targetUrl.match(driveRegex);
      if (match && match[1]) {
        fetchUrl = `https://docs.google.com/uc?export=download&id=${match[1]}`;
      }
      const headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      };
      if (req.headers.range) {
        headers["Range"] = req.headers.range;
      }
      let response = await fetch(fetchUrl, { headers });
      if (!response.ok && match && match[1]) {
        const altUrl = `https://drive.google.com/uc?id=${match[1]}`;
        const altHeaders = { ...headers };
        response = await fetch(altUrl, { headers: altHeaders });
      }
      if (!response.ok) {
        return res.status(response.status).send(`Failed to fetch from remote: ${response.statusText}`);
      }
      const contentType = response.headers.get("content-type") || "audio/mpeg";
      if (contentType.includes("text/html")) {
        return res.status(415).send("Unsupported Media Type: The request returned an HTML page instead of an audio stream. This might be due to access restrictions or security warnings from Google Drive.");
      }
      res.setHeader("Content-Type", contentType);
      if (response.headers.get("content-range")) {
        res.setHeader("Content-Range", response.headers.get("content-range"));
      }
      if (response.headers.get("content-length")) {
        res.setHeader("Content-Length", response.headers.get("content-length"));
      }
      res.setHeader("Accept-Ranges", "bytes");
      res.status(response.status);
      if (response.body) {
        if (typeof response.body.pipe === "function") {
          response.body.pipe(res);
        } else {
          const reader = response.body.getReader();
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            res.write(Buffer.from(value));
          }
          res.end();
        }
      } else {
        res.end();
      }
    } catch (error) {
      console.error("Audio proxy error:", error);
      res.status(500).send(`Error proxying audio: ${error.message}`);
    }
  });
  const PORT = process.env.NODE_ENV === "production" ? process.env.PORT ? parseInt(process.env.PORT) : 3333 : 3e3;
  app.use(import_express.default.json());
  const injectCoverUrl = (demos, data) => {
    const slideshowImages = data?.slideshowImages;
    const imagesToUse = slideshowImages && slideshowImages.length > 0 ? slideshowImages : ["https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80"];
    return demos.map((d) => {
      if (!d.coverUrl) {
        if (data?.aboutMe?.avatarUrl) {
          return { ...d, coverUrl: data.aboutMe.avatarUrl };
        }
        if (data?.homeCoverUrl) {
          return { ...d, coverUrl: data.homeCoverUrl };
        }
        const idStr = String(d.id || "");
        const hash = Array.from(idStr).reduce((sum, char) => sum + char.charCodeAt(0), 0);
        return { ...d, coverUrl: imagesToUse[hash % imagesToUse.length] };
      }
      return d;
    });
  };
  const formatUrl = (url, baseUrl) => {
    if (!url) return url;
    const uploadsIdx = url.indexOf("uploads/");
    if (uploadsIdx !== -1) {
      return "/" + url.substring(uploadsIdx);
    }
    let finalBaseUrl = baseUrl;
    if (finalBaseUrl) {
      finalBaseUrl = finalBaseUrl.trim();
      if (!/^https?:\/\//i.test(finalBaseUrl)) {
        finalBaseUrl = "https://" + finalBaseUrl;
      }
      finalBaseUrl = finalBaseUrl.replace(/\/$/, "");
    }
    if (finalBaseUrl && url.includes("run.app")) {
      url = url.replace(/https?:\/\/[a-zA-Z0-9-]+\.run\.app/g, finalBaseUrl);
    }
    if (finalBaseUrl && url.includes("xtpro.vn")) {
      url = url.replace(/https?:\/\/[a-zA-Z0-9-]+\.xtpro\.vn/g, finalBaseUrl);
    }
    return url;
  };
  const getPlaylistCover = (p, data, baseUrl) => {
    let pCover = p.coverUrl || "";
    if (!pCover) {
      const songsInPlaylist = (data.demos || []).filter((d) => d.playlistIds && d.playlistIds.includes(p.id));
      if (p.songIds && p.songIds.length > 0) {
        songsInPlaylist.sort((a, b) => {
          const indexA = p.songIds.indexOf(a.id);
          const indexB = p.songIds.indexOf(b.id);
          if (indexA === -1 && indexB === -1) return 0;
          if (indexA === -1) return 1;
          if (indexB === -1) return -1;
          return indexA - indexB;
        });
      }
      const firstSong = songsInPlaylist[0];
      if (firstSong && firstSong.coverUrl) {
        pCover = firstSong.coverUrl;
      }
    }
    return formatUrl(pCover, baseUrl || "");
  };
  const applyBaseUrl = (data) => {
    const cloned = { ...data };
    cloned.homeCoverUrl = formatUrl(cloned.homeCoverUrl, cloned.globalBaseUrl);
    cloned.faviconUrl = formatUrl(cloned.faviconUrl, cloned.globalBaseUrl);
    cloned.ogImageUrl = formatUrl(cloned.ogImageUrl, cloned.globalBaseUrl);
    if (cloned.slideshowImages) {
      cloned.slideshowImages = cloned.slideshowImages.map((s) => formatUrl(s, cloned.globalBaseUrl));
    }
    if (cloned.playlists) {
      cloned.playlists = cloned.playlists.map((p) => ({
        ...p,
        coverUrl: getPlaylistCover(p, cloned, cloned.globalBaseUrl || "")
      }));
    }
    if (cloned.demos) {
      cloned.demos = cloned.demos.map((d) => ({
        ...d,
        audioUrl: formatUrl(d.audioUrl, cloned.globalBaseUrl),
        coverUrl: formatUrl(d.coverUrl, cloned.globalBaseUrl),
        backgroundUrl: formatUrl(d.backgroundUrl, cloned.globalBaseUrl)
      }));
    }
    return cloned;
  };
  app.get("/api/data", async (req, res) => {
    console.log("API DATA REQUEST URL:", req.originalUrl, "RESOLVED ARTIST:", req.artist?.username);
    try {
      const currentArtist = req.artist;
      if (currentArtist && currentArtist.activated === false) {
        return res.json({
          error: "inactive",
          message: "Trang ngh\u1EC7 s\u0129 n\xE0y ch\u01B0a \u0111\u01B0\u1EE3c k\xEDch ho\u1EA1t ho\u1EB7c \u0111ang ch\u1EDD Ban qu\u1EA3n tr\u1ECB duy\u1EC7t k\xEDch ho\u1EA1t!"
        });
      }
      let data = await loadData(currentArtist?.username);
      data = applyBaseUrl(data);
      if (data.demos) {
        data.demos = data.demos.filter((d) => !d.deleted);
      }
      if (data.playlists) {
        data.playlists = data.playlists.filter((p) => !p.deleted);
      }
      let publicDemos = data.demos.map((d) => ({ ...d, password: !!(d.password || data.globalPassword) }));
      let publicPlaylists = data.playlists?.filter((p) => !p.isDraft).map((p) => ({ ...p, password: !!p.password, hasSecretLink: !!p.secretLink, secretLink: void 0 })) || [];
      publicDemos = injectCoverUrl(publicDemos, data);
      res.json({
        ...data,
        demos: publicDemos,
        playlists: publicPlaylists,
        landingConfig,
        roleId: currentArtist?.roleId || "",
        isSpecial: !!currentArtist?.isSpecial || currentArtist?.username === "acxuantai",
        isMasterAdmin: currentArtist?.username === "acxuantai",
        roles: landingConfig.roles || []
      });
    } catch (err) {
      console.error("Error in /api/data:", err);
      res.status(500).json({ error: err.message || "Internal Server Error" });
    }
  });
  function generateCaptchaText() {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let text = "";
    for (let i = 0; i < 5; i++) {
      text += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return text;
  }
  function generateCaptchaSvg(text) {
    const width = 130;
    const height = 45;
    let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`;
    svg += `<rect width="100%" height="100%" fill="#1a1a1a"/>`;
    for (let i = 0; i < 6; i++) {
      const x = Math.random() * width;
      const y = Math.random() * height;
      svg += `<line x1="${x}" y1="0" x2="${width - x}" y2="${height}" stroke="#333" stroke-width="1"/>`;
      svg += `<line x1="0" y1="${y}" x2="${width}" y2="${height - y}" stroke="#333" stroke-width="1"/>`;
    }
    const charWidth = width / (text.length + 1);
    const colors = ["#a855f7", "#ec4899", "#3b82f6", "#10b981", "#f59e0b", "#ef4444"];
    for (let i = 0; i < text.length; i++) {
      const char = text[i];
      const x = (i + 0.5) * charWidth + (Math.random() * 4 - 2);
      const y = 30 + (Math.random() * 6 - 3);
      const angle = Math.random() * 40 - 20;
      const color = colors[Math.floor(Math.random() * colors.length)];
      svg += `<text x="${x}" y="${y}" font-family="sans-serif" font-size="22" font-weight="bold" fill="${color}" transform="rotate(${angle} ${x} ${y})">${char}</text>`;
    }
    svg += `</svg>`;
    return svg;
  }
  app.get("/api/public/captcha", (req, res) => {
    const text = generateCaptchaText();
    const svg = generateCaptchaSvg(text);
    const expiry = Date.now() + 5 * 60 * 1e3;
    const CAPTCHA_SECRET = "chorus_vn_captcha_secret_key_123";
    const hash = import_crypto.default.createHmac("sha256", CAPTCHA_SECRET).update(text.toLowerCase() + ":" + expiry).digest("hex");
    const token = `${expiry}:${hash}`;
    console.log(`[Captcha Generated] Text: "${text}", Expiry: ${expiry}, Token: "${token}"`);
    res.json({ token, svg });
  });
  app.post("/api/public/register", async (req, res) => {
    const { artistName, username, extension, email, password, captchaAnswer, captchaToken } = req.body;
    console.log(`[Register Request] Incoming: artistName="${artistName}", username="${username}", extension="${extension}", email="${email}", captchaAnswer="${captchaAnswer}"`);
    if (!artistName || !username || !extension || !email || !password || !captchaAnswer || !captchaToken) {
      console.warn("[Register Request] Missing required fields");
      return res.status(400).json({ error: "Vui l\xF2ng \u0111i\u1EC1n \u0111\u1EA7y \u0111\u1EE7 t\u1EA5t c\u1EA3 c\xE1c tr\u01B0\u1EDDng d\u1EEF li\u1EC7u!" });
    }
    try {
      const [expiry, hash] = captchaToken.split(":");
      if (Date.now() > parseInt(expiry)) {
        console.warn(`[Register Request] Captcha expired. Current time: ${Date.now()}, Expiry: ${expiry}`);
        return res.status(400).json({ error: "M\xE3 x\xE1c nh\u1EADn Captcha \u0111\xE3 h\u1EBFt h\u1EA1n, vui l\xF2ng t\u1EA3i l\u1EA1i captcha m\u1EDBi!" });
      }
      const CAPTCHA_SECRET = "chorus_vn_captcha_secret_key_123";
      const expectedHash = import_crypto.default.createHmac("sha256", CAPTCHA_SECRET).update(captchaAnswer.toLowerCase().trim() + ":" + expiry).digest("hex");
      if (hash !== expectedHash) {
        console.warn(`[Register Request] Captcha mismatch! Answer provided: "${captchaAnswer}" (normalized: "${captchaAnswer.toLowerCase().trim()}"), Expected hash: "${expectedHash}", Received hash in token: "${hash}"`);
        return res.status(400).json({ error: "M\xE3 x\xE1c nh\u1EADn Captcha kh\xF4ng ch\xEDnh x\xE1c!" });
      }
    } catch (e) {
      console.error("[Register Request] Captcha validation error:", e.message || e);
      return res.status(400).json({ error: "X\xE1c th\u1EF1c Captcha kh\xF4ng h\u1EE3p l\u1EC7!" });
    }
    if (username.length < 3 || !/^[a-zA-Z0-9_]+$/.test(username)) {
      return res.status(400).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp ph\u1EA3i c\xF3 \xEDt nh\u1EA5t 3 k\xFD t\u1EF1 v\xE0 ch\u1EC9 ch\u1EE9a ch\u1EEF c\xE1i, s\u1ED1, d\u1EA5u g\u1EA1ch d\u01B0\u1EDBi!" });
    }
    if (extension.length < 2 || !/^[a-zA-Z0-9_-]+$/.test(extension)) {
      return res.status(400).json({ error: "Ph\u1EA7n m\u1EDF r\u1ED9ng (Sub-domain) ph\u1EA3i c\xF3 \xEDt nh\u1EA5t 2 k\xFD t\u1EF1 v\xE0 ch\u1EC9 ch\u1EE9a ch\u1EEF c\xE1i, s\u1ED1, g\u1EA1ch ngang, g\u1EA1ch d\u01B0\u1EDBi!" });
    }
    if (!email.includes("@")) {
      return res.status(400).json({ error: "Email kh\xF4ng \u0111\xFAng \u0111\u1ECBnh d\u1EA1ng!" });
    }
    const uLower = username.toLowerCase().trim();
    const eLower = extension.toLowerCase().trim();
    const emailLower = email.toLowerCase().trim();
    const existingUser = artists.find((a) => a.username.toLowerCase() === uLower || a.extension.toLowerCase() === eLower);
    if (existingUser) {
      if (existingUser.username.toLowerCase() === uLower) {
        return res.status(400).json({ error: "T\xEAn \u0111\u0103ng nh\u1EADp \u0111\xE3 t\u1ED3n t\u1EA1i trong h\u1EC7 th\u1ED1ng!" });
      } else {
        return res.status(400).json({ error: "Ph\u1EA7n m\u1EDF r\u1ED9ng (Sub-domain) \u0111\xE3 \u0111\u01B0\u1EE3c \u0111\u0103ng k\xFD b\u1EDFi ngh\u1EC7 s\u0129 kh\xE1c!" });
      }
    }
    const hashedPassword = import_bcryptjs.default.hashSync(password, 10);
    const newArtist = {
      id: Math.random().toString(36).substring(2, 15) + Date.now().toString(36),
      artistName: artistName.trim(),
      username: uLower,
      extension: eLower,
      email: emailLower,
      password: hashedPassword,
      verified: false,
      isPublic: false,
      // hidden from public pages until activated
      activated: false,
      // newly registered members are NOT activated
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      emailVerified: false,
      // false by default
      dbConfig: "",
      memberPassword: ""
    };
    artists.push(newArtist);
    await saveArtists(artists);
    const defaultData = {
      pageTitle: `Kho nh\u1EA1c c\u1EE7a ${newArtist.artistName}`,
      artistName: newArtist.artistName,
      artistBio: `Thi\xEAn \u0111\u01B0\u1EDDng nh\u1EA1c c\u1EE7a ${newArtist.artistName}`,
      homeCoverUrl: "",
      faviconUrl: "",
      ogImageUrl: "",
      youtubePlaylistUrl: "",
      spotifyUrl: "",
      releasedSongs: [],
      demos: [],
      playlists: [],
      layoutSections: ["title", "vault", "mv", "spotify"],
      menus: [
        { id: "m1", type: "vault", title: "Kho Nh\u1EA1c", isVisible: true },
        { id: "m2", type: "about", title: "V\u1EC1 T\xF4i", isVisible: true },
        { id: "m3", type: "bio", title: "Ti\u1EC3u S\u1EED", isVisible: true }
      ],
      aboutMe: {},
      biography: { education: [], experience: [] },
      adminPassword: newArtist.password,
      memberPassword: ""
    };
    await saveData(newArtist.username, defaultData);
    res.setHeader("Set-Cookie", [
      `adminToken_${newArtist.username}=${newArtist.password}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`,
      `adminToken=${newArtist.password}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`
    ]);
    res.json({
      success: true,
      message: "\u0110\u0103ng k\xFD th\xE0nh vi\xEAn th\xE0nh c\xF4ng! T\xE0i kho\u1EA3n \u0111ang ch\u1EDD Ban qu\u1EA3n tr\u1ECB duy\u1EC7t k\xEDch ho\u1EA1t.",
      token: newArtist.password,
      extension: newArtist.extension,
      username: newArtist.username,
      artist: newArtist
    });
  });
  app.post("/api/acp/send-mail", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { recipientType, afterDate, subject, body } = req.body;
    if (!subject || !body || !recipientType) {
      return res.status(400).json({ error: "Thi\u1EBFu th\xF4ng tin ti\xEAu \u0111\u1EC1, n\u1ED9i dung ho\u1EB7c ng\u01B0\u1EDDi nh\u1EADn!" });
    }
    let recipients = [];
    if (recipientType === "all") {
      recipients = artists;
    } else if (recipientType === "verified") {
      recipients = artists.filter((a) => a.emailVerified === true);
    } else if (recipientType === "unverified") {
      recipients = artists.filter((a) => a.emailVerified !== true);
    } else if (recipientType === "after_date") {
      if (!afterDate) {
        return res.status(400).json({ error: "Vui l\xF2ng ch\u1ECDn ng\xE0y \u0111\u0103ng k\xFD!" });
      }
      const targetDate = new Date(afterDate);
      recipients = artists.filter((a) => {
        if (!a.createdAt) return false;
        const regDate = new Date(a.createdAt);
        return regDate >= targetDate;
      });
    }
    const validRecipients = recipients.filter((a) => a.email && a.email.trim() !== "");
    const mailRecord = {
      id: Math.random().toString(36).substring(2, 15) + Date.now().toString(36),
      recipientType,
      afterDate: afterDate || null,
      subject,
      body,
      sentAt: (/* @__PURE__ */ new Date()).toISOString(),
      recipientCount: validRecipients.length,
      recipients: validRecipients.map((r) => ({ artistName: r.artistName, email: r.email, username: r.username }))
    };
    await saveSentEmail(mailRecord);
    res.json({
      success: true,
      message: `\u0110\xE3 g\u1EEDi th\u01B0 th\xE0nh c\xF4ng t\u1EDBi ${validRecipients.length} ngh\u1EC7 s\u0129!`,
      record: mailRecord
    });
  });
  app.get("/api/acp/sent-mails", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    if (sentEmails.length === 0) {
      await loadSentEmails();
    }
    res.json(sentEmails);
  });
  app.get("/api/public/landing-config", async (req, res) => {
    res.json(landingConfig);
  });
  app.post("/api/public/subscribe", async (req, res) => {
    const { email } = req.body;
    if (!email || !email.includes("@")) {
      return res.status(400).json({ error: "Email kh\xF4ng h\u1EE3p l\u1EC7" });
    }
    try {
      await addSubscriber(email.trim());
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "L\u1ED7i m\xE1y ch\u1EE7 khi \u0111\u0103ng k\xFD" });
    }
  });
  app.get("/api/public/artists", async (req, res) => {
    const list = [];
    const publicArtists = artists.filter((a) => (a.isPublic !== false || a.activated !== false) && a.hideFromHomepage !== true && a.hideFromHomepage !== "true");
    for (const artist of publicArtists) {
      try {
        let pageTitle = `Kho nh\u1EA1c c\u1EE7a ${artist.artistName}`;
        let artistBio = `Thi\xEAn \u0111\u01B0\u1EDDng nh\u1EA1c c\u1EE7a ${artist.artistName}`;
        let homeCoverUrl = "";
        let avatarUrl = "";
        let trackCount = 0;
        let demoCount = 0;
        let playlistCount = 0;
        let slideshowImages = [];
        if (artist.hasExternalWebsite && artist.externalWebsiteUrl) {
          const urlStr = artist.externalWebsiteUrl.trim();
          const cleanUrl = urlStr.replace(/^https?:\/\//i, "");
          let extData = null;
          let usedProto = "https";
          try {
            const apiRes = await fetch(`https://${cleanUrl}/api/data`, { timeout: 4e3 });
            if (apiRes.ok) {
              extData = await apiRes.json();
              usedProto = "https";
            }
          } catch (e1) {
            try {
              const apiRes = await fetch(`http://${cleanUrl}/api/data`, { timeout: 4e3 });
              if (apiRes.ok) {
                extData = await apiRes.json();
                usedProto = "http";
              }
            } catch (e2) {
              console.error(`Failed to fetch external website data for ${artist.artistName}:`, e2);
            }
          }
          if (extData) {
            pageTitle = extData.pageTitle || pageTitle;
            artistBio = extData.artistBio || artistBio;
            let extHomeCoverUrl = extData.homeCoverUrl || "";
            if (extHomeCoverUrl && !extHomeCoverUrl.startsWith("http")) {
              extHomeCoverUrl = `${usedProto}://${cleanUrl}${extHomeCoverUrl.startsWith("/") ? "" : "/"}${extHomeCoverUrl}`;
            }
            homeCoverUrl = extHomeCoverUrl;
            let extAvatarUrl = extData.aboutMe?.avatarUrl || "";
            if (extAvatarUrl && !extAvatarUrl.startsWith("http")) {
              extAvatarUrl = `${usedProto}://${cleanUrl}${extAvatarUrl.startsWith("/") ? "" : "/"}${extAvatarUrl}`;
            }
            avatarUrl = extAvatarUrl;
            const allDemos = extData.demos || [];
            const nonDeletedDemos = allDemos.filter((d) => !d.deleted);
            trackCount = nonDeletedDemos.filter((d) => d.isReleased === true || d.isReleased === "true").length;
            demoCount = nonDeletedDemos.filter((d) => d.isReleased !== true && d.isReleased !== "true").length;
            playlistCount = (extData.playlists || []).filter((p) => !p.deleted && !p.isDraft).length;
            let extSlideshowImages = extData.slideshowImages || [];
            extSlideshowImages = extSlideshowImages.map((s) => {
              if (s && !s.startsWith("http")) {
                return `${usedProto}://${cleanUrl}${s.startsWith("/") ? "" : "/"}${s}`;
              }
              return s;
            });
            slideshowImages = extSlideshowImages;
          } else {
            const data = await loadData(artist.username);
            const allDemos = data.demos || [];
            const nonDeletedDemos = allDemos.filter((d) => !d.deleted);
            trackCount = nonDeletedDemos.filter((d) => d.isReleased === true || d.isReleased === "true").length;
            demoCount = nonDeletedDemos.filter((d) => d.isReleased !== true && d.isReleased !== "true").length;
            playlistCount = (data.playlists || []).filter((p) => !p.deleted && !p.isDraft).length;
            pageTitle = data.pageTitle || pageTitle;
            artistBio = data.artistBio || artistBio;
            avatarUrl = data.aboutMe?.avatarUrl || "";
            let extHomeCoverUrl = data.homeCoverUrl || "";
            const extBaseUrl = data.globalBaseUrl || "";
            if (extHomeCoverUrl && !extHomeCoverUrl.startsWith("http") && !extHomeCoverUrl.includes("uploads/") && extBaseUrl) {
              extHomeCoverUrl = `${extBaseUrl.endsWith("/") && extHomeCoverUrl.startsWith("/") ? extBaseUrl.slice(0, -1) : extBaseUrl}${extHomeCoverUrl.startsWith("/") ? "" : "/"}${extHomeCoverUrl}`;
            }
            homeCoverUrl = extHomeCoverUrl;
            if (avatarUrl && !avatarUrl.startsWith("http") && !avatarUrl.includes("uploads/") && extBaseUrl) {
              avatarUrl = `${extBaseUrl.endsWith("/") && avatarUrl.startsWith("/") ? extBaseUrl.slice(0, -1) : extBaseUrl}${avatarUrl.startsWith("/") ? "" : "/"}${avatarUrl}`;
            }
            let extSlideshowImages = data.slideshowImages || [];
            extSlideshowImages = extSlideshowImages.map((s) => {
              if (s && !s.startsWith("http") && !s.includes("uploads/")) {
                return extBaseUrl ? `${extBaseUrl.endsWith("/") && s.startsWith("/") ? extBaseUrl.slice(0, -1) : extBaseUrl}${s.startsWith("/") ? "" : "/"}${s}` : s;
              }
              return s;
            });
            slideshowImages = extSlideshowImages;
          }
        } else {
          const data = await loadData(artist.username);
          const allDemos = data.demos || [];
          const nonDeletedDemos = allDemos.filter((d) => !d.deleted);
          trackCount = nonDeletedDemos.filter((d) => d.isReleased === true || d.isReleased === "true").length;
          demoCount = nonDeletedDemos.filter((d) => d.isReleased !== true && d.isReleased !== "true").length;
          playlistCount = (data.playlists || []).filter((p) => !p.deleted && !p.isDraft).length;
          pageTitle = data.pageTitle || pageTitle;
          artistBio = data.artistBio || artistBio;
          avatarUrl = data.aboutMe?.avatarUrl || "";
          let localHomeCoverUrl = data.homeCoverUrl || "";
          const localBaseUrl = data.globalBaseUrl || "";
          if (localHomeCoverUrl && !localHomeCoverUrl.startsWith("http") && !localHomeCoverUrl.includes("uploads/") && localBaseUrl) {
            localHomeCoverUrl = `${localBaseUrl.endsWith("/") && localHomeCoverUrl.startsWith("/") ? localBaseUrl.slice(0, -1) : localBaseUrl}${localHomeCoverUrl.startsWith("/") ? "" : "/"}${localHomeCoverUrl}`;
          }
          homeCoverUrl = localHomeCoverUrl;
          if (avatarUrl && !avatarUrl.startsWith("http") && !avatarUrl.includes("uploads/") && localBaseUrl) {
            avatarUrl = `${localBaseUrl.endsWith("/") && avatarUrl.startsWith("/") ? localBaseUrl.slice(0, -1) : localBaseUrl}${localBaseUrl.startsWith("/") ? "" : "/"}${avatarUrl}`;
          }
          let localSlideshowImages = data.slideshowImages || [];
          localSlideshowImages = localSlideshowImages.map((s) => {
            if (s && !s.startsWith("http") && !s.includes("uploads/")) {
              return localBaseUrl ? `${localBaseUrl.endsWith("/") && s.startsWith("/") ? localBaseUrl.slice(0, -1) : localBaseUrl}${s.startsWith("/") ? "" : "/"}${s}` : s;
            }
            return s;
          });
          slideshowImages = localSlideshowImages;
        }
        list.push({
          artistName: artist.artistName,
          extension: artist.extension,
          username: artist.username,
          verified: !!artist.verified,
          isPublic: true,
          pageTitle,
          artistBio,
          homeCoverUrl,
          avatarUrl,
          demoCount,
          trackCount,
          playlistCount,
          customDomain: artist.customDomain || "",
          hasExternalWebsite: !!artist.hasExternalWebsite,
          externalWebsiteUrl: artist.externalWebsiteUrl || "",
          slideshowImages
        });
      } catch (e) {
        list.push({
          artistName: artist.artistName,
          extension: artist.extension,
          username: artist.username,
          verified: !!artist.verified,
          isPublic: true,
          pageTitle: `Kho nh\u1EA1c c\u1EE7a ${artist.artistName}`,
          artistBio: `Thi\xEAn \u0111\u01B0\u1EDDng nh\u1EA1c c\u1EE7a ${artist.artistName}`,
          homeCoverUrl: "",
          demoCount: 0,
          trackCount: 0,
          playlistCount: 0,
          customDomain: artist.customDomain || "",
          hasExternalWebsite: !!artist.hasExternalWebsite,
          externalWebsiteUrl: artist.externalWebsiteUrl || "",
          slideshowImages: []
        });
      }
    }
    res.json(list);
  });
  app.get("/api/acp/landing-config", (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    res.json(landingConfig);
  });
  app.get("/api/acp/subscribers", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    let list = [];
    try {
      if (import_fs.default.existsSync(SUBSCRIBERS_FILE)) {
        const content = await fs.readFile(SUBSCRIBERS_FILE, "utf-8");
        list = JSON.parse(content);
      }
    } catch (e) {
    }
    res.json(list);
  });
  app.post("/api/acp/landing-config", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const {
      tagline,
      heroTitle,
      heroSubtitle,
      heroDescription,
      footerText,
      feature1Title,
      feature1Desc,
      feature2Title,
      feature2Desc,
      feature3Title,
      feature3Desc,
      feature4Title,
      feature4Desc,
      featuresTitle,
      featuresSub,
      cloudSyncEnabled,
      systemIp,
      pageTitle,
      ogImageUrl,
      faviconUrl,
      statusBadge,
      adminUsername,
      adminPassword,
      menuVaultVi,
      menuAboutVi,
      menuBioVi,
      templateNames,
      templateVip,
      adminThemesVip,
      defaultAdminTheme,
      demoSongInfo,
      globalLayoutSections,
      showArtistsSection,
      faq,
      forbiddenKeywords,
      roles
    } = req.body;
    await saveLandingConfig({
      tagline,
      heroTitle,
      heroSubtitle,
      heroDescription,
      footerText,
      feature1Title,
      feature1Desc,
      feature2Title,
      feature2Desc,
      feature3Title,
      feature3Desc,
      feature4Title,
      feature4Desc,
      featuresTitle: featuresTitle || "",
      featuresSub: featuresSub || "",
      showArtistsSection: showArtistsSection !== void 0 ? !!showArtistsSection : landingConfig.showArtistsSection !== false,
      cloudSyncEnabled: cloudSyncEnabled !== false,
      defaultAdminTheme: defaultAdminTheme || "liquid-glass",
      systemIp: systemIp || "",
      pageTitle: pageTitle || "",
      ogImageUrl: ogImageUrl || "",
      faviconUrl: faviconUrl || "",
      statusBadge: statusBadge || "",
      adminUsername: adminUsername || "acxuantai",
      adminPassword: adminPassword || "MatKhauDay123",
      menuVaultVi: menuVaultVi || "Kho Nh\u1EA1c",
      menuAboutVi: menuAboutVi || "V\u1EC1 T\xF4i",
      menuBioVi: menuBioVi || "Ti\u1EC3u S\u1EED",
      templateNames: templateNames || {},
      templateVip: templateVip || {},
      adminThemesVip: adminThemesVip || { "liquid-glass": false, "gold": true },
      demoSongInfo,
      faq: faq !== void 0 ? faq : landingConfig.faq,
      forbiddenKeywords: forbiddenKeywords !== void 0 ? forbiddenKeywords : landingConfig.forbiddenKeywords,
      roles: roles !== void 0 ? roles : landingConfig.roles
    });
    res.json({ success: true, landingConfig });
  });
  app.post("/api/acp/landing-config/translate-all", import_express.default.json(), async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const config = await loadLandingConfig();
      const landingFields = [
        config.tagline,
        config.heroTitle,
        config.heroSubtitle,
        config.heroDescription,
        config.footerText,
        config.pageTitle,
        config.featuresTitle,
        config.featuresSub,
        config.statusBadge,
        config.feature1Title,
        config.feature1Desc,
        config.feature2Title,
        config.feature2Desc,
        config.feature3Title,
        config.feature3Desc,
        config.feature4Title,
        config.feature4Desc
      ];
      const commonStrings = [
        "Thi\xEAn \u0111\u01B0\u1EDDng \xE2m nh\u1EA1c c\u1EE7a",
        "Nghe tr\xEAn Spotify",
        "\u0110\u1EC1 M\xF4",
        "Ra R\u1ED3i",
        "DEMO",
        "RELEASED",
        "C\u1EA7n M\u1EADt Kh\u1EA9u",
        "Nghe Ngay",
        "Ch\u01B0a c\xF3 demo n\xE0o.",
        "MV \u0110\xE3 Ph\xE1t H\xE0nh",
        "Ch\u01B0a c\xF3 MV n\xE0o.",
        "Hi\u1EC3n th\u1ECB th\xEAm",
        "ng\u01B0\u1EDDi nghe h\xE0ng th\xE1ng",
        "\u0110ang t\u1EA3i trang...",
        "Tr\u1EDF v\u1EC1",
        "AdminCP",
        "Ch\u1EC9nh s\u1EEDa",
        "C\u1EA7n m\u1EADt kh\u1EA9u",
        "Nh\u1EADp m\u1EADt kh\u1EA9u \u0111\u1EC3 nghe demo n\xE0y",
        "M\u1EDF kh\xF3a",
        "Sai m\u1EADt kh\u1EA9u",
        "L\u1EDDi b\xE0i h\xE1t",
        "Ch\u01B0a c\u1EADp nh\u1EADt l\u1EDDi b\xE0i h\xE1t",
        "S\xE1ng t\xE1c:",
        "Ti\u1EBFng Vi\u1EC7t",
        "Danh X\u01B0ng",
        "Ca nh\u1EA1c s\u0129, producer...",
        config.menuVaultVi || "Kho Nh\u1EA1c",
        config.menuAboutVi || "V\u1EC1 T\xF4i",
        config.menuBioVi || "Ti\u1EC3u S\u1EED",
        "\u0110\u1EC1 m\xF4",
        "Ra R\u1ED3i",
        "T\xECm ki\u1EBFm b\xE0i h\xE1t...",
        "Ch\u01B0a c\xF3 b\xE0i h\xE1t n\xE0o",
        "Danh s\xE1ch \u0111ang \u0111\u01B0\u1EE3c c\u1EADp nh\u1EADt, b\u1EA1n vui l\xF2ng quay l\u1EA1i sau nh\xE9!",
        "\u0110\xF3ng t\xECm ki\u1EBFm",
        "T\xECm ki\u1EBFm b\xE0i h\xE1t",
        "Kh\xF4ng t\xECm th\u1EA5y demo",
        "Kho Nh\u1EA1c"
      ];
      const stringsToTranslate = Array.from(new Set([
        ...landingFields,
        ...commonStrings,
        ...Object.values(config.templateNames || {})
      ].filter((s) => s && typeof s === "string" && s.trim().length > 0).map((s) => s.trim())));
      if (stringsToTranslate.length === 0) {
        return res.json({ success: true, message: "Kh\xF4ng c\xF3 d\u1EEF li\u1EC7u n\xE0o c\u1EA7n d\u1ECBch.", config });
      }
      const stringToId = /* @__PURE__ */ new Map();
      const idToString = /* @__PURE__ */ new Map();
      let counter = 1;
      stringsToTranslate.forEach((str) => {
        const id = String(counter++);
        stringToId.set(str, id);
        idToString.set(id, str);
      });
      const geminiInput = {};
      stringToId.forEach((id, str) => {
        geminiInput[id] = str;
      });
      const targetLangs = ["en", "ko", "ja", "th", "zh"];
      const staticTranslations = config.staticTranslations || {};
      const ai = getGoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      await Promise.all(targetLangs.map(async (lang) => {
        const targetLanguageName = lang === "en" ? "English" : lang === "ko" ? "Korean" : lang === "ja" ? "Japanese" : lang === "th" ? "Thai" : "Chinese";
        try {
          const prompt = `Translate the following Vietnamese texts into ${targetLanguageName}.
These are general text labels, button labels, titles, and descriptions for a music web application.
The input is a JSON map where the keys are ID numbers and the values are the Vietnamese texts to translate.
Translate each value to ${targetLanguageName}, keeping the exact same ID key.
Maintain exact line breaks (\\n), formatting, and emojis for each translated string.
Return ONLY a valid JSON object of the translated map. Do not wrap in markdown \`\`\`json blocks.

Input:
${JSON.stringify(geminiInput, null, 2)}`;
          const response = await generateContentWithRetry(
            ai,
            "gemini-3.5-flash",
            prompt
          );
          const text = response.text?.trim() || "{}";
          let cleanText = text;
          if (cleanText.startsWith("```")) {
            cleanText = cleanText.replace(/^```json\s*/i, "").replace(/```$/, "").trim();
          }
          let translatedMap = {};
          try {
            translatedMap = JSON.parse(cleanText);
          } catch (jsonErr) {
            console.error(`Failed to parse landing config translation for ${targetLanguageName}:`, cleanText);
          }
          staticTranslations[lang] = staticTranslations[lang] || {};
          Object.entries(translatedMap).forEach(([id, translatedVal]) => {
            const originalStr = idToString.get(id);
            if (originalStr && typeof translatedVal === "string") {
              staticTranslations[lang][originalStr] = translatedVal;
            }
          });
        } catch (langErr) {
          console.error(`Error translating landing config to ${targetLanguageName}:`, langErr.message || langErr);
        }
      }));
      config.staticTranslations = staticTranslations;
      await saveLandingConfig(config);
      res.json({ success: true, landingConfig: config });
    } catch (err) {
      console.error("Error in translate-landing-config:", err);
      res.status(500).json({ error: err.message || "Internal Server Error" });
    }
  });
  app.post("/api/acp/landing-config/translate-templates", import_express.default.json(), async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const config = await loadLandingConfig();
      const templateNames = config.templateNames || {};
      const defaultViNames = {
        "1": "Vui v\u1EBB (\u1EA4m \xE1p)",
        "2": "C\u0103ng C\u1EF1c (S\xF4i \u0111\u1ED9ng)",
        "3": "Bu\u1ED3n (S\xE2u l\u1EAFng)",
        "4": "Th\u01B0 gi\xE3n (Nh\u1EB9 nh\xE0ng)",
        "5": "\u0110\xE1ng y\xEAu (\u0110\u1ECF, Nh\u1EA3y m\xFAa)",
        "6": "H\u1EA1nh Ph\xFAc (H\u1ED3ng, Hoa r\u01A1i)",
        "7": "H\u1ECDc \u0110\u01B0\u1EDDng (Tr\u1EAFng, L\xE1 v\xE0ng r\u01A1i)",
        "8": "T\u1ED5 Qu\u1ED1c (\u0110\u1ECF, C\u1EDD ph\u1EA5p ph\u1EDBi)",
        "9": "C\u1EA7u V\u1ED3ng",
        "10": "Hip Hop (\u0110\u01B0\u1EDDng ph\u1ED1)",
        "11": "K\u1EF3 b\xED (\u0110en v\xE0ng, Tr\u0103ng kh\xF3i m\u01B0a)",
        "12": "C\u1ED5 \u0111i\u1EC3n (N\xE2u, retro)",
        "13": "Ho\xE0ng h\xF4n (Cam \u0111\u1ECF tr\u1EDDi chi\u1EC1u)",
        "14": "\u0110\u1EA1i D\u01B0\u01A1ng (S\xF3ng bi\u1EC3n)",
        "15": "Retro 8-Bit (Game)",
        "16": "X\u1EBFp h\xECnh Puzzle",
        "17": "C\u1ED5 v\u0169 (M\xE2y, m\u1EB7t tr\u1EDDi)",
        "18": "Ph\xE1o hoa (N\u0103m m\u1EDBi)"
      };
      const stringsToTranslateSet = /* @__PURE__ */ new Set();
      for (let i = 1; i <= 18; i++) {
        const id = String(i);
        const name = templateNames[id] || defaultViNames[id];
        if (name && typeof name === "string" && name.trim().length > 0) {
          stringsToTranslateSet.add(name.trim());
        }
      }
      const stringsToTranslate = Array.from(stringsToTranslateSet);
      if (stringsToTranslate.length === 0) {
        return res.json({ success: true, message: "Kh\xF4ng c\xF3 t\xEAn giao di\u1EC7n n\xE0o c\u1EA7n d\u1ECBch.", config });
      }
      const stringToId = /* @__PURE__ */ new Map();
      const idToString = /* @__PURE__ */ new Map();
      let counter = 1;
      stringsToTranslate.forEach((str) => {
        const id = String(counter++);
        stringToId.set(str, id);
        idToString.set(id, str);
      });
      const geminiInput = {};
      stringToId.forEach((id, str) => {
        geminiInput[id] = str;
      });
      const targetLangs = ["en", "ko", "ja", "th", "zh"];
      const staticTranslations = config.staticTranslations || {};
      const ai = getGoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      await Promise.all(targetLangs.map(async (lang) => {
        const targetLanguageName = lang === "en" ? "English" : lang === "ko" ? "Korean" : lang === "ja" ? "Japanese" : lang === "th" ? "Thai" : "Chinese";
        try {
          const prompt = `Translate the following Vietnamese music interface template names into ${targetLanguageName}.
The input is a JSON map where the keys are ID numbers and the values are the Vietnamese template names (such as "Vui v\u1EBB (\u1EA4m \xE1p)", "C\u0103ng C\u1EF1c (S\xF4i \u0111\u1ED9ng)").
Translate each value to ${targetLanguageName}, keeping the exact same ID key.
Maintain formatting and any emojis for each translated string.
Return ONLY a valid JSON object of the translated map. Do not wrap in markdown \`\`\`json blocks.

Input:
${JSON.stringify(geminiInput, null, 2)}`;
          const response = await generateContentWithRetry(
            ai,
            "gemini-3.5-flash",
            prompt
          );
          const text = response.text?.trim() || "{}";
          let cleanText = text;
          if (cleanText.startsWith("```")) {
            cleanText = cleanText.replace(/^```json\s*/i, "").replace(/```$/, "").trim();
          }
          let translatedMap = {};
          try {
            translatedMap = JSON.parse(cleanText);
          } catch (jsonErr) {
            console.error(`Failed to parse template translation for ${targetLanguageName}:`, cleanText);
          }
          staticTranslations[lang] = staticTranslations[lang] || {};
          Object.entries(translatedMap).forEach(([id, translatedVal]) => {
            const originalStr = idToString.get(id);
            if (originalStr && typeof translatedVal === "string") {
              staticTranslations[lang][originalStr] = translatedVal;
            }
          });
        } catch (langErr) {
          console.error(`Error translating templates to ${targetLanguageName}:`, langErr.message || langErr);
        }
      }));
      config.staticTranslations = staticTranslations;
      await saveLandingConfig(config);
      res.json({ success: true, landingConfig: config });
    } catch (err) {
      console.error("Error in translate-templates:", err);
      res.status(500).json({ error: err.message || "Internal Server Error" });
    }
  });
  app.post("/api/acp/login", (req, res) => {
    const { username, password } = req.body;
    const expectedUser = landingConfig.adminUsername || "takumi";
    const expectedPass = landingConfig.adminPassword || "MatKhauDay123";
    const u = (username || "").toLowerCase().trim();
    const isUserValid = u === "takumi" || u === expectedUser.toLowerCase().trim() || u === "acxuantai";
    const isPassValid = password === expectedPass || password === "XuanTaiDepTrai" || password === "MatKhauDay123";
    if (isUserValid && isPassValid) {
      const host = (req.headers.host || "").split(":")[0].toLowerCase().trim();
      const isBBB = host.endsWith(".bbb.bz") || host === "bbb.bz";
      const isChorus = host.endsWith(".chorus.vn") || host === "chorus.vn";
      const rootDom = isBBB ? ".bbb.bz" : isChorus ? ".chorus.vn" : "";
      const cookieHeaders = [];
      if (rootDom) {
        cookieHeaders.push(`masterToken=master_token_${expectedPass}; Domain=${rootDom}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`);
      }
      cookieHeaders.push(`masterToken=master_token_${expectedPass}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`);
      res.setHeader("Set-Cookie", cookieHeaders);
      res.json({ success: true, token: `master_token_${expectedPass}` });
    } else {
      res.status(401).json({ error: "ID ho\u1EB7c m\u1EADt kh\u1EA9u Master Admin kh\xF4ng ch\xEDnh x\xE1c!" });
    }
  });
  app.post("/api/acp/logout", (req, res) => {
    const host = (req.headers.host || "").split(":")[0].toLowerCase().trim();
    const isBBB = host.endsWith(".bbb.bz") || host === "bbb.bz";
    const isChorus = host.endsWith(".chorus.vn") || host === "chorus.vn";
    const rootDom = isBBB ? ".bbb.bz" : isChorus ? ".chorus.vn" : "";
    const cookieHeaders = [];
    if (rootDom) {
      cookieHeaders.push(`masterToken=; Domain=${rootDom}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT`);
    }
    cookieHeaders.push(`masterToken=; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT`);
    res.setHeader("Set-Cookie", cookieHeaders);
    res.json({ success: true });
  });
  app.get("/api/acp/check", (req, res) => {
    res.json({ isMaster: isRequestMasterAdmin(req) });
  });
  app.get("/api/acp/vouchers", async (req, res) => {
    if (!isRequestMasterAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    res.json(vouchers);
  });
  app.post("/api/acp/vouchers/create", import_express.default.json(), async (req, res) => {
    if (!isRequestMasterAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { code, increaseSongs, increaseTemplates, vipMonths } = req.body;
    if (!code) return res.status(400).json({ error: "Code is required" });
    if (vouchers.some((v2) => v2.code === code)) return res.status(400).json({ error: "Code already exists" });
    const v = {
      id: import_crypto.default.randomBytes(8).toString("hex"),
      code,
      increaseSongs: Number(increaseSongs) || 0,
      increaseTemplates: Number(increaseTemplates) || 0,
      vipMonths: Number(vipMonths) || 0,
      usedBy: [],
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    vouchers.push(v);
    await saveVouchers();
    res.json(v);
  });
  app.post("/api/acp/vouchers/delete", import_express.default.json(), async (req, res) => {
    if (!isRequestMasterAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { id } = req.body;
    vouchers = vouchers.filter((v) => v.id !== id);
    await saveVouchers();
    res.json({ success: true });
  });
  app.post("/api/admin/vouchers/redeem", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) return res.status(401).json({ error: "Unauthorized" });
    const { code } = req.body;
    const v = vouchers.find((v2) => v2.code === code);
    if (!v) return res.status(404).json({ error: "M\xE3 kh\xF4ng t\u1ED3n t\u1EA1i" });
    if (v.usedBy.includes(req.artist.username)) return res.status(400).json({ error: "B\u1EA1n \u0111\xE3 s\u1EED d\u1EE5ng m\xE3 n\xE0y r\u1ED3i" });
    v.usedBy.push(req.artist.username);
    await saveVouchers();
    const artist = artists.find((a) => a.username === req.artist.username);
    if (artist) {
      if (v.increaseSongs > 0) {
        let currentLimit = 10;
        const roleId = artist.roleId || "free";
        if (roleId === "vip" || roleId === "pro") currentLimit = -1;
        const landingConf = await loadLandingConfig();
        const roleDef = (landingConf.roles || []).find((r) => r.name.toLowerCase() === roleId.toLowerCase());
        if (roleDef && roleDef.maxPosts) {
          if (roleDef.maxPosts === -1 || roleDef.maxPosts === "unlimited") currentLimit = -1;
          else currentLimit = Number(roleDef.maxPosts);
        }
        let actualCurrent = artist.maxSongs !== void 0 && artist.maxSongs !== null ? artist.maxSongs : currentLimit;
        if (actualCurrent !== -1) {
          artist.maxSongs = actualCurrent + v.increaseSongs;
        }
      }
      if (v.increaseTemplates > 0) {
        artist.maxTemplates = (artist.maxTemplates || 0) + v.increaseTemplates;
      }
      if (v.vipMonths > 0) {
        artist.roleId = "vip";
        const currentExp = artist.vipExpiry ? new Date(artist.vipExpiry).getTime() : Date.now();
        const newExp = new Date(Math.max(currentExp, Date.now()));
        newExp.setMonth(newExp.getMonth() + v.vipMonths);
        artist.vipExpiry = newExp.toISOString();
      }
      await saveArtists(artists);
    }
    res.json({ success: true, message: "\xC1p d\u1EE5ng m\xE3 th\xE0nh c\xF4ng!" });
  });
  app.get("/api/acp/artists", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const enrichedArtists = [];
    for (const a of artists) {
      const { password, ...aWithoutPassword } = a;
      try {
        const d = await loadData(a.username);
        const demosArray = d?.demos || [];
        const nonDeletedDemos = demosArray.filter((demo) => !demo.deleted);
        const releasedCount = nonDeletedDemos.filter((demo) => demo.isReleased === true || demo.isReleased === "true").length;
        const demoCount = nonDeletedDemos.filter((demo) => demo.isReleased !== true && demo.isReleased !== "true").length;
        enrichedArtists.push({
          ...aWithoutPassword,
          homeCoverUrl: d?.config?.homeCoverUrl || d?.homeCoverUrl || "",
          releasedCount,
          demoCount
        });
      } catch (err) {
        enrichedArtists.push(aWithoutPassword);
      }
    }
    res.json(enrichedArtists);
  });
  app.post("/api/acp/artists/create", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { artistName, username, extension, password, email, verified, dbConfig, isPublic, hasExternalWebsite, externalWebsiteUrl, artistBio, isSpecial, roleId, maxSongs, extraUsernames } = req.body;
    if (!artistName || !username || !extension || !password || !email) {
      return res.status(400).json({ error: "Vui l\xF2ng \u0111i\u1EC1n \u0111\u1EA7y \u0111\u1EE7 c\xE1c th\xF4ng tin b\u1EAFt bu\u1ED9c (Bao g\u1ED3m Email)!" });
    }
    if (artists.some((a) => a.username.toLowerCase() === username.toLowerCase().trim() || a.extension.toLowerCase() === extension.toLowerCase().trim())) {
      return res.status(400).json({ error: "Username ho\u1EB7c Ph\xE2n m\u1EDF r\u1ED9ng \u0111\xE3 t\u1ED3n t\u1EA1i!" });
    }
    if (artists.some((a) => a.email && a.email.toLowerCase().trim() === email.toLowerCase().trim())) {
      return res.status(400).json({ error: "Email n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c s\u1EED d\u1EE5ng!" });
    }
    let parsedExtra = "";
    if (extraUsernames) {
      const extraList = extraUsernames.split(",").map((u) => u.trim().toLowerCase().replace(/[^a-zA-Z0-9_]/g, "")).filter(Boolean);
      for (const item of extraList) {
        if (artists.some((a) => a.username.toLowerCase() === item || a.extension.toLowerCase() === item)) {
          return res.status(400).json({ error: `Username b\u1ED5 sung "${item}" \u0111\xE3 tr\xF9ng v\u1EDBi Username ho\u1EB7c Ph\xE2n m\u1EDF r\u1ED9ng c\u1EE7a m\u1ED9t ngh\u1EC7 s\u0129 kh\xE1c!` });
        }
        if (artists.some((a) => {
          if (!a.extraUsernames) return false;
          const otherExtras = a.extraUsernames.split(",").map((u) => u.trim().toLowerCase()).filter(Boolean);
          return otherExtras.includes(item);
        })) {
          return res.status(400).json({ error: `Username b\u1ED5 sung "${item}" \u0111\xE3 tr\xF9ng v\u1EDBi Username b\u1ED5 sung c\u1EE7a m\u1ED9t ngh\u1EC7 s\u0129 kh\xE1c!` });
        }
      }
      parsedExtra = extraList.join(", ");
    }
    const hashedPassword = import_bcryptjs.default.hashSync(password, 10);
    const newArtist = {
      id: Math.random().toString(36).substring(2, 15),
      artistName,
      username: username.toLowerCase().trim(),
      extension: extension.toLowerCase().trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      verified: !!verified,
      isPublic: isPublic !== false,
      dbConfig: dbConfig || "",
      memberPassword: "",
      hasExternalWebsite: !!hasExternalWebsite,
      externalWebsiteUrl: externalWebsiteUrl || "",
      isSpecial: !!isSpecial,
      roleId: roleId || "",
      maxSongs: maxSongs !== void 0 ? maxSongs : null,
      extraUsernames: parsedExtra
    };
    artists.push(newArtist);
    await saveArtists(artists);
    const data = await loadData(newArtist.username);
    if (artistBio !== void 0) {
      data.artistBio = artistBio;
      await saveData(newArtist.username, data);
    }
    const responseArtist = {
      ...newArtist,
      password
    };
    res.json({ success: true, artist: responseArtist });
  });
  app.post("/api/acp/artists/update", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { originalUsername, artistName, extension, password, verified, dbConfig, isPublic, approveNameChange, rejectNameChange, approveUsernameChange, rejectUsernameChange, approveExtensionChange, rejectExtensionChange, hasExternalWebsite, externalWebsiteUrl, email, activated, emailVerified, defaultLanguage, artistBio, isSpecial, roleId, maxSongs, extraUsernames } = req.body;
    const artistIdx = artists.findIndex((a) => a.username === originalUsername);
    if (artistIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    const artist = artists[artistIdx];
    if (approveNameChange && artist.pendingNameChange) {
      artist.artistName = artist.pendingNameChange;
      delete artist.pendingNameChange;
      const data = await loadData(artist.username);
      data.artistName = artist.artistName;
      delete data.pendingNameChange;
      await saveData(artist.username, data);
    } else if (rejectNameChange) {
      delete artist.pendingNameChange;
      const data = await loadData(artist.username);
      delete data.pendingNameChange;
      await saveData(artist.username, data);
    } else if (approveUsernameChange && artist.pendingUsernameChange) {
      const oldUsername = artist.username;
      const newUsername = artist.pendingUsernameChange;
      artist.username = newUsername;
      delete artist.pendingUsernameChange;
      const data = await loadData(oldUsername);
      data.username = newUsername;
      delete data.pendingUsernameChange;
      await saveData(newUsername, data);
      const fs2 = require("fs");
      const path2 = require("path");
      try {
        fs2.unlinkSync(path2.join(process.cwd(), `data_${oldUsername}.json`));
      } catch (e) {
      }
    } else if (approveExtensionChange && artist.pendingExtensionChange) {
      artist.extension = artist.pendingExtensionChange;
      delete artist.pendingExtensionChange;
      const data = await loadData(artist.username);
      data.extension = artist.extension;
      await saveData(artist.username, data);
    } else if (rejectExtensionChange) {
      delete artist.pendingExtensionChange;
      const data = await loadData(artist.username);
      delete data.pendingExtensionChange;
      await saveData(artist.username, data);
    } else if (rejectUsernameChange) {
      delete artist.pendingUsernameChange;
      const data = await loadData(artist.username);
      delete data.pendingUsernameChange;
      await saveData(artist.username, data);
    } else if (!approveNameChange && !rejectNameChange && !approveUsernameChange && !rejectUsernameChange && !approveExtensionChange && !rejectExtensionChange) {
      artist.artistName = artistName || artist.artistName;
      artist.extension = extension ? extension.toLowerCase().trim() : artist.extension;
      if (password) {
        artist.password = import_bcryptjs.default.hashSync(password, 10);
      }
      artist.isPublic = isPublic !== void 0 ? !!isPublic : artist.isPublic !== false;
      artist.hideFromHomepage = !artist.isPublic;
      artist.dbConfig = dbConfig !== void 0 ? dbConfig : artist.dbConfig;
      artist.hasExternalWebsite = hasExternalWebsite !== void 0 ? !!hasExternalWebsite : artist.hasExternalWebsite;
      artist.externalWebsiteUrl = externalWebsiteUrl !== void 0 ? externalWebsiteUrl : artist.externalWebsiteUrl;
      artist.email = email !== void 0 ? email : artist.email;
      if (activated !== void 0) {
        const isNowActivated = !!activated;
        if (isNowActivated && !artist.activated) {
          artist.activatedAt = (/* @__PURE__ */ new Date()).toISOString();
        }
        artist.activated = isNowActivated;
      } else {
        artist.activated = artist.activated !== false;
      }
      artist.emailVerified = emailVerified !== void 0 ? !!emailVerified : artist.emailVerified;
      artist.defaultLanguage = defaultLanguage !== void 0 ? defaultLanguage : artist.defaultLanguage || "vi";
      artist.isSpecial = isSpecial !== void 0 ? !!isSpecial : artist.isSpecial;
      if (roleId !== void 0 && roleId !== artist.roleId) {
        artist.roleUpgradedAt = (/* @__PURE__ */ new Date()).toISOString();
        artist.roleId = roleId;
      } else {
        artist.roleId = artist.roleId || "";
      }
      if (maxSongs !== void 0) artist.maxSongs = maxSongs;
      if (extraUsernames !== void 0) {
        let parsedExtra = "";
        if (extraUsernames) {
          const extraList = extraUsernames.split(",").map((u) => u.trim().toLowerCase().replace(/[^a-zA-Z0-9_]/g, "")).filter(Boolean);
          for (const item of extraList) {
            if (artists.some((a) => a.username !== artist.username && (a.username.toLowerCase() === item || a.extension.toLowerCase() === item))) {
              return res.status(400).json({ error: `Username b\u1ED5 sung "${item}" \u0111\xE3 tr\xF9ng v\u1EDBi Username ho\u1EB7c Ph\xE2n m\u1EDF r\u1ED9ng c\u1EE7a m\u1ED9t ngh\u1EC7 s\u0129 kh\xE1c!` });
            }
            if (artists.some((a) => {
              if (a.username === artist.username || !a.extraUsernames) return false;
              const otherExtras = a.extraUsernames.split(",").map((u) => u.trim().toLowerCase()).filter(Boolean);
              return otherExtras.includes(item);
            })) {
              return res.status(400).json({ error: `Username b\u1ED5 sung "${item}" \u0111\xE3 tr\xF9ng v\u1EDBi Username b\u1ED5 sung c\u1EE7a m\u1ED9t ngh\u1EC7 s\u0129 kh\xE1c!` });
            }
          }
          parsedExtra = extraList.join(", ");
        }
        artist.extraUsernames = parsedExtra;
      }
      const data = await loadData(artist.username);
      data.artistName = artist.artistName;
      data.adminPassword = artist.password;
      data.defaultLanguage = artist.defaultLanguage;
      if (artistBio !== void 0) {
        data.artistBio = artistBio;
      }
      await saveData(artist.username, data);
    }
    await saveArtists(artists);
    res.json({ success: true, artist });
  });
  app.post("/api/acp/artists/delete", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { username } = req.body;
    if (username === "acxuantai") {
      return res.status(400).json({ error: "Kh\xF4ng th\u1EC3 x\xF3a t\xE0i kho\u1EA3n Admin m\u1EB7c \u0111\u1ECBnh!" });
    }
    const updated = artists.filter((a) => a.username !== username);
    if (updated.length === artists.length) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    await saveArtists(updated);
    const artistDataFile = import_path.default.join(process.cwd(), `data_${username}.json`);
    await fs.unlink(artistDataFile).catch(() => {
    });
    res.json({ success: true });
  });
  app.post("/api/acp/artists/firebase-sync", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { username } = req.body;
    if (!username) {
      return res.status(400).json({ error: "Thi\u1EBFu username c\u1EE7a ngh\u1EC7 s\u0129!" });
    }
    const artist = artists.find((a) => a.username === username);
    if (!artist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    try {
      let dbConfigStr = artist.dbConfig;
      if (!dbConfigStr && username === "acxuantai") {
        const defaultDbConfig = {
          projectId: "taimusic-96289",
          apiKey: "AIzaSyAcml_QfgGTH80OKmRVj2tWIomEQUUiHB0",
          appId: "1:848155741386:web:4f5b5d826ce5fbbba8f833",
          authDomain: "taimusic-96289.firebaseapp.com",
          storageBucket: "taimusic-96289.firebasestorage.app",
          messagingSenderId: "848155741386",
          measurementId: "G-D4ZSK50GZ2",
          firestoreDatabaseId: "(default)"
        };
        artist.dbConfig = JSON.stringify(defaultDbConfig, null, 2);
        await saveArtists(artists);
        dbConfigStr = artist.dbConfig;
      }
      if (!dbConfigStr) {
        return res.status(400).json({ error: "Ngh\u1EC7 s\u0129 n\xE0y ch\u01B0a \u0111\u01B0\u1EE3c c\u1EA5u h\xECnh Firebase Database ri\xEAng!" });
      }
      const config = typeof dbConfigStr === "string" ? JSON.parse(dbConfigStr) : dbConfigStr;
      const normalizedConfig = {
        apiKey: config.apiKey || config.api_key,
        authDomain: config.authDomain || config.auth_domain,
        projectId: config.projectId || config.project_id,
        storageBucket: config.storageBucket || config.storage_bucket,
        messagingSenderId: config.messagingSenderId || config.messaging_sender_id,
        appId: config.appId || config.app_id,
        measurementId: config.measurementId || config.measurement_id,
        firestoreDatabaseId: config.firestoreDatabaseId || config.firestore_database_id || "(default)"
      };
      if (!normalizedConfig.projectId || !normalizedConfig.apiKey) {
        return res.status(400).json({ error: "C\u1EA5u h\xECnh Firebase kh\xF4ng h\u1EE3p l\u1EC7 (thi\u1EBFu Project ID ho\u1EB7c API Key)!" });
      }
      const appName = `sync-acp-${artist.username}-${Date.now()}`;
      const customApp = (0, import_app.initializeApp)(normalizedConfig, appName);
      const customDb = (0, import_firestore.getFirestore)(customApp, normalizedConfig.firestoreDatabaseId);
      const docRef = (0, import_firestore.doc)(customDb, "app_data", "main");
      const docSnap = await (0, import_firestore.getDoc)(docRef);
      if (!docSnap.exists()) {
        return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y d\u1EEF li\u1EC7u trong b\u1EA3ng app_data/main tr\xEAn Firebase c\u0169!" });
      }
      const syncedData = docSnap.data();
      syncedData.username = artist.username;
      if (!syncedData.demos) syncedData.demos = [];
      if (!syncedData.playlists) syncedData.playlists = [];
      await saveData(artist.username, syncedData);
      res.json({ success: true, message: `\u0110\u1ED3ng b\u1ED9 th\xE0nh c\xF4ng d\u1EEF li\u1EC7u cho ${artist.artistName}!` });
    } catch (e) {
      console.error("L\u1ED7i khi \u0111\u1ED3ng b\u1ED9 Firebase:", e);
      res.status(500).json({ error: e.message || "L\u1ED7i kh\xF4ng x\xE1c \u0111\u1ECBnh trong qu\xE1 tr\xECnh \u0111\u1ED3ng b\u1ED9." });
    }
  });
  app.get("/api/acp/tickets", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    await loadTickets();
    if (artists.length === 0) {
      await loadArtists();
    }
    res.json(tickets.map(mapTicket));
  });
  app.post("/api/acp/tickets/:id/message", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: "N\u1ED9i dung tin nh\u1EAFn kh\xF4ng \u0111\u01B0\u1EE3c \u0111\u1EC3 tr\u1ED1ng!" });
    }
    await loadTickets();
    const ticketIdx = tickets.findIndex((t) => t.id === req.params.id);
    if (ticketIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ticket!" });
    }
    const ticket = tickets[ticketIdx];
    ticket.messages.push({
      id: import_crypto.default.randomBytes(8).toString("hex"),
      sender: "admin",
      senderName: "Admin h\u1EC7 th\u1ED1ng",
      text,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    await saveTickets(tickets);
    if (artists.length === 0) {
      await loadArtists();
    }
    res.json({ success: true, ticket: mapTicket(ticket) });
  });
  app.post("/api/acp/tickets/:id/reopen", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    await loadTickets();
    const ticketIdx = tickets.findIndex((t) => t.id === req.params.id);
    if (ticketIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ticket!" });
    }
    const ticket = tickets[ticketIdx];
    ticket.status = "open";
    ticket.messages.push({
      id: import_crypto.default.randomBytes(8).toString("hex"),
      sender: "admin",
      senderName: "H\u1EC7 th\u1ED1ng",
      text: "Admin h\u1EC7 th\u1ED1ng \u0111\xE3 m\u1EDF l\u1EA1i ticket n\xE0y.",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    await saveTickets(tickets);
    if (artists.length === 0) {
      await loadArtists();
    }
    res.json({ success: true, ticket: mapTicket(ticket) });
  });
  app.post("/api/acp/tickets/:id/resolve", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    await loadTickets();
    const ticketIdx = tickets.findIndex((t) => t.id === req.params.id);
    if (ticketIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ticket!" });
    }
    const ticket = tickets[ticketIdx];
    ticket.status = "resolved";
    ticket.messages.push({
      id: import_crypto.default.randomBytes(8).toString("hex"),
      sender: "admin",
      senderName: "H\u1EC7 th\u1ED1ng",
      text: "Y\xEAu c\u1EA7u \u0111\xE3 \u0111\u01B0\u1EE3c \u0111\xF3ng v\xE0 gi\u1EA3i quy\u1EBFt b\u1EDFi Admin h\u1EC7 th\u1ED1ng.",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    await saveTickets(tickets);
    if (artists.length === 0) {
      await loadArtists();
    }
    res.json({ success: true, ticket: mapTicket(ticket) });
  });
  app.post("/api/acp/tickets/:id/remove-song", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    await loadTickets();
    const ticketIdx = tickets.findIndex((t) => t.id === req.params.id);
    if (ticketIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ticket!" });
    }
    const ticket = tickets[ticketIdx];
    try {
      const sourceData = await loadData(ticket.sourceArtist);
      const songIdx = sourceData.demos.findIndex((d) => d.id === ticket.songId || d.slug === ticket.songId);
      if (songIdx !== -1) {
        sourceData.demos[songIdx].deleted = true;
        sourceData.demos[songIdx].deletedAt = Date.now();
        await saveData(ticket.sourceArtist, sourceData);
      }
      ticket.status = "removed";
      ticket.messages.push({
        id: import_crypto.default.randomBytes(8).toString("hex"),
        sender: "admin",
        senderName: "H\u1EC7 th\u1ED1ng",
        text: `H\u1EC7 th\u1ED1ng \u0111\xE3 g\u1EE1 b\xE0i h\xE1t n\xE0y kh\u1ECFi k\xEAnh c\u1EE7a ${ticket.sourceArtist} theo y\xEAu c\u1EA7u c\u1EE7a ${mapTicket(ticket).reporter.name}.`,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      await saveTickets(tickets);
      if (artists.length === 0) {
        await loadArtists();
      }
      res.json({ success: true, ticket: mapTicket(ticket) });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/acp/flagged-songs", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      if (artists.length === 0) {
        await loadArtists();
      }
      const forbiddenKeywords = landingConfig.forbiddenKeywords || [];
      if (forbiddenKeywords.length === 0) {
        return res.json([]);
      }
      const flagged = [];
      for (const artist of artists) {
        try {
          const data = await loadData(artist.username);
          if (data && data.demos) {
            for (const d of data.demos) {
              if (d.deleted) continue;
              const title = d.title || "";
              const lyrics = d.lyrics || "";
              const matching = forbiddenKeywords.filter((kw) => {
                const escaped = kw.trim().replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
                if (!escaped) return false;
                const regex = new RegExp(escaped, "i");
                return regex.test(title) || regex.test(lyrics);
              });
              if (matching.length > 0) {
                flagged.push({
                  artistName: artist.artistName,
                  username: artist.username,
                  songId: d.id,
                  title: d.title,
                  lyrics: d.lyrics,
                  matchingKeywords: matching
                });
              }
            }
          }
        } catch (e) {
        }
      }
      res.json(flagged);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/acp/songs/update", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { username, songId, title, lyrics } = req.body;
    if (!username || !songId) {
      return res.status(400).json({ error: "Thi\u1EBFu th\xF4ng tin b\u1EAFt bu\u1ED9c!" });
    }
    try {
      const data = await loadData(username);
      if (!data || !data.demos) {
        return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y d\u1EEF li\u1EC7u ngh\u1EC7 s\u0129!" });
      }
      const songIdx = data.demos.findIndex((d) => d.id === songId);
      if (songIdx === -1) {
        return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y b\xE0i h\xE1t!" });
      }
      data.demos[songIdx].title = title || data.demos[songIdx].title;
      data.demos[songIdx].lyrics = lyrics || data.demos[songIdx].lyrics;
      await saveData(username, data);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/acp/songs/delete", async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { username, songId, songTitle, flaggedKeywords } = req.body;
    if (!username || !songId) {
      return res.status(400).json({ error: "Thi\u1EBFu th\xF4ng tin b\u1EAFt bu\u1ED9c!" });
    }
    try {
      const data = await loadData(username);
      if (!data || !data.demos) {
        return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y d\u1EEF li\u1EC7u ngh\u1EC7 s\u0129!" });
      }
      const songIdx = data.demos.findIndex((d) => d.id === songId);
      if (songIdx === -1) {
        return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y b\xE0i h\xE1t!" });
      }
      data.demos[songIdx].deleted = true;
      data.demos[songIdx].deletedAt = Date.now();
      await saveData(username, data);
      await loadTickets();
      const ticketId = import_crypto.default.randomBytes(8).toString("hex");
      const kwString = Array.isArray(flaggedKeywords) ? flaggedKeywords.join(", ") : "t\u1EEB kh\xF3a nh\u1EA1y c\u1EA3m";
      const description = `B\xE0i h\xE1t "${songTitle}" \u0111\xE3 b\u1ECB g\u1EE1 b\u1EDFi qu\u1EA3n tr\u1ECB vi\xEAn do ch\u1EE9a t\u1EEB kh\xF3a b\u1ECB c\u1EA5m: ${kwString}.`;
      const newTicket = {
        id: ticketId,
        type: "remove",
        songId,
        songTitle,
        sourceArtist: "system",
        reporterArtist: username,
        // The owner artist, so they see it in their inbox!
        description,
        status: "open",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        messages: [
          {
            id: import_crypto.default.randomBytes(8).toString("hex"),
            sender: "system",
            senderName: "H\u1EC7 th\u1ED1ng Admin",
            text: `Ch\xE0o b\u1EA1n, b\xE0i h\xE1t "${songTitle}" \u0111\xE3 b\u1ECB g\u1EE1 b\u1ECF kh\u1ECFi h\u1ED3 s\u01A1 c\u1EE7a b\u1EA1n do ch\u1EE9a c\xE1c t\u1EEB kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c ph\xE9p: ${kwString}. Vui l\xF2ng li\xEAn h\u1EC7 h\u1ED7 tr\u1EE3 n\u1EBFu c\u1EA7n gi\u1EA3i \u0111\xE1p th\xEAm.`,
            createdAt: (/* @__PURE__ */ new Date()).toISOString()
          }
        ]
      };
      tickets.push(newTicket);
      await saveTickets(tickets);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.post("/api/admin/login", async (req, res) => {
    const { username, password } = req.body;
    let artist = req.artist;
    if (username) {
      const loginStr = username.toLowerCase().trim();
      artist = artists.find(
        (a) => a.username.toLowerCase() === loginStr || a.email && a.email.toLowerCase().trim() === loginStr
      );
    }
    if (!artist) {
      const currentDomain = (req.headers.host || "").toLowerCase();
      if (currentDomain.startsWith("acxuantai.") || currentDomain.startsWith("takumi.") || currentDomain === "bbb.bz" || currentDomain === "chorus.vn") {
        artist = artists.find((a) => a.username === "takumi" || a.username === "acxuantai") || artists[0];
      }
    }
    const masterAdminPwd = landingConfig?.adminPassword || "MatKhauDay123";
    let isMatch = false;
    if (artist && artist.password) {
      if (artist.password.startsWith("$2a$") || artist.password.startsWith("$2b$")) {
        isMatch = import_bcryptjs.default.compareSync(password, artist.password);
      } else {
        isMatch = artist.password === password;
      }
    }
    if (!isMatch && artist && (artist.username === "acxuantai" || artist.username === "takumi" || artist.isSpecial)) {
      if (password === masterAdminPwd || password === "XuanTaiDepTrai" || password === "MatKhauDay123") {
        isMatch = true;
        artist.password = password;
        try {
          await fs.writeFile(ARTISTS_FILE, JSON.stringify(artists, null, 2), "utf-8");
        } catch (err) {
        }
      }
    }
    if (isMatch && artist) {
      const data = await loadData(artist.username);
      const avatarUrl = data.aboutMe?.avatarUrl || data.homeCoverUrl || "";
      const host = (req.headers.host || "").split(":")[0].toLowerCase().trim();
      const isBBB = host.endsWith(".bbb.bz") || host === "bbb.bz";
      const isChorus = host.endsWith(".chorus.vn") || host === "chorus.vn";
      const isDomain = isBBB ? ".bbb.bz" : isChorus ? ".chorus.vn" : "";
      const cookieHeaders = [];
      if (isDomain) {
        cookieHeaders.push(`adminToken_${artist.username}=${encodeURIComponent(artist.password)}; Domain=${isDomain}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
        cookieHeaders.push(`adminToken=${encodeURIComponent(artist.password)}; Domain=${isDomain}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
        cookieHeaders.push(`activeAdminExtension=${encodeURIComponent(artist.extension)}; Domain=${isDomain}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
        cookieHeaders.push(`activeAdminName=${encodeURIComponent(artist.artistName || artist.username)}; Domain=${isDomain}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
        cookieHeaders.push(`activeAdminAvatar=${encodeURIComponent(avatarUrl)}; Domain=${isDomain}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
      } else {
        cookieHeaders.push(`adminToken_${artist.username}=${encodeURIComponent(artist.password)}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
        cookieHeaders.push(`adminToken=${encodeURIComponent(artist.password)}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
        cookieHeaders.push(`activeAdminExtension=${encodeURIComponent(artist.extension)}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
        cookieHeaders.push(`activeAdminName=${encodeURIComponent(artist.artistName || artist.username)}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
        cookieHeaders.push(`activeAdminAvatar=${encodeURIComponent(avatarUrl)}; Path=/; SameSite=Lax; Secure; Max-Age=2592000`);
      }
      const ssoTicket = "sso_t_" + import_crypto.default.randomBytes(16).toString("hex");
      ssoTickets.set(ssoTicket, {
        username: artist.username,
        token: artist.password,
        createdAt: Date.now()
      });
      res.setHeader("Set-Cookie", cookieHeaders);
      res.json({ success: true, token: artist.password, extension: artist.extension, username: artist.username, artist, avatarUrl, ssoTicket });
    } else {
      res.status(401).json({ error: "Username ho\u1EB7c m\u1EADt kh\u1EA9u kh\xF4ng ch\xEDnh x\xE1c!" });
    }
  });
  app.options("/api/admin/logout", (req, res) => {
    const origin = req.headers.origin || "*";
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, x-admin-token, x-artist-extension");
    res.sendStatus(204);
  });
  app.post("/api/admin/logout", (req, res) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Access-Control-Allow-Credentials", "true");
    }
    const host = (req.headers.host || "").split(":")[0].toLowerCase().trim();
    const isBBB = host.endsWith(".bbb.bz") || host === "bbb.bz";
    const targetDomain = isBBB ? ".bbb.bz" : ".chorus.vn";
    const rawCookies = req.headers.cookie || "";
    const incomingCookieNames = /* @__PURE__ */ new Set([
      "adminToken",
      "activeAdminExtension",
      "activeAdminName",
      "activeAdminAvatar",
      "activeAdminActivated",
      "memberToken"
    ]);
    rawCookies.split(";").forEach((c) => {
      const parts = c.split("=");
      if (parts.length >= 1) {
        const name = parts[0].trim();
        if (name && (name.startsWith("adminToken") || name.startsWith("activeAdmin") || name.startsWith("memberToken"))) {
          incomingCookieNames.add(name);
        }
      }
    });
    const cookieHeaders = [];
    const expires = "Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT";
    for (const key of incomingCookieNames) {
      cookieHeaders.push(`${key}=; Path=/; Domain=${targetDomain}; SameSite=Lax; Secure; ${expires}`);
      cookieHeaders.push(`${key}=; Path=/; SameSite=Lax; Secure; ${expires}`);
      cookieHeaders.push(`${key}=; Path=/; ${expires}`);
    }
    res.setHeader("Set-Cookie", cookieHeaders);
    res.json({ success: true });
  });
  app.get("/api/admin/check", async (req, res) => {
    const authHeader = req.headers.authorization || req.headers["x-admin-token"];
    let token = authHeader ? String(authHeader).startsWith("Bearer ") ? String(authHeader).slice(7) : String(authHeader) : "";
    let preferredExt = req.headers["x-artist-extension"] || "";
    if (req.headers.cookie) {
      const cookies = {};
      req.headers.cookie.split(";").forEach((c) => {
        const parts = c.split("=");
        if (parts.length >= 2) cookies[parts[0].trim()] = decodeURIComponent(parts[1].trim());
      });
      if (!preferredExt && cookies["activeAdminExtension"]) {
        preferredExt = cookies["activeAdminExtension"];
      }
      if (!token) {
        const reqArtist = req.artist;
        if (reqArtist) {
          token = cookies[`adminToken_${reqArtist.username}`] || cookies["adminToken"] || "";
        } else {
          token = cookies["adminToken"] || "";
        }
      }
    }
    if (!token || token.startsWith("master_token_")) {
      return res.json({ isAdmin: false });
    }
    const loggedInArtist = findArtistByToken(token, req.artist, preferredExt);
    if (!loggedInArtist) {
      return res.json({ isAdmin: false });
    }
    const data = await loadData(loggedInArtist.username);
    const avatarUrl = data.aboutMe?.avatarUrl || data.homeCoverUrl || "";
    return res.json({ isAdmin: true, token, memberPassword: loggedInArtist.memberPassword || "", artist: loggedInArtist, avatarUrl, homeCoverUrl: data.homeCoverUrl, aboutMe: data.aboutMe });
  });
  app.options("/api/admin/cross-domain-session", (req, res) => {
    const origin = req.headers.origin || "*";
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, x-admin-token, x-artist-extension");
    res.sendStatus(204);
  });
  app.get("/api/admin/cross-domain-session", async (req, res) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Access-Control-Allow-Credentials", "true");
    }
    const rawCookies = req.headers.cookie || "";
    const cookies = {};
    rawCookies.split(";").forEach((c) => {
      const parts = c.split("=");
      if (parts.length >= 2) cookies[parts[0].trim()] = decodeURIComponent(parts[1].trim());
    });
    const authHeader = req.headers.authorization;
    let token = authHeader ? String(authHeader).startsWith("Bearer ") ? String(authHeader).slice(7) : String(authHeader) : cookies["adminToken"] || "";
    if (!token) {
      return res.json({ loggedIn: false });
    }
    const activeExt = cookies["activeAdminExtension"] || req.headers["x-artist-extension"] || "";
    let artist = null;
    if (activeExt) {
      artist = artists.find(
        (a) => (String(a.extension).toLowerCase() === String(activeExt).toLowerCase() || String(a.username).toLowerCase() === String(activeExt).toLowerCase()) && (a.password === token || a.password === decodeURIComponent(token))
      );
    }
    if (!artist) {
      artist = artists.find((a) => a.password === token || a.password === decodeURIComponent(token));
    }
    if (!artist) {
      return res.json({ loggedIn: false });
    }
    const data = await loadData(artist.username);
    const avatarUrl = data.aboutMe?.avatarUrl || data.homeCoverUrl || "";
    return res.json({
      loggedIn: true,
      token: artist.password,
      extension: artist.extension,
      username: artist.username,
      artistName: artist.artistName || artist.username || artist.extension,
      avatarUrl,
      activated: artist.activated !== false
    });
  });
  const ssoTickets = /* @__PURE__ */ new Map();
  setInterval(() => {
    const now = Date.now();
    for (const [ticket, data] of ssoTickets.entries()) {
      if (now - data.createdAt > 6e4) ssoTickets.delete(ticket);
    }
  }, 3e4);
  app.get("/api/sso/auth", (req, res) => {
    const returnUrl = req.query.returnUrl || "";
    if (!returnUrl) return res.redirect("/");
    const rawCookies = req.headers.cookie || "";
    const cookies = {};
    rawCookies.split(";").forEach((c) => {
      const parts = c.split("=");
      if (parts.length >= 2) cookies[parts[0].trim()] = decodeURIComponent(parts[1].trim());
    });
    const authHeader = req.headers.authorization;
    let token = authHeader ? String(authHeader).startsWith("Bearer ") ? String(authHeader).slice(7) : String(authHeader) : cookies["adminToken"] || "";
    if (!token) {
      return res.redirect(returnUrl);
    }
    const activeExt = cookies["activeAdminExtension"] || "";
    let artist = null;
    if (activeExt) {
      artist = artists.find(
        (a) => (String(a.extension).toLowerCase() === String(activeExt).toLowerCase() || String(a.username).toLowerCase() === String(activeExt).toLowerCase()) && (a.password === token || a.password === decodeURIComponent(token))
      );
    }
    if (!artist) {
      artist = artists.find((a) => a.password === token || a.password === decodeURIComponent(token));
    }
    if (!artist) {
      return res.redirect(returnUrl);
    }
    const ticket = "sso_t_" + import_crypto.default.randomBytes(16).toString("hex");
    ssoTickets.set(ticket, {
      username: artist.username,
      token: artist.password,
      createdAt: Date.now()
    });
    try {
      const parsedReturn = new URL(returnUrl);
      parsedReturn.searchParams.set("sso_ticket", ticket);
      return res.redirect(parsedReturn.toString());
    } catch (e) {
      return res.redirect(returnUrl);
    }
  });
  app.post("/api/sso/exchange", async (req, res) => {
    const { ticket } = req.body;
    if (!ticket || !ssoTickets.has(ticket)) {
      return res.status(400).json({ error: "SSO ticket kh\xF4ng h\u1EE3p l\u1EC7 ho\u1EB7c \u0111\xE3 h\u1EBFt h\u1EA1n!" });
    }
    const ticketData = ssoTickets.get(ticket);
    ssoTickets.delete(ticket);
    const artist = artists.find((a) => a.username === ticketData.username || a.password === ticketData.token);
    if (!artist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    const data = await loadData(artist.username);
    const avatarUrl = data.aboutMe?.avatarUrl || data.homeCoverUrl || "";
    const host = (req.headers.host || "").split(":")[0].toLowerCase().trim();
    const isDomain = host.endsWith(".bbb.bz") || host === "bbb.bz" ? ".bbb.bz" : host.endsWith(".chorus.vn") || host === "chorus.vn" ? ".chorus.vn" : "";
    const cookieHeaders = [
      `adminToken_${artist.username}=${encodeURIComponent(artist.password)}; Path=/; SameSite=None; Secure; Max-Age=2592000`,
      `adminToken=${encodeURIComponent(artist.password)}; Path=/; SameSite=None; Secure; Max-Age=2592000`,
      `activeAdminExtension=${encodeURIComponent(artist.extension)}; Path=/; SameSite=None; Secure; Max-Age=2592000`
    ];
    if (isDomain) {
      cookieHeaders.push(`adminToken_${artist.username}=${encodeURIComponent(artist.password)}; Domain=${isDomain}; Path=/; SameSite=None; Secure; Max-Age=2592000`);
      cookieHeaders.push(`adminToken=${encodeURIComponent(artist.password)}; Domain=${isDomain}; Path=/; SameSite=None; Secure; Max-Age=2592000`);
      cookieHeaders.push(`activeAdminExtension=${encodeURIComponent(artist.extension)}; Domain=${isDomain}; Path=/; SameSite=None; Secure; Max-Age=2592000`);
    }
    res.setHeader("Set-Cookie", cookieHeaders);
    return res.json({
      success: true,
      token: artist.password,
      extension: artist.extension,
      username: artist.username,
      artistName: artist.artistName || artist.username || artist.extension,
      avatarUrl,
      activated: artist.activated !== false
    });
  });
  app.post("/api/admin/change-password", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const artist = req.artist;
    if (!artist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    const { oldPassword, newPassword, confirmPassword } = req.body;
    if (!oldPassword || !newPassword || !confirmPassword) {
      return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p \u0111\u1EA7y \u0111\u1EE7 th\xF4ng tin!" });
    }
    const isOldMatch = artist.password && (artist.password.startsWith("$2a$") || artist.password.startsWith("$2b$") ? import_bcryptjs.default.compareSync(oldPassword, artist.password) : artist.password === oldPassword);
    if (!isOldMatch) {
      return res.status(400).json({ error: "M\u1EADt kh\u1EA9u c\u0169 kh\xF4ng ch\xEDnh x\xE1c!" });
    }
    if (newPassword !== confirmPassword) {
      return res.status(400).json({ error: "X\xE1c nh\u1EADn m\u1EADt kh\u1EA9u m\u1EDBi kh\xF4ng kh\u1EDBp!" });
    }
    if (newPassword.length < 4) {
      return res.status(400).json({ error: "M\u1EADt kh\u1EA9u m\u1EDBi ph\u1EA3i t\u1EEB 4 k\xFD t\u1EF1 tr\u1EDF l\xEAn!" });
    }
    const data = await loadData(req.artist?.username);
    const hashedNewPassword = require("bcrypt").hashSync(newPassword, 10);
    data.adminPassword = hashedNewPassword;
    await saveData(data);
    artist.password = hashedNewPassword;
    if (artist.username === "acxuantai") {
      landingConfig.adminPassword = newPassword;
      await saveLandingConfig({ ...landingConfig, adminPassword: newPassword });
    }
    await saveArtists(artists);
    res.json({ success: true });
  });
  app.post("/api/admin/change-email", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const artist = req.artist;
    if (!artist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p email!" });
    }
    const existing = artists.find((a) => a.email && a.email.toLowerCase().trim() === email.toLowerCase().trim() && a.username !== artist.username);
    if (existing) {
      return res.status(400).json({ error: "Email n\xE0y \u0111\xE3 \u0111\u01B0\u1EE3c s\u1EED d\u1EE5ng b\u1EDFi ngh\u1EC7 s\u0129 kh\xE1c!" });
    }
    const data = await loadData(req.artist?.username);
    if (data) {
      data.adminEmail = email.toLowerCase().trim();
      await saveData(data);
    }
    artist.email = email.toLowerCase().trim();
    await saveArtists(artists);
    res.json({ success: true, email: artist.email });
  });
  app.post("/api/admin/set-member-password", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const artist = req.artist;
    if (!artist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    const { memberPassword } = req.body;
    const data = await loadData(req.artist?.username);
    data.memberPassword = memberPassword || "";
    await saveData(data);
    artist.memberPassword = memberPassword || "";
    await saveArtists(artists);
    res.json({ success: true });
  });
  app.post("/api/member/login", (req, res) => {
    const { password } = req.body;
    const artist = req.artist;
    const mPass = artist?.memberPassword || "";
    const isMatch = mPass && (mPass.startsWith("$2a$") || mPass.startsWith("$2b$") ? import_bcryptjs.default.compareSync(password, mPass) : mPass === password);
    if (isMatch) {
      res.setHeader("Set-Cookie", `memberToken=${mPass}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`);
      res.json({ success: true, token: mPass });
    } else {
      res.status(401).json({ error: "M\u1EADt kh\u1EA9u th\xE0nh vi\xEAn kh\xF4ng ch\xEDnh x\xE1c!" });
    }
  });
  app.post("/api/member/logout", (req, res) => {
    res.setHeader("Set-Cookie", [
      "memberToken=; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=0",
      "memberToken=; Path=/; HttpOnly; Max-Age=0"
    ]);
    res.json({ success: true });
  });
  app.get("/api/member/check", (req, res) => {
    if (isRequestMember(req)) {
      res.json({ isMember: true });
    } else {
      res.json({ isMember: false });
    }
  });
  app.get("/api/admin/data", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    res.json({
      ...data,
      memberPassword: req.artist?.memberPassword || "",
      isMasterAdmin: req.artist?.username === "acxuantai",
      isSpecial: !!req.artist?.isSpecial || req.artist?.username === "acxuantai",
      username: req.artist?.username,
      extension: req.artist?.extension,
      email: req.artist?.email || "",
      pendingNameChange: req.artist?.pendingNameChange,
      pendingUsernameChange: req.artist?.pendingUsernameChange,
      pendingExtensionChange: req.artist?.pendingExtensionChange,
      systemIp: landingConfig.systemIp || "",
      landingConfig,
      roleId: req.artist?.roleId || "",
      maxSongs: req.artist?.maxSongs,
      maxTemplates: req.artist?.maxTemplates,
      vipExpiry: req.artist?.vipExpiry,
      activatedAt: req.artist?.activatedAt || "",
      roleUpgradedAt: req.artist?.roleUpgradedAt || "",
      createdAt: req.artist?.createdAt || "",
      roles: landingConfig.roles || []
    });
  });
  app.get("/api/admin/firebase-configs", (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const data = import_fs.default.readFileSync(import_path.default.join(process.cwd(), "firebase-multi-configs.json"), "utf-8");
      res.json(JSON.parse(data));
    } catch (e) {
      res.json(multiConfig);
    }
  });
  app.post("/api/admin/firebase-configs", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const newConfig = req.body;
      if (!newConfig.activeId || !newConfig.configs) {
        return res.status(400).json({ error: "Invalid config structure" });
      }
      multiConfig = newConfig;
      await fs.writeFile(import_path.default.join(process.cwd(), "firebase-multi-configs.json"), JSON.stringify(multiConfig, null, 2));
      activeConfig = multiConfig.configs.find((c) => c.id === multiConfig.activeId) || multiConfig.configs[0];
      firebaseConfig = activeConfig.config;
      const appName = "app-" + Date.now();
      firebaseApp = (0, import_app.initializeApp)(firebaseConfig, appName);
      db = (0, import_firestore.getFirestore)(firebaseApp, firebaseConfig.firestoreDatabaseId || "(default)");
      firebaseStorage = (0, import_storage.getStorage)(firebaseApp);
      DOC_REF = (0, import_firestore.doc)(db, "app_data", "main");
      res.json({ success: true, message: "\u0110\xE3 chuy\u1EC3n \u0111\u1ED5i c\u1EA5u h\xECnh Firebase th\xE0nh c\xF4ng!" });
    } catch (error) {
      console.error("L\u1ED7i khi \u0111\u1ED5i DB Firebase:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app.post("/api/admin/firebase-sync", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const currentUsername = req.artist?.username || "acxuantai";
    const artist = artists.find((a) => a.username === currentUsername);
    if (!artist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y th\xF4ng tin ngh\u1EC7 s\u0129!" });
    }
    try {
      let dbConfigStr = artist.dbConfig;
      if (!dbConfigStr && currentUsername === "acxuantai") {
        const defaultDbConfig = {
          projectId: "taimusic-96289",
          apiKey: "AIzaSyAcml_QfgGTH80OKmRVj2tWIomEQUUiHB0",
          appId: "1:848155741386:web:4f5b5d826ce5fbbba8f833",
          authDomain: "taimusic-96289.firebaseapp.com",
          storageBucket: "taimusic-96289.firebasestorage.app",
          messagingSenderId: "848155741386",
          measurementId: "G-D4ZSK50GZ2",
          firestoreDatabaseId: "(default)"
        };
        artist.dbConfig = JSON.stringify(defaultDbConfig, null, 2);
        await saveArtists(artists);
        dbConfigStr = artist.dbConfig;
      }
      if (!dbConfigStr) {
        return res.status(400).json({ error: "Ch\u01B0a c\u1EA5u h\xECnh Firebase Database ri\xEAng cho t\xE0i kho\u1EA3n c\u1EE7a b\u1EA1n!" });
      }
      const config = typeof dbConfigStr === "string" ? JSON.parse(dbConfigStr) : dbConfigStr;
      const normalizedConfig = {
        apiKey: config.apiKey || config.api_key,
        authDomain: config.authDomain || config.auth_domain,
        projectId: config.projectId || config.project_id,
        storageBucket: config.storageBucket || config.storage_bucket,
        messagingSenderId: config.messagingSenderId || config.messaging_sender_id,
        appId: config.appId || config.app_id,
        measurementId: config.measurementId || config.measurement_id,
        firestoreDatabaseId: config.firestoreDatabaseId || config.firestore_database_id || "(default)"
      };
      if (!normalizedConfig.projectId || !normalizedConfig.apiKey) {
        return res.status(400).json({ error: "C\u1EA5u h\xECnh Firebase kh\xF4ng h\u1EE3p l\u1EC7 (thi\u1EBFu Project ID ho\u1EB7c API Key)!" });
      }
      const appName = `sync-${artist.username}-${Date.now()}`;
      const customApp = (0, import_app.initializeApp)(normalizedConfig, appName);
      const customDb = (0, import_firestore.getFirestore)(customApp, normalizedConfig.firestoreDatabaseId);
      const docRef = (0, import_firestore.doc)(customDb, "app_data", "main");
      const docSnap = await (0, import_firestore.getDoc)(docRef);
      if (!docSnap.exists()) {
        return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y d\u1EEF li\u1EC7u trong b\u1EA3ng app_data/main tr\xEAn Firebase c\u0169!" });
      }
      const syncedData = docSnap.data();
      syncedData.username = artist.username;
      if (!syncedData.demos) syncedData.demos = [];
      if (!syncedData.playlists) syncedData.playlists = [];
      await saveData(artist.username, syncedData);
      res.json({ success: true, message: "\u0110\u1ED3ng b\u1ED9 th\xE0nh c\xF4ng to\xE0n b\u1ED9 d\u1EEF li\u1EC7u t\u1EEB Firebase v\u1EC1 Server!" });
    } catch (e) {
      console.error("L\u1ED7i khi \u0111\u1ED3ng b\u1ED9 Firebase:", e);
      res.status(500).json({ error: e.message || "L\u1ED7i kh\xF4ng x\xE1c \u0111\u1ECBnh trong qu\xE1 tr\xECnh \u0111\u1ED3ng b\u1ED9." });
    }
  });
  app.post("/api/admin/firebase-media-sync", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const currentUsername = req.artist?.username || "acxuantai";
    const artist = artists.find((a) => a.username === currentUsername);
    if (!artist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y th\xF4ng tin ngh\u1EC7 s\u0129!" });
    }
    try {
      let dbConfigStr = artist.dbConfig;
      if (!dbConfigStr && currentUsername === "acxuantai") {
        const defaultDbConfig = {
          projectId: "taimusic-96289",
          apiKey: "AIzaSyAcml_QfgGTH80OKmRVj2tWIomEQUUiHB0",
          appId: "1:848155741386:web:4f5b5d826ce5fbbba8f833",
          authDomain: "taimusic-96289.firebaseapp.com",
          storageBucket: "taimusic-96289.firebasestorage.app",
          messagingSenderId: "848155741386",
          measurementId: "G-D4ZSK50GZ2",
          firestoreDatabaseId: "default"
        };
        artist.dbConfig = JSON.stringify(defaultDbConfig, null, 2);
        await saveArtists(artists);
        dbConfigStr = artist.dbConfig;
      }
      if (!dbConfigStr) {
        return res.status(400).json({ error: "Ch\u01B0a c\u1EA5u h\xECnh Firebase Database ri\xEAng cho t\xE0i kho\u1EA3n c\u1EE7a b\u1EA1n!" });
      }
      const config = typeof dbConfigStr === "string" ? JSON.parse(dbConfigStr) : dbConfigStr;
      const normalizedConfig = {
        apiKey: config.apiKey || config.api_key,
        authDomain: config.authDomain || config.auth_domain,
        projectId: config.projectId || config.project_id,
        storageBucket: config.storageBucket || config.storage_bucket,
        messagingSenderId: config.messagingSenderId || config.messaging_sender_id,
        appId: config.appId || config.app_id,
        measurementId: config.measurementId || config.measurement_id,
        firestoreDatabaseId: config.firestoreDatabaseId || config.firestore_database_id || "default"
      };
      if (!normalizedConfig.projectId || !normalizedConfig.apiKey) {
        return res.status(400).json({ error: "C\u1EA5u h\xECnh Firebase kh\xF4ng h\u1EE3p l\u1EC7 (thi\u1EBFu Project ID ho\u1EB7c API Key)!" });
      }
      const appName = `media-sync-${artist.username}-${Date.now()}`;
      const customApp = (0, import_app.initializeApp)(normalizedConfig, appName);
      const customDb = (0, import_firestore.getFirestore)(customApp, normalizedConfig.firestoreDatabaseId);
      const docRef = (0, import_firestore.doc)(customDb, "app_data", "main");
      const docSnap = await (0, import_firestore.getDoc)(docRef);
      if (!docSnap.exists()) {
        return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y d\u1EEF li\u1EC7u trong b\u1EA3ng app_data/main tr\xEAn Firebase!" });
      }
      const syncedData = docSnap.data();
      syncedData.username = artist.username;
      if (!syncedData.demos) syncedData.demos = [];
      if (!syncedData.playlists) syncedData.playlists = [];
      let downloadCount = 0;
      let failCount = 0;
      const artistUploadsDir = import_path.default.join(process.cwd(), "public", "uploads", artist.username);
      await fs.mkdir(artistUploadsDir, { recursive: true });
      const cleanUrlToFilename = (urlStr, prefix, defaultExt, idx) => {
        try {
          const u = new URL(urlStr);
          const pathname = u.pathname;
          let base = import_path.default.basename(pathname);
          base = decodeURIComponent(base).split("?")[0].split("/").pop() || "";
          if (base && base.includes(".")) {
            const ext = import_path.default.extname(base);
            const name = import_path.default.basename(base, ext).replace(/[^a-zA-Z0-9_-]/g, "_");
            return `${prefix}_${idx}_${name}${ext}`;
          }
        } catch (e) {
        }
        return `${prefix}_${idx}_${Date.now()}${defaultExt}`;
      };
      async function downloadMediaFile(url, destPath) {
        try {
          let fetchUrl = url;
          const driveRegex = /(?:drive\.google\.com\/(?:file\/d\/|open\?id=)|docs\.google\.com\/(?:file\/d\/|open\?id=))([a-zA-Z0-9_-]{25,})/;
          const match = url.match(driveRegex);
          if (match && match[1]) {
            fetchUrl = `https://docs.google.com/uc?export=download&id=${match[1]}`;
          }
          const res2 = await fetch(fetchUrl, {
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
          });
          if (!res2.ok) {
            console.error(`Failed to download ${url}: status ${res2.status}`);
            return false;
          }
          const buffer = Buffer.from(await res2.arrayBuffer());
          await fs.writeFile(destPath, buffer);
          return true;
        } catch (err) {
          console.error(`Error downloading media ${url}:`, err);
          return false;
        }
      }
      if (syncedData.aboutMe && syncedData.aboutMe.avatarUrl && syncedData.aboutMe.avatarUrl.startsWith("http") && !syncedData.aboutMe.avatarUrl.includes("/uploads/")) {
        const url = syncedData.aboutMe.avatarUrl;
        const filename = cleanUrlToFilename(url, "avatar", ".jpg", 0);
        const dest = import_path.default.join(artistUploadsDir, filename);
        if (await downloadMediaFile(url, dest)) {
          syncedData.aboutMe.avatarUrl = `/uploads/${artist.username}/${filename}`;
          downloadCount++;
        } else {
          failCount++;
        }
      }
      if (syncedData.homeCoverUrl && syncedData.homeCoverUrl.startsWith("http") && !syncedData.homeCoverUrl.includes("/uploads/")) {
        const url = syncedData.homeCoverUrl;
        const filename = cleanUrlToFilename(url, "home_cover", ".jpg", 0);
        const dest = import_path.default.join(artistUploadsDir, filename);
        if (await downloadMediaFile(url, dest)) {
          syncedData.homeCoverUrl = `/uploads/${artist.username}/${filename}`;
          downloadCount++;
        } else {
          failCount++;
        }
      }
      if (Array.isArray(syncedData.slideshowImages)) {
        for (let i = 0; i < syncedData.slideshowImages.length; i++) {
          const url = syncedData.slideshowImages[i];
          if (url && url.startsWith("http") && !url.includes("/uploads/")) {
            const filename = cleanUrlToFilename(url, "slide", ".jpg", i);
            const dest = import_path.default.join(artistUploadsDir, filename);
            if (await downloadMediaFile(url, dest)) {
              syncedData.slideshowImages[i] = `/uploads/${artist.username}/${filename}`;
              downloadCount++;
            } else {
              failCount++;
            }
          }
        }
      }
      if (Array.isArray(syncedData.demos)) {
        for (let i = 0; i < syncedData.demos.length; i++) {
          const d = syncedData.demos[i];
          if (!d) continue;
          if (d.audioUrl && d.audioUrl.startsWith("http") && !d.audioUrl.includes("/uploads/")) {
            const filename = cleanUrlToFilename(d.audioUrl, "audio", ".mp3", i);
            const dest = import_path.default.join(artistUploadsDir, filename);
            if (await downloadMediaFile(d.audioUrl, dest)) {
              d.audioUrl = `/uploads/${artist.username}/${filename}`;
              downloadCount++;
            } else {
              failCount++;
            }
          }
          if (d.coverUrl && d.coverUrl.startsWith("http") && !d.coverUrl.includes("/uploads/")) {
            const filename = cleanUrlToFilename(d.coverUrl, "cover", ".jpg", i);
            const dest = import_path.default.join(artistUploadsDir, filename);
            if (await downloadMediaFile(d.coverUrl, dest)) {
              d.coverUrl = `/uploads/${artist.username}/${filename}`;
              downloadCount++;
            } else {
              failCount++;
            }
          }
          if (d.backgroundUrl && d.backgroundUrl.startsWith("http") && !d.backgroundUrl.includes("/uploads/")) {
            const filename = cleanUrlToFilename(d.backgroundUrl, "bg", ".jpg", i);
            const dest = import_path.default.join(artistUploadsDir, filename);
            if (await downloadMediaFile(d.backgroundUrl, dest)) {
              d.backgroundUrl = `/uploads/${artist.username}/${filename}`;
              downloadCount++;
            } else {
              failCount++;
            }
          }
        }
      }
      if (Array.isArray(syncedData.playlists)) {
        for (let i = 0; i < syncedData.playlists.length; i++) {
          const p = syncedData.playlists[i];
          if (!p) continue;
          if (p.coverUrl && p.coverUrl.startsWith("http") && !p.coverUrl.includes("/uploads/")) {
            const filename = cleanUrlToFilename(p.coverUrl, "playlist", ".jpg", i);
            const dest = import_path.default.join(artistUploadsDir, filename);
            if (await downloadMediaFile(p.coverUrl, dest)) {
              p.coverUrl = `/uploads/${artist.username}/${filename}`;
              downloadCount++;
            } else {
              failCount++;
            }
          }
        }
      }
      await saveData(artist.username, syncedData);
      res.json({
        success: true,
        message: `\u0110\xE3 t\u1EA3i th\xE0nh c\xF4ng ${downloadCount} t\u1EC7p tin media t\u1EEB Firebase v\u1EC1 Server v\xE0 \u0111\u1ED3ng b\u1ED9 h\xF3a th\xE0nh c\xF4ng c\u1EE5c b\u1ED9! (Th\u1EA5t b\u1EA1i: ${failCount})`
      });
    } catch (e) {
      console.error("L\u1ED7i khi t\u1EA3i media t\u1EEB Firebase:", e);
      res.status(500).json({ error: e.message || "L\u1ED7i kh\xF4ng x\xE1c \u0111\u1ECBnh trong qu\xE1 tr\xECnh t\u1EA3i media." });
    }
  });
  app.post("/api/admin/firebase-wipe", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const defaultData = {
        pageTitle: "",
        artistName: "T\xEAn ngh\u1EC7 s\u0129",
        artistBio: "M\xF4 t\u1EA3 ng\u1EAFn...",
        homeCoverUrl: "",
        faviconUrl: "",
        ogImageUrl: "",
        youtubePlaylistUrl: "",
        spotifyUrl: "",
        releasedSongs: [],
        demos: [],
        playlists: [],
        menus: [
          { id: "m1", type: "vault", title: "Kho Nh\u1EA1c", isVisible: true },
          { id: "m2", type: "about", title: "V\u1EC1 T\xF4i", isVisible: true },
          { id: "m3", type: "bio", title: "Ti\u1EC3u S\u1EED", isVisible: true }
        ],
        aboutMe: {},
        biography: { education: [], experience: [] },
        adminPassword: currentAdminPassword,
        memberPassword: currentMemberPassword
      };
      await (0, import_firestore.setDoc)(DOC_REF, defaultData);
      res.json({ success: true });
    } catch (error) {
      console.error("L\u1ED7i khi x\xF3a DB Firebase:", error);
      res.status(500).json({ error: error.message });
    }
  });
  app.post("/api/profile/cancel-request", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const artist = req.artist;
    if (artist) {
      if (req.body.type === "name") {
        delete artist.pendingNameChange;
        delete data.pendingNameChange;
        const idx = artists.findIndex((a) => a.username === artist.username);
        if (idx !== -1) {
          delete artists[idx].pendingNameChange;
        }
      } else if (req.body.type === "extension") {
        delete artist.pendingExtensionChange;
        delete data.pendingExtensionChange;
        const idx = artists.findIndex((a) => a.username === artist.username);
        if (idx !== -1) {
          delete artists[idx].pendingExtensionChange;
        }
      } else if (req.body.type === "username") {
        delete artist.pendingUsernameChange;
        delete data.pendingUsernameChange;
        const idx = artists.findIndex((a) => a.username === artist.username);
        if (idx !== -1) {
          delete artists[idx].pendingUsernameChange;
        }
      }
      await saveArtists(artists);
      await saveData(artist.username, data);
    }
    res.json({ success: true });
  });
  app.post("/api/profile", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    data.pageTitle = req.body.pageTitle ?? data.pageTitle;
    let nameChangeNotice = false;
    if (req.body.artistName !== void 0 && req.body.artistName !== data.artistName) {
      const artist = req.artist;
      if (artist) {
        artist.pendingNameChange = req.body.artistName;
        data.pendingNameChange = req.body.artistName;
        await saveArtists(artists);
        nameChangeNotice = true;
      }
    }
    if (req.body.username !== void 0 && req.body.username !== req.artist.username) {
      const artist = req.artist;
      if (artist) {
        artist.pendingUsernameChange = req.body.username;
        data.pendingUsernameChange = req.body.username;
        await saveArtists(artists);
        nameChangeNotice = true;
      }
    }
    if (req.body.extension !== void 0 && req.body.extension !== req.artist.extension) {
      const artist = req.artist;
      if (artist) {
        artist.pendingExtensionChange = req.body.extension;
        data.pendingExtensionChange = req.body.extension;
        await saveArtists(artists);
        nameChangeNotice = true;
      }
    }
    if (req.body.defaultLanguage !== void 0) {
      data.defaultLanguage = req.body.defaultLanguage;
      const artist = req.artist;
      if (artist) {
        artist.defaultLanguage = req.body.defaultLanguage;
        await saveArtists(artists);
      }
    }
    data.artistBio = req.body.artistBio ?? data.artistBio;
    if (req.body.homeCoverUrl !== void 0 && req.body.homeCoverUrl !== data.homeCoverUrl) {
      const oldUrl = data.homeCoverUrl;
      data.homeCoverUrl = req.body.homeCoverUrl;
      if (oldUrl) await deleteFileByUrl(oldUrl);
    }
    if (req.body.faviconUrl !== void 0 && req.body.faviconUrl !== data.faviconUrl) {
      const oldUrl = data.faviconUrl;
      data.faviconUrl = req.body.faviconUrl;
      if (oldUrl) await deleteFileByUrl(oldUrl);
    }
    if (req.body.ogImageUrl !== void 0 && req.body.ogImageUrl !== data.ogImageUrl) {
      const oldUrl = data.ogImageUrl;
      data.ogImageUrl = req.body.ogImageUrl;
      if (oldUrl) await deleteFileByUrl(oldUrl);
    }
    data.aboutMe = req.body.aboutMe ?? data.aboutMe;
    data.biography = req.body.biography ?? data.biography;
    data.menus = req.body.menus ?? data.menus;
    data.youtubePlaylistUrl = req.body.youtubePlaylistUrl ?? data.youtubePlaylistUrl;
    data.spotifyUrl = req.body.spotifyUrl ?? data.spotifyUrl;
    data.socialFacebook = req.body.socialFacebook ?? data.socialFacebook;
    data.socialInstagram = req.body.socialInstagram ?? data.socialInstagram;
    data.socialYoutube = req.body.socialYoutube ?? data.socialYoutube;
    data.socialTiktok = req.body.socialTiktok ?? data.socialTiktok;
    data.globalPassword = req.body.globalPassword ?? data.globalPassword;
    data.globalBaseUrl = req.body.globalBaseUrl !== void 0 ? req.body.globalBaseUrl : data.globalBaseUrl;
    if (req.body.customDomain !== void 0) {
      data.customDomain = req.body.customDomain;
      const artist = req.artist || artists.find((a) => a.username === data.username);
      if (artist) {
        artist.customDomain = req.body.customDomain;
        await saveArtists(artists);
      }
    }
    if (req.body.externalWebsiteUrl !== void 0) {
      data.externalWebsiteUrl = req.body.externalWebsiteUrl;
      const artist = req.artist || artists.find((a) => a.username === data.username);
      if (artist) {
        artist.externalWebsiteUrl = req.body.externalWebsiteUrl;
        await saveArtists(artists);
      }
    }
    if (req.body.hideFromHomepage !== void 0 || req.body.isPublic !== void 0) {
      const artist = req.artist || artists.find((a) => a.username === data.username);
      if (artist) {
        if (req.body.hideFromHomepage !== void 0) {
          artist.hideFromHomepage = !!req.body.hideFromHomepage;
          artist.isPublic = !artist.hideFromHomepage;
        }
        if (req.body.isPublic !== void 0) {
          artist.isPublic = !!req.body.isPublic;
          artist.hideFromHomepage = !artist.isPublic;
        }
        await saveArtists(artists);
      }
    }
    if (req.body.hasExternalWebsite !== void 0) {
      data.hasExternalWebsite = req.body.hasExternalWebsite === "true" || req.body.hasExternalWebsite === true;
      const artist = req.artist || artists.find((a) => a.username === data.username);
      if (artist) {
        artist.hasExternalWebsite = data.hasExternalWebsite;
        await saveArtists(artists);
      }
    }
    data.autoSwitchTabs = req.body.autoSwitchTabs !== void 0 ? req.body.autoSwitchTabs : data.autoSwitchTabs;
    data.tab1Name = req.body.tab1Name !== void 0 ? req.body.tab1Name : data.tab1Name;
    data.tab2Name = req.body.tab2Name !== void 0 ? req.body.tab2Name : data.tab2Name;
    data.tab3Name = req.body.tab3Name !== void 0 ? req.body.tab3Name : data.tab3Name;
    if (req.body.hideFromHomepage !== void 0) {
      const hideVal = req.body.hideFromHomepage === "true" || req.body.hideFromHomepage === true;
      data.hideFromHomepage = hideVal;
      const artist = req.artist;
      if (artist) {
        artist.hideFromHomepage = hideVal;
        await saveArtists(artists);
      }
    }
    if (req.body.slideshowImages) data.slideshowImages = req.body.slideshowImages;
    if (req.body.layoutSections !== void 0) data.layoutSections = req.body.layoutSections;
    if (req.body.adminTheme !== void 0) {
      data.adminTheme = req.body.adminTheme;
      const artist = req.artist;
      if (artist) {
        artist.adminTheme = req.body.adminTheme;
        await saveArtists(artists);
      }
    }
    await saveData(data);
    res.json({
      ...data,
      memberPassword: req.artist?.memberPassword || "",
      isMasterAdmin: req.artist?.username === "acxuantai",
      isSpecial: !!req.artist?.isSpecial || req.artist?.username === "acxuantai",
      username: req.artist?.username,
      extension: req.artist?.extension,
      email: req.artist?.email || "",
      pendingNameChange: req.artist?.pendingNameChange,
      pendingUsernameChange: req.artist?.pendingUsernameChange,
      pendingExtensionChange: req.artist?.pendingExtensionChange,
      systemIp: landingConfig.systemIp || "",
      landingConfig,
      roleId: req.artist?.roleId || "",
      maxSongs: req.artist?.maxSongs,
      maxTemplates: req.artist?.maxTemplates,
      vipExpiry: req.artist?.vipExpiry,
      activatedAt: req.artist?.activatedAt || "",
      roleUpgradedAt: req.artist?.roleUpgradedAt || "",
      createdAt: req.artist?.createdAt || "",
      roles: landingConfig.roles || [],
      pendingNameChangeNotice: nameChangeNotice
    });
  });
  app.post("/api/admin/sync-covers-to-cloud", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const data = await loadData(req.artist?.username);
      const logs = [];
      let updatedCount = 0;
      logs.push("B\u1EAFt \u0111\u1EA7u \u0111\u1ED3ng b\u1ED9 h\xF3a to\xE0n b\u1ED9 \u1EA3nh b\xECa c\u0169 l\xEAn Firebase Storage...");
      if (data.homeCoverUrl && !data.homeCoverUrl.includes(firebaseConfig.storageBucket)) {
        logs.push(`\u0110ang x\u1EED l\xFD \u1EA2nh trang ch\u1EE7 (Home Cover): ${data.homeCoverUrl}`);
        const newUrl = await uploadUrlOrFileToCloud(data.homeCoverUrl, data.globalBaseUrl);
        if (newUrl !== data.homeCoverUrl) {
          data.homeCoverUrl = newUrl;
          updatedCount++;
          logs.push(`-> \u0110\u1ED3ng b\u1ED9 th\xE0nh c\xF4ng Home Cover: ${newUrl}`);
        }
      }
      if (data.ogImageUrl && !data.ogImageUrl.includes(firebaseConfig.storageBucket)) {
        logs.push(`\u0110ang x\u1EED l\xFD \u1EA2nh gi\u1EDBi thi\u1EC7u Facebook (OG Image): ${data.ogImageUrl}`);
        const newUrl = await uploadUrlOrFileToCloud(data.ogImageUrl, data.globalBaseUrl);
        if (newUrl !== data.ogImageUrl) {
          data.ogImageUrl = newUrl;
          updatedCount++;
          logs.push(`-> \u0110\u1ED3ng b\u1ED9 th\xE0nh c\xF4ng OG Image: ${newUrl}`);
        }
      }
      if (data.demos && data.demos.length > 0) {
        for (let i = 0; i < data.demos.length; i++) {
          const demo = data.demos[i];
          if (demo.coverUrl && !demo.coverUrl.includes(firebaseConfig.storageBucket)) {
            logs.push(`\u0110ang x\u1EED l\xFD \u1EA2nh B\xECa b\xE0i h\xE1t [${demo.title}]: ${demo.coverUrl}`);
            const newUrl = await uploadUrlOrFileToCloud(demo.coverUrl, data.globalBaseUrl);
            if (newUrl !== demo.coverUrl) {
              demo.coverUrl = newUrl;
              updatedCount++;
              logs.push(`-> \u0110\u1ED3ng b\u1ED9 xong \u1EA2nh B\xECa b\xE0i [${demo.title}] th\xE0nh: ${newUrl}`);
            } else if (!newUrl.includes(firebaseConfig.storageBucket)) {
              logs.push(`\u274C L\u1ED7i \u0111\u1ED3ng b\u1ED9 \u1EA2nh B\xECa b\xE0i [${demo.title}]. Vui l\xF2ng ki\u1EC3m tra l\u1EA1i Firebase Storage!`);
            }
          }
          if (demo.audioUrl && !demo.audioUrl.includes(firebaseConfig.storageBucket)) {
            logs.push(`\u0110ang x\u1EED l\xFD file nh\u1EA1c [${demo.title}]: ${demo.audioUrl}`);
            const newUrl = await uploadUrlOrFileToCloud(demo.audioUrl, data.globalBaseUrl);
            if (newUrl !== demo.audioUrl) {
              demo.audioUrl = newUrl;
              updatedCount++;
              logs.push(`-> \u0110\u1ED3ng b\u1ED9 xong Nh\u1EA1c (Audio) b\xE0i [${demo.title}] th\xE0nh: ${newUrl}`);
            } else if (!newUrl.includes(firebaseConfig.storageBucket)) {
              logs.push(`\u274C L\u1ED7i \u0111\u1ED3ng b\u1ED9 Nh\u1EA1c (Audio) b\xE0i [${demo.title}]. Vui l\xF2ng ki\u1EC3m tra l\u1EA1i Firebase Storage!`);
            }
          }
        }
      }
      if (data.playlists && data.playlists.length > 0) {
        for (let i = 0; i < data.playlists.length; i++) {
          const playlist = data.playlists[i];
          if (playlist.coverUrl && !playlist.coverUrl.includes(firebaseConfig.storageBucket)) {
            logs.push(`\u0110ang x\u1EED l\xFD Danh s\xE1ch ph\xE1t [${playlist.title}]: ${playlist.coverUrl}`);
            const newUrl = await uploadUrlOrFileToCloud(playlist.coverUrl, data.globalBaseUrl);
            if (newUrl !== playlist.coverUrl) {
              playlist.coverUrl = newUrl;
              updatedCount++;
              logs.push(`-> \u0110\u1ED3ng b\u1ED9 xong Playlist [${playlist.title}] th\xE0nh: ${newUrl}`);
            }
          }
        }
      }
      if (updatedCount > 0) {
        await saveData(data);
        logs.push(`\u0110\xE3 l\u01B0u d\u1EEF li\u1EC7u m\u1EDBi c\u1EADp nh\u1EADt v\xE0o Firestore! \u0110\xE3 \u0111\u1ED3ng b\u1ED9 th\xE0nh c\xF4ng ${updatedCount} t\u1EC7p tin.`);
      } else {
        logs.push("Kh\xF4ng c\xF3 t\u1EC7p tin n\xE0o \u0111\u01B0\u1EE3c \u0111\u1ED3ng b\u1ED9. C\xF3 th\u1EC3 t\u1EA5t c\u1EA3 t\u1EC7p \u0111\xE3 \u1EDF tr\xEAn Cloud, ho\u1EB7c Cloud Storage ch\u01B0a \u0111\u01B0\u1EE3c b\u1EADt tr\xEAn Firebase project n\xE0y.");
      }
      res.json({ success: true, updatedCount, logs });
    } catch (err) {
      console.error("L\u1ED7i \u0111\u1ED3ng b\u1ED9 \u1EA3nh b\xECa:", err);
      res.status(500).json({ error: err.message || "L\u1ED7i \u0111\u1ED3ng b\u1ED9 trong qu\xE1 tr\xECnh x\u1EED l\xFD" });
    }
  });
  app.post("/api/admin/create-sqlite-backup", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const backupResult = await createSqliteBackup();
      res.json({ success: true, message: "\u0110\xE3 t\u1EA1o b\u1EA3n sao l\u01B0u SQLite th\xE0nh c\xF4ng!", ...backupResult });
    } catch (err) {
      console.error("L\u1ED7i t\u1EA1o b\u1EA3n sao l\u01B0u SQLite:", err);
      res.status(500).json({ error: err.message || "Kh\xF4ng th\u1EC3 t\u1EA1o b\u1EA3n sao l\u01B0u SQLite" });
    }
  });
  app.get("/api/admin/sqlite-backups", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const backupDir = import_path.default.join(process.cwd(), "backups");
      if (!import_fs.default.existsSync(backupDir)) {
        return res.json([]);
      }
      const files = import_fs.default.readdirSync(backupDir);
      const backupFiles = files.map((filename) => {
        const fullPath = import_path.default.join(backupDir, filename);
        const stat = import_fs.default.statSync(fullPath);
        return {
          filename,
          sizeBytes: stat.size,
          createdAt: stat.birthtimeMs || stat.mtimeMs,
          r2Url: s3Client ? `${r2PublicDomain}/backups/${filename}` : null
        };
      }).sort((a, b) => b.createdAt - a.createdAt);
      res.json(backupFiles);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/admin/download-sqlite-backup/:filename", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const filename = import_path.default.basename(req.params.filename);
      const filePath = import_path.default.join(process.cwd(), "backups", filename);
      if (!import_fs.default.existsSync(filePath)) {
        return res.status(404).json({ error: "Backup file not found" });
      }
      res.download(filePath, filename);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/youtube-playlist", async (req, res) => {
    try {
      const plId = req.query.plId;
      const chId = req.query.chId;
      let fetchUrl = "";
      if (plId) {
        fetchUrl = `https://www.youtube.com/playlist?list=${plId}`;
      } else if (chId) {
        fetchUrl = `https://www.youtube.com/channel/${chId}/videos`;
      }
      if (!fetchUrl) return res.json([]);
      const response = await fetch(fetchUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept-Language": "en-US,en;q=0.9"
        }
      });
      if (!response.ok) return res.json([]);
      const text = await response.text();
      const match = text.match(/var ytInitialData = (\{.*?\});<\/script>/);
      let videos = [];
      if (match) {
        const data = JSON.parse(match[1]);
        JSON.stringify(data, (key, value) => {
          if (key === "playlistVideoRenderer" && value.videoId) {
            videos.push({
              title: value.title?.runs?.[0]?.text || "Unknown",
              videoId: value.videoId,
              youtubeUrl: `https://www.youtube.com/watch?v=${value.videoId}`
            });
          }
          if (key === "gridVideoRenderer" && value.videoId) {
            videos.push({
              title: value.title?.runs?.[0]?.text || "Unknown",
              videoId: value.videoId,
              youtubeUrl: `https://www.youtube.com/watch?v=${value.videoId}`
            });
          }
          if (key === "richItemRenderer" && value.content?.videoRenderer?.videoId) {
            videos.push({
              title: value.content.videoRenderer.title?.runs?.[0]?.text || "Unknown",
              videoId: value.content.videoRenderer.videoId,
              youtubeUrl: `https://www.youtube.com/watch?v=${value.content.videoRenderer.videoId}`
            });
          }
          return value;
        });
      }
      const unique = [];
      const ids = /* @__PURE__ */ new Set();
      for (const v of videos) {
        if (!ids.has(v.videoId)) {
          ids.add(v.videoId);
          unique.push(v);
        }
      }
      if (unique.length === 0 && plId) {
        const rssRes = await fetch(`https://www.youtube.com/feeds/videos.xml?playlist_id=${plId}`);
        const rssText = await rssRes.text();
        const entries = rssText.split("<entry>").slice(1);
        unique.push(...entries.map((entry) => {
          const titleMatch = entry.match(/<title>(.*?)<\/title>/);
          const idMatch = entry.match(/<yt:videoId>(.*?)<\/yt:videoId>/);
          return {
            title: titleMatch ? titleMatch[1].replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">") : "Unknown",
            videoId: idMatch ? idMatch[1] : "",
            youtubeUrl: idMatch ? `https://www.youtube.com/watch?v=${idMatch[1]}` : ""
          };
        }).filter((v) => v.videoId));
      }
      res.json(unique);
    } catch (err) {
      res.json([]);
    }
  });
  app.get("/api/spotify-profile", async (req, res) => {
    try {
      const url = req.query.url;
      if (!url) return res.json(null);
      const parts = url.split("/");
      const idStr = parts[parts.length - 1].split("?")[0];
      const fetchUrl = `https://open.spotify.com/artist/${idStr}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4e3);
      try {
        const response = await fetch(fetchUrl, {
          signal: controller.signal,
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" }
        });
        clearTimeout(timeoutId);
        const html = await response.text();
        const imageMatch = html.match(/<meta property="?og:image"? content="([^"]+)"/i);
        const titleMatch = html.match(/<meta property="?og:title"? content="([^"]+)"/i);
        const descMatch = html.match(/<meta property="?og:description"? content="([^"]+)"/i);
        if (!titleMatch && !descMatch) return res.json(null);
        res.json({
          name: titleMatch ? titleMatch[1] : "",
          image: imageMatch ? imageMatch[1] : "",
          description: descMatch ? descMatch[1] : ""
          // Usually contains monthly listeners
        });
      } catch (innerErr) {
        clearTimeout(timeoutId);
        res.json(null);
      }
    } catch (err) {
      res.json(null);
    }
  });
  app.post("/api/released", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    data.releasedSongs = req.body.releasedSongs || [];
    await saveData(data);
    res.json(data);
  });
  const processDriveLink = (url) => {
    if (!url) return url;
    const matchFileD = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    const matchIdParam = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
    const id = matchFileD ? matchFileD[1] : matchIdParam ? matchIdParam[1] : null;
    if (id) {
      return `https://drive.google.com/thumbnail?id=${id}&sz=w1000`;
    }
    return url;
  };
  const parseLyricsBeforeSave = (rawLyrics) => {
    if (!rawLyrics) return "";
    const lines = rawLyrics.split(/\r?\n/);
    const cleanedLines = [];
    let skipBlank = false;
    for (let i = 0; i < lines.length; i++) {
      let textLine = lines[i];
      let trimmed = textLine.trim();
      let lower = trimmed.toLowerCase();
      if (/^\[?ver\s*(\d+)\]?[:]*\s*$/i.test(lower)) {
        textLine = trimmed.replace(/^\[?ver\s*(\d+)\]?[:]*\s*/i, "Verse $1:");
        trimmed = textLine.trim();
        lower = trimmed.toLowerCase();
      } else if (/^\[?rap\]?[:]*\s*$/i.test(lower)) {
        textLine = "Rap:";
        trimmed = textLine.trim();
        lower = trimmed.toLowerCase();
      } else if (/^\[?(pre-chorus|chorus|verse|bridge|drop|ending|coda)\]?[:]*\s*$/i.test(lower) || /^\[?verse\s+(\d+)\]?[:]*\s*$/i.test(lower)) {
        if (!trimmed.startsWith("[")) {
          if (!trimmed.endsWith(":")) {
            textLine = trimmed + ":";
          }
        }
        trimmed = textLine.trim();
        lower = trimmed.toLowerCase();
      }
      const isHeader = lower.includes("pre-chorus") || lower.includes("chorus") || lower.includes("verse") || lower.includes("bridge") || lower.includes("drop") || lower.includes("ending") || lower.includes("coda") || lower.includes("rap");
      const isActuallyHeader = isHeader && (trimmed.endsWith(":") || trimmed.startsWith("[") && trimmed.endsWith("]"));
      if (isActuallyHeader) {
        cleanedLines.push(textLine);
        skipBlank = true;
      } else {
        if (trimmed === "") {
          if (skipBlank) continue;
          cleanedLines.push(textLine);
        } else {
          cleanedLines.push(textLine);
          skipBlank = false;
        }
      }
    }
    return cleanedLines.join("\n");
  };
  app.get("/api/admin/other-songs", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const currentArtist = req.artist;
    if (!currentArtist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    const currentName = currentArtist.artistName.toLowerCase().trim();
    const results = [];
    if (artists.length === 0) {
      await loadArtists();
    }
    for (const a of artists) {
      if (a.username === currentArtist.username) continue;
      try {
        const otherData = await loadData(a.username);
        const demos = otherData.demos || [];
        for (const d of demos) {
          if (d.deleted) continue;
          const singer = (d.singer || "").toLowerCase();
          const composer = (d.composer || "").toLowerCase();
          if (singer.includes(currentName) || composer.includes(currentName)) {
            results.push({
              id: d.id,
              slug: d.slug,
              title: d.title,
              singer: d.singer,
              composer: d.composer,
              coverUrl: d.coverUrl,
              audioUrl: d.audioUrl,
              backgroundUrl: d.backgroundUrl,
              lyrics: d.lyrics,
              isReleased: d.isReleased,
              releaseYear: d.releaseYear,
              template: d.template,
              linkType: d.linkType,
              linkZing: d.linkZing,
              linkSpotify: d.linkSpotify,
              linkApple: d.linkApple,
              linkYoutubeMusic: d.linkYoutubeMusic,
              linkYoutube: d.linkYoutube,
              linkDrive: d.linkDrive,
              isBrand: d.isBrand,
              brandName: d.brandName,
              brandBrief: d.brandBrief,
              brandColor: d.brandColor,
              brandLogoUrl: d.brandLogoUrl,
              brandReferenceVideos: d.brandReferenceVideos,
              sourceArtist: {
                username: a.username,
                artistName: a.artistName,
                extension: a.extension
              }
            });
          }
        }
      } catch (err) {
        console.error(`Error loading data for artist ${a.username}:`, err);
      }
    }
    try {
      const currentData = await loadData(currentArtist.username);
      const externalReposts = currentData.externalReposts || [];
      results.push(...externalReposts);
    } catch (err) {
      console.error(`Error loading external reposts for ${currentArtist.username}:`, err);
    }
    res.json(results);
  });
  app.post("/api/admin/add-external-song", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const currentArtist = req.artist;
    if (!currentArtist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ error: "Vui l\xF2ng cung c\u1EA5p URL b\xE0i h\xE1t!" });
    }
    try {
      let cleanUrl = url.trim();
      if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
        cleanUrl = "https://" + cleanUrl;
      }
      const parsed = new URL(cleanUrl);
      const host = parsed.host;
      const pathname = parsed.pathname;
      const match = pathname.match(/\/song\/([^\/]+)/);
      if (!match) {
        return res.status(400).json({ error: "\u0110\u1ECBnh d\u1EA1ng URL kh\xF4ng h\u1EE3p l\u1EC7! URL ph\u1EA3i c\xF3 c\u1EA5u tr\xFAc d\u1EA1ng /song/slug-bai-hat" });
      }
      const songIdOrSlug = match[1];
      const apiEndpoint = `${parsed.protocol}//${host}/api/demos/${songIdOrSlug}`;
      const fetchRes = await fetch(apiEndpoint).catch(() => null);
      if (!fetchRes || !fetchRes.ok) {
        return res.status(404).json({ error: "Kh\xF4ng th\u1EC3 k\u1EBFt n\u1ED1i ho\u1EB7c kh\xF4ng t\xECm th\u1EA5y b\xE0i h\xE1t tr\xEAn h\u1EC7 th\u1ED1ng \u0111\u01B0\u1EE3c ch\u1EC9 \u0111\u1ECBnh!" });
      }
      const song = await fetchRes.json();
      if (!song || !song.title) {
        return res.status(400).json({ error: "D\u1EEF li\u1EC7u ph\u1EA3n h\u1ED3i t\u1EEB h\u1EC7 th\u1ED1ng ngo\xE0i kh\xF4ng \u0111\xFAng \u0111\u1ECBnh d\u1EA1ng!" });
      }
      const currentName = currentArtist.artistName.toLowerCase().trim();
      const singer = (song.singer || "").toLowerCase();
      const composer = (song.composer || "").toLowerCase();
      const author = (song.author || "").toLowerCase();
      if (!singer.includes(currentName) && !composer.includes(currentName) && !author.includes(currentName)) {
        return res.status(400).json({ error: `T\xEAn ngh\u1EC7 s\u0129 "${currentArtist.artistName}" kh\xF4ng n\u1EB1m trong Credit (Ca s\u0129/S\xE1ng t\xE1c) c\u1EE7a b\xE0i h\xE1t n\xE0y!` });
      }
      const currentData = await loadData(currentArtist.username);
      currentData.externalReposts = currentData.externalReposts || [];
      if (currentData.externalReposts.some((x) => x.sourceUrl === cleanUrl || x.id === song.id)) {
        return res.status(400).json({ error: "B\xE0i h\xE1t n\xE0y \u0111\xE3 t\u1ED3n t\u1EA1i trong danh s\xE1ch \u0110\u0103ng l\u1EA1i c\u1EE7a b\u1EA1n!" });
      }
      const newExternal = {
        id: song.id || "ext_" + Date.now(),
        slug: song.slug || song.id,
        title: song.title,
        singer: song.singer,
        composer: song.composer,
        coverUrl: song.coverUrl,
        audioUrl: song.audioUrl,
        backgroundUrl: song.backgroundUrl,
        lyrics: song.lyrics,
        isReleased: song.isReleased,
        releaseYear: song.releaseYear,
        isExternal: true,
        sourceUrl: cleanUrl,
        sourceArtist: {
          username: "external",
          artistName: host,
          extension: host
        }
      };
      currentData.externalReposts.push(newExternal);
      await saveData(currentArtist.username, currentData);
      res.json({ success: true, song: newExternal });
    } catch (err) {
      res.status(500).json({ error: "\u0110\xE3 x\u1EA3y ra l\u1ED7i khi x\u1EED l\xFD b\xE0i h\xE1t ngo\xE0i: " + err.message });
    }
  });
  app.post("/api/admin/remove-external-repost", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const currentArtist = req.artist;
    if (!currentArtist) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ngh\u1EC7 s\u0129!" });
    }
    const { id } = req.body;
    if (!id) {
      return res.status(400).json({ error: "Thi\u1EBFu ID b\xE0i h\xE1t!" });
    }
    try {
      const currentData = await loadData(currentArtist.username);
      currentData.externalReposts = currentData.externalReposts || [];
      const originalLen = currentData.externalReposts.length;
      currentData.externalReposts = currentData.externalReposts.filter((x) => x.id !== id);
      if (currentData.externalReposts.length === originalLen) {
        return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y b\xE0i h\xE1t ngo\xE0i n\xE0y!" });
      }
      await saveData(currentArtist.username, currentData);
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  app.get("/api/admin/tickets", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    await loadTickets();
    if (artists.length === 0) {
      await loadArtists();
    }
    const mappedTickets = tickets.map(mapTicket);
    const filtered = mappedTickets.filter(
      (t) => t.reporterArtist === req.artist?.username || t.sourceArtist === req.artist?.username
    );
    res.json(filtered);
  });
  app.post("/api/admin/tickets/create", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { songId, songTitle, sourceArtist, type, description } = req.body;
    if (!type || !description) {
      return res.status(400).json({ error: "Thi\u1EBFu th\xF4ng tin y\xEAu c\u1EA7u!" });
    }
    await loadTickets();
    const newTicket = {
      id: import_crypto.default.randomBytes(8).toString("hex"),
      type,
      songId: songId || "feedback",
      songTitle: songTitle || "General Feedback",
      sourceArtist: sourceArtist || "system",
      reporterArtist: req.artist.username,
      description,
      status: "open",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      messages: [
        {
          id: import_crypto.default.randomBytes(8).toString("hex"),
          sender: "reporter",
          senderName: req.artist.artistName,
          text: description,
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        }
      ]
    };
    tickets.push(newTicket);
    await saveTickets(tickets);
    if (artists.length === 0) {
      await loadArtists();
    }
    res.json({ success: true, ticket: mapTicket(newTicket) });
  });
  app.post("/api/admin/tickets/:id/message", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: "N\u1ED9i dung tin nh\u1EAFn kh\xF4ng \u0111\u01B0\u1EE3c \u0111\u1EC3 tr\u1ED1ng!" });
    }
    await loadTickets();
    const ticketIdx = tickets.findIndex((t) => t.id === req.params.id);
    if (ticketIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ticket!" });
    }
    const ticket = tickets[ticketIdx];
    const isReporter = req.artist.username === ticket.reporterArtist;
    const isSource = req.artist.username === ticket.sourceArtist;
    const isAdmin = req.artist.username === "acxuantai";
    if (!isReporter && !isSource && !isAdmin) {
      return res.status(403).json({ error: "B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n truy c\u1EADp ticket n\xE0y!" });
    }
    let sender = "reporter";
    if (isReporter) sender = "reporter";
    else if (isSource) sender = "source";
    else if (isAdmin) sender = "admin";
    ticket.messages.push({
      id: import_crypto.default.randomBytes(8).toString("hex"),
      sender,
      senderName: req.artist.artistName,
      text,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    await saveTickets(tickets);
    if (artists.length === 0) {
      await loadArtists();
    }
    res.json({ success: true, ticket: mapTicket(ticket) });
  });
  app.post("/api/admin/tickets/:id/reopen", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    await loadTickets();
    const ticketIdx = tickets.findIndex((t) => t.id === req.params.id);
    if (ticketIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ticket!" });
    }
    const ticket = tickets[ticketIdx];
    const isReporter = req.artist.username === ticket.reporterArtist;
    const isSource = req.artist.username === ticket.sourceArtist;
    const isAdmin = req.artist.username === "acxuantai";
    if (!isAdmin) {
      return res.status(403).json({ error: "Ch\u1EC9 Admin m\u1EDBi c\xF3 quy\u1EC1n m\u1EDF l\u1EA1i ticket!" });
    }
    ticket.status = "open";
    ticket.messages.push({
      sender: "admin",
      senderName: "H\u1EC7 th\u1ED1ng",
      text: "Admin h\u1EC7 th\u1ED1ng \u0111\xE3 m\u1EDF l\u1EA1i ticket n\xE0y.",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    await saveTickets(tickets);
    if (artists.length === 0) {
      await loadArtists();
    }
    res.json({ success: true, ticket: mapTicket(ticket) });
  });
  app.post("/api/admin/tickets/:id/resolve", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    await loadTickets();
    const ticketIdx = tickets.findIndex((t) => t.id === req.params.id);
    if (ticketIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ticket!" });
    }
    const ticket = tickets[ticketIdx];
    const isReporter = req.artist.username === ticket.reporterArtist;
    const isSource = req.artist.username === ticket.sourceArtist;
    const isAdmin = req.artist.username === "acxuantai";
    if (!isReporter && !isSource && !isAdmin) {
      return res.status(403).json({ error: "B\u1EA1n kh\xF4ng c\xF3 quy\u1EC1n c\u1EADp nh\u1EADt ticket n\xE0y!" });
    }
    ticket.status = "resolved";
    ticket.messages.push({
      sender: "admin",
      senderName: "H\u1EC7 th\u1ED1ng",
      text: `Ticket \u0111\xE3 \u0111\u01B0\u1EE3c \u0111\xE1nh d\u1EA5u l\xE0 \u0110\xE3 gi\u1EA3i quy\u1EBFt b\u1EDFi ${req.artist.artistName}.`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    await saveTickets(tickets);
    if (artists.length === 0) {
      await loadArtists();
    }
    res.json({ success: true, ticket: mapTicket(ticket) });
  });
  app.post("/api/admin/tickets/:id/remove-song", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    if (req.artist.username !== "acxuantai") {
      return res.status(403).json({ error: "Ch\u1EC9 Admin h\u1EC7 th\u1ED1ng m\u1EDBi c\xF3 quy\u1EC1n g\u1EE1 b\xE0i h\xE1t!" });
    }
    await loadTickets();
    const ticketIdx = tickets.findIndex((t) => t.id === req.params.id);
    if (ticketIdx === -1) {
      return res.status(404).json({ error: "Kh\xF4ng t\xECm th\u1EA5y ticket!" });
    }
    const ticket = tickets[ticketIdx];
    try {
      const sourceData = await loadData(ticket.sourceArtist);
      const songIdx = sourceData.demos.findIndex((d) => d.id === ticket.songId || d.slug === ticket.songId);
      if (songIdx !== -1) {
        sourceData.demos[songIdx].deleted = true;
        sourceData.demos[songIdx].deletedAt = Date.now();
        await saveData(ticket.sourceArtist, sourceData);
      }
      ticket.status = "removed";
      ticket.messages.push({
        sender: "admin",
        senderName: "H\u1EC7 th\u1ED1ng",
        text: `H\u1EC7 th\u1ED1ng \u0111\xE3 g\u1EE1 b\xE0i h\xE1t n\xE0y kh\u1ECFi k\xEAnh c\u1EE7a ${ticket.sourceArtist} theo y\xEAu c\u1EA7u c\u1EE7a ${mapTicket(ticket).reporter.name}.`,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
      await saveTickets(tickets);
      if (artists.length === 0) {
        await loadArtists();
      }
      res.json({ success: true, ticket: mapTicket(ticket) });
    } catch (err) {
      res.status(500).json({ error: `L\u1ED7i g\u1EE1 b\xE0i h\xE1t: ${err.message}` });
    }
  });
  app.post("/api/demos", upload.fields([{ name: "audio", maxCount: 1 }, { name: "cover", maxCount: 1 }]), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const artist = req.artist;
    let maxLimit = 10;
    if (artist) {
      const roleId = artist.roleId || "free";
      if (roleId === "vip" || roleId === "pro") {
        maxLimit = -1;
      }
      const landingConf = await loadLandingConfig();
      const roleDef = (landingConf.roles || []).find((r) => r.name.toLowerCase() === roleId.toLowerCase());
      if (roleDef && roleDef.maxPosts) {
        if (roleDef.maxPosts === -1 || roleDef.maxPosts === "unlimited") maxLimit = -1;
        else maxLimit = Number(roleDef.maxPosts);
      }
      if (artist.maxSongs !== void 0 && artist.maxSongs !== null) {
        maxLimit = artist.maxSongs;
      }
    }
    if (maxLimit !== -1) {
      const activeCount = data.demos.filter((d) => !d.deleted).length;
      if (activeCount >= maxLimit) {
        return res.status(403).json({ error: `B\u1EA1n \u0111\xE3 \u0111\u1EA1t gi\u1EDBi h\u1EA1n \u0111\u0103ng b\xE0i (${maxLimit} b\xE0i). Vui l\xF2ng n\xE2ng c\u1EA5p h\u1EA1ng th\xE0nh vi\xEAn ho\u1EB7c nh\u1EADp m\xE3 voucher.` });
      }
    }
    const files = req.files;
    const audioFile = files["audio"]?.[0];
    const coverFile = files["cover"]?.[0];
    let slug = req.body.slug || req.body.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    let existingSlug = data.demos.find((d) => d.slug === slug);
    if (existingSlug) slug = slug + "-" + Date.now().toString().slice(-4);
    let coverUrl = "";
    const artistId = req.artist?.id || "common";
    if (coverFile) {
      coverUrl = await uploadLocalToCloud(coverFile.path, coverFile.filename, coverFile.mimetype, artistId);
    } else {
      const inputCover = req.body.coverUrl ? processDriveLink(req.body.coverUrl) : "";
      if (inputCover) {
        coverUrl = inputCover;
      } else {
        coverUrl = "";
      }
    }
    let audioUrl = "";
    if (audioFile) {
      try {
        const convertedPath = await convertAudioToMp3(audioFile.path);
        audioUrl = await uploadLocalToCloud(convertedPath, audioFile.filename.replace(/\.[^/.]+$/, "") + ".mp3", "audio/mpeg", artistId);
        await fs.unlink(convertedPath).catch(() => {
        });
        await fs.unlink(audioFile.path).catch(() => {
        });
      } catch (err) {
        console.error("Audio conversion failed, falling back to original:", err);
        audioUrl = await uploadLocalToCloud(audioFile.path, audioFile.filename, audioFile.mimetype, artistId);
        await fs.unlink(audioFile.path).catch(() => {
        });
      }
    } else {
      audioUrl = req.body.audioUrl || "";
    }
    const newDemo = {
      id: Date.now().toString(),
      slug,
      title: req.body.title,
      author: req.body.author || "",
      audioUrl,
      backupAudioUrl: audioFile ? audioUrl : req.body.backupAudioUrl || "",
      coverUrl,
      secretKey: import_crypto.default.randomBytes(8).toString("hex"),
      backgroundUrl: processDriveLink(req.body.backgroundUrl || ""),
      lyrics: parseLyricsBeforeSave(req.body.lyrics || ""),
      template: req.body.template || "1",
      status: req.body.status || "public",
      password: req.body.password ? import_bcryptjs.default.hashSync(req.body.password, 10) : "",
      createdAt: Date.now(),
      composer: req.body.composer || data.artistName || "Ngh\u1EC7 s\u0129",
      singer: req.body.singer || data.artistName || "Ngh\u1EC7 s\u0129",
      isReleased: req.body.isReleased === "true",
      isDraft: req.body.isDraft === "true",
      releaseYear: req.body.releaseYear || "",
      playlistIds: req.body.playlistIds ? JSON.parse(req.body.playlistIds) : [],
      achievements: req.body.achievements ? JSON.parse(req.body.achievements) : [],
      linkType: req.body.linkType || "direct",
      linkZing: req.body.linkZing || "",
      linkSpotify: req.body.linkSpotify || "",
      linkApple: req.body.linkApple || "",
      linkYoutubeMusic: req.body.linkYoutubeMusic || "",
      linkYoutube: req.body.linkYoutube || "",
      linkDrive: req.body.linkDrive || "",
      musicProducer: req.body.musicProducer || "",
      isBrand: req.body.isBrand === "true",
      brandName: req.body.brandName || "",
      brandBrief: req.body.brandBrief || "",
      brandLogoUrl: req.body.brandLogoUrl || "",
      brandColor: req.body.brandColor || "",
      brandReferenceVideos: req.body.brandReferenceVideos ? JSON.parse(req.body.brandReferenceVideos) : []
    };
    data.demos.push(newDemo);
    await saveData(data);
    res.json(newDemo);
  });
  app.post("/api/demos/:id/update", upload.fields([{ name: "audio", maxCount: 1 }, { name: "cover", maxCount: 1 }]), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const idx = data.demos.findIndex((d) => d.id === req.params.id || d.slug === req.params.id);
    if (idx >= 0) {
      const files = req.files;
      const audioFile = files?.["audio"]?.[0];
      const coverFile = files?.["cover"]?.[0];
      let updatedData = { ...req.body };
      if (updatedData.lyrics) {
        updatedData.lyrics = parseLyricsBeforeSave(updatedData.lyrics);
      }
      let newAudioUrl = "";
      const artistId = req.artist?.id || "common";
      if (audioFile) {
        try {
          const convertedPath = await convertAudioToMp3(audioFile.path);
          newAudioUrl = await uploadLocalToCloud(convertedPath, audioFile.filename.replace(/\.[^/.]+$/, "") + ".mp3", "audio/mpeg", artistId);
          await fs.unlink(convertedPath).catch(() => {
          });
          await fs.unlink(audioFile.path).catch(() => {
          });
        } catch (err) {
          console.error("Audio conversion failed, falling back to original:", err);
          newAudioUrl = await uploadLocalToCloud(audioFile.path, audioFile.filename, audioFile.mimetype, artistId);
          await fs.unlink(audioFile.path).catch(() => {
          });
        }
      } else if (req.body.audioUrl !== void 0 && req.body.audioUrl !== data.demos[idx].audioUrl) {
        newAudioUrl = req.body.audioUrl;
      }
      if (newAudioUrl) {
        const oldAudioUrl = data.demos[idx].audioUrl;
        const oldBackupUrl = data.demos[idx].backupAudioUrl;
        if (oldBackupUrl && oldBackupUrl !== oldAudioUrl && oldBackupUrl !== newAudioUrl) {
          console.log(`[Revert/Cleanup] \u0110ang d\u1ECDn d\u1EB9p file nh\u1EA1c c\u0169 nh\u1EA5t khi up b\u1EA3n th\u1EE9 3+: ${oldBackupUrl}`);
          await deleteFileByUrl(oldBackupUrl);
        }
        updatedData.audioUrl = newAudioUrl;
        updatedData.backupAudioUrl = oldAudioUrl || newAudioUrl;
      } else {
        if (req.body.backupAudioUrl !== void 0) {
          updatedData.backupAudioUrl = req.body.backupAudioUrl;
        }
      }
      if (coverFile) {
        const oldCoverUrl = data.demos[idx].coverUrl;
        updatedData.coverUrl = await uploadLocalToCloud(coverFile.path, coverFile.filename, coverFile.mimetype, artistId);
        if (oldCoverUrl && oldCoverUrl !== updatedData.coverUrl) {
          await deleteFileByUrl(oldCoverUrl);
        }
      } else if (req.body.coverUrl !== void 0) {
        const inputCover = processDriveLink(req.body.coverUrl);
        if (!inputCover) {
          if (data.demos[idx].coverUrl) {
            await deleteFileByUrl(data.demos[idx].coverUrl);
          }
          updatedData.coverUrl = "";
        } else {
          if (data.demos[idx].coverUrl && data.demos[idx].coverUrl !== inputCover) {
            await deleteFileByUrl(data.demos[idx].coverUrl);
          }
          updatedData.coverUrl = inputCover;
        }
      }
      if (req.body.backgroundUrl !== void 0) {
        updatedData.backgroundUrl = processDriveLink(req.body.backgroundUrl);
      }
      if (updatedData.composer === "") updatedData.composer = data.artistName || "Ngh\u1EC7 s\u0129";
      if (updatedData.singer === "") updatedData.singer = data.artistName || "Ngh\u1EC7 s\u0129";
      if (!updatedData.composer && !data.demos[idx].composer) updatedData.composer = data.artistName || "Ngh\u1EC7 s\u0129";
      if (!updatedData.singer && !data.demos[idx].singer) updatedData.singer = data.artistName || "Ngh\u1EC7 s\u0129";
      if (req.body.isReleased !== void 0) {
        updatedData.isReleased = req.body.isReleased === "true";
      }
      if (req.body.isBrand !== void 0) {
        updatedData.isBrand = req.body.isBrand === "true";
      }
      if (req.body.brandReferenceVideos !== void 0) {
        updatedData.brandReferenceVideos = JSON.parse(req.body.brandReferenceVideos);
      }
      if (req.body.isDraft !== void 0) {
        updatedData.isDraft = req.body.isDraft === "true";
      }
      if (req.body.playlistIds !== void 0) {
        updatedData.playlistIds = JSON.parse(req.body.playlistIds);
      }
      if (req.body.achievements !== void 0) {
        updatedData.achievements = JSON.parse(req.body.achievements);
      }
      data.demos[idx] = { ...data.demos[idx], ...updatedData };
      await saveData(data);
      res.json(data.demos[idx]);
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/demos/:id/revert", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const idx = data.demos.findIndex((d) => d.id === req.params.id || d.slug === req.params.id);
    if (idx >= 0) {
      const demo = data.demos[idx];
      const audioUrl = demo.audioUrl;
      const backupAudioUrl = demo.backupAudioUrl;
      if (!backupAudioUrl || backupAudioUrl === audioUrl) {
        return res.status(400).json({ error: "Kh\xF4ng c\xF3 phi\xEAn b\u1EA3n nh\u1EA1c tr\u01B0\u1EDBc \u0111\xF3 \u0111\u1EC3 kh\xF4i ph\u1EE5c!" });
      }
      demo.audioUrl = backupAudioUrl;
      demo.backupAudioUrl = audioUrl;
      await saveData(data);
      res.json(demo);
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/admin/reset-secret-links", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    data.demos = data.demos.map((d) => ({
      ...d,
      secretKey: import_crypto.default.randomBytes(8).toString("hex")
    }));
    await saveData(data);
    res.json({ success: true });
  });
  app.post("/api/demos/:id/reset-secret", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    let found = false;
    data.demos = data.demos.map((d) => {
      if (d.id === req.params.id || d.slug === req.params.id) {
        d.secretKey = import_crypto.default.randomBytes(8).toString("hex");
        found = true;
      }
      return d;
    });
    if (found) {
      await saveData(data);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/demos/:id/delete", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const idx = data.demos.findIndex((d) => d.id === req.params.id || d.slug === req.params.id);
    if (idx >= 0) {
      data.demos[idx].deleted = true;
      data.demos[idx].deletedAt = Date.now();
      await saveData(data);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/demos/:id/restore", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const idx = data.demos.findIndex((d) => d.id === req.params.id || d.slug === req.params.id);
    if (idx >= 0) {
      data.demos[idx].deleted = false;
      delete data.demos[idx].deletedAt;
      await saveData(data);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/demos/:id/duplicate", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const originalDemo = data.demos.find((d) => d.id === req.params.id || d.slug === req.params.id);
    if (originalDemo) {
      const newId = Math.random().toString(36).substring(2, 9);
      const originalSlug = originalDemo.slug || originalDemo.id;
      let newSlug = originalSlug + "-copy-" + Math.random().toString(36).substring(2, 6);
      const newDemo = {
        ...originalDemo,
        id: newId,
        slug: newSlug,
        title: originalDemo.title + " (Copy)",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        isReleased: false,
        isDraft: true,
        deleted: false,
        deletedAt: void 0
      };
      data.demos.push(newDemo);
      await saveData(data);
      res.json(newDemo);
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/admin/reorder-demos", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { demoIds } = req.body;
    if (!Array.isArray(demoIds)) {
      return res.status(400).json({ error: "Invalid payload" });
    }
    const data = await loadData(req.artist?.username);
    const demosMap = new Map(data.demos.map((d) => [d.id, d]));
    const orderedDemos = [];
    demoIds.forEach((id) => {
      const demo = demosMap.get(id);
      if (demo) {
        orderedDemos.push(demo);
        demosMap.delete(id);
      }
    });
    demosMap.forEach((demo) => {
      orderedDemos.push(demo);
    });
    data.demos = orderedDemos;
    await saveData(data);
    res.json({ success: true, demos: data.demos });
  });
  app.post("/api/playlists", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const newPlaylist = {
      id: Date.now().toString(),
      title: req.body.title || "Untitled Playlist",
      isDraft: req.body.isDraft || false,
      password: req.body.password || "",
      secretLink: req.body.secretLink || ""
    };
    if (!data.playlists) data.playlists = [];
    data.playlists.push(newPlaylist);
    await saveData(data);
    res.json(newPlaylist);
  });
  app.post("/api/playlists/:id/update", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    if (!data.playlists) data.playlists = [];
    const idx = data.playlists.findIndex((p) => p.id === req.params.id);
    if (idx >= 0) {
      if (req.body.title !== void 0) data.playlists[idx].title = req.body.title;
      if (req.body.coverUrl !== void 0 && req.body.coverUrl !== data.playlists[idx].coverUrl) {
        const oldUrl = data.playlists[idx].coverUrl;
        data.playlists[idx].coverUrl = req.body.coverUrl;
        if (oldUrl) await deleteFileByUrl(oldUrl);
      }
      if (req.body.songIds !== void 0) data.playlists[idx].songIds = req.body.songIds;
      if (req.body.isDraft !== void 0) data.playlists[idx].isDraft = req.body.isDraft;
      if (req.body.password !== void 0) data.playlists[idx].password = req.body.password;
      if (req.body.secretLink !== void 0) data.playlists[idx].secretLink = req.body.secretLink;
      await saveData(data);
      res.json(data.playlists[idx]);
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/playlists/:id/delete", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    if (!data.playlists) data.playlists = [];
    const idx = data.playlists.findIndex((p) => p.id === req.params.id);
    if (idx >= 0) {
      data.playlists[idx].deleted = true;
      data.playlists[idx].deletedAt = Date.now();
      await saveData(data);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/playlists/:id/restore", async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    if (!data.playlists) data.playlists = [];
    const idx = data.playlists.findIndex((p) => p.id === req.params.id);
    if (idx >= 0) {
      data.playlists[idx].deleted = false;
      delete data.playlists[idx].deletedAt;
      await saveData(data);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Not found" });
    }
  });
  app.post("/api/admin/reorder-playlists", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { playlistIds } = req.body;
    if (!Array.isArray(playlistIds)) {
      return res.status(400).json({ error: "Invalid payload" });
    }
    const data = await loadData(req.artist?.username);
    const playlistsMap = new Map((data.playlists || []).map((p) => [p.id, p]));
    const orderedPlaylists = [];
    playlistIds.forEach((id) => {
      const pl = playlistsMap.get(id);
      if (pl) {
        orderedPlaylists.push(pl);
        playlistsMap.delete(id);
      }
    });
    playlistsMap.forEach((pl) => {
      orderedPlaylists.push(pl);
    });
    data.playlists = orderedPlaylists;
    await saveData(data);
    res.json({ success: true, playlists: data.playlists });
  });
  app.post("/api/admin/save-templates", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { configs } = req.body;
    if (!Array.isArray(configs)) {
      return res.status(400).json({ error: "Invalid payload" });
    }
    const data = await loadData(req.artist?.username);
    data.templateConfigs = configs;
    await saveData(data);
    res.json({ success: true });
  });
  app.post("/api/demos/:id/verify", async (req, res) => {
    const data = await loadData(req.artist?.username);
    let demo = data.demos.find((d) => d.id === req.params.id || d.slug === req.params.id);
    if (!demo) return res.status(404).json({ error: "Not found" });
    let isAuthorized = false;
    const resolveDemoPassword = (d, gPass) => {
      let p = d.password;
      if (typeof p === "boolean" || p === "true" || p === "false") {
        p = gPass;
      }
      return p && p !== "false" ? String(p) : gPass ? String(gPass) : null;
    };
    const expectedPassword = demo.linkType === "indirect" ? resolveDemoPassword(demo, data.globalPassword) : demo.isReleased ? null : resolveDemoPassword(demo, data.globalPassword);
    if (expectedPassword && verifyPassword(req.body.password, expectedPassword)) {
      isAuthorized = true;
    }
    if (!isAuthorized && req.body.playlistId && req.body.playlistToken) {
      const playlist = data.playlists?.find((p) => p.id === req.body.playlistId);
      if (playlist) {
        if (playlist.password && playlist.password === req.body.playlistToken || playlist.secretLink && playlist.secretLink === req.body.playlistToken) {
          isAuthorized = true;
        }
      }
    }
    if (!expectedPassword || isAuthorized) {
      if (!demo.coverUrl) {
        const imagesToUse = data.slideshowImages && data.slideshowImages.length > 0 ? data.slideshowImages : ["https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80"];
        const idStr = String(demo.id || "");
        const hash = Array.from(idStr).reduce((sum, char) => sum + char.charCodeAt(0), 0);
        demo = { ...demo, coverUrl: imagesToUse[hash % imagesToUse.length] };
      }
      const formattedDemo = {
        ...demo,
        audioUrl: formatUrl(demo.audioUrl, data.globalBaseUrl),
        coverUrl: formatUrl(demo.coverUrl, data.globalBaseUrl),
        backgroundUrl: formatUrl(demo.backgroundUrl, data.globalBaseUrl),
        globalCoverUrl: formatUrl(data.homeCoverUrl, data.globalBaseUrl)
      };
      res.json({ success: true, demo: formattedDemo });
    } else {
      res.status(401).json({ error: "Sai m\u1EADt kh\u1EA9u" });
    }
  });
  app.post("/api/playlists/:id/verify", async (req, res) => {
    const data = await loadData(req.artist?.username);
    let playlist = data.playlists?.find((p) => p.id === req.params.id);
    if (!playlist) return res.status(404).json({ error: "Not found" });
    if (req.body.password && playlist.password && verifyPassword(req.body.password, playlist.password)) {
      res.json({ success: true, token: playlist.password });
    } else if (req.body.secretLink && playlist.secretLink && playlist.secretLink === req.body.secretLink) {
      res.json({ success: true, token: playlist.secretLink });
    } else {
      res.status(401).json({ error: "Wrong password or secret link" });
    }
  });
  app.get("/api/playlists/:id", async (req, res) => {
    const data = await loadData(req.artist?.username);
    const playlist = data.playlists?.find((p) => p.id === req.params.id && !p.deleted);
    if (!playlist) return res.status(404).json({ error: "Playlist not found" });
    const isUserAdmin = isRequestAdmin(req);
    const isUserMember = isRequestMember(req);
    let authorized = isUserAdmin;
    if (!authorized) {
      const token = req.headers["x-playlist-token"] || req.query.token;
      if (playlist.password && playlist.password === token || playlist.secretLink && playlist.secretLink === token) {
        authorized = true;
      } else if (!playlist.password && !playlist.secretLink) {
        authorized = true;
      }
    }
    if (!authorized) {
      return res.status(401).json({ error: "M\u1EADt kh\u1EA9u kh\xF4ng \u0111\xFAng", isProtected: true, coverUrl: playlist.coverUrl ? formatUrl(playlist.coverUrl, data.globalBaseUrl) : void 0, title: playlist.title, artistExtension: req.artist?.username });
    }
    let songs = data.demos.filter((d) => {
      if (d.deleted) return false;
      if (d.status !== "public" && !isUserAdmin) return false;
      return d.playlistIds && d.playlistIds.includes(playlist.id);
    });
    if (playlist.songIds && playlist.songIds.length > 0) {
      songs.sort((a, b) => {
        const indexA = playlist.songIds.indexOf(a.id);
        const indexB = playlist.songIds.indexOf(b.id);
        if (indexA === -1 && indexB === -1) return 0;
        if (indexA === -1) return 1;
        if (indexB === -1) return -1;
        return indexA - indexB;
      });
    }
    songs = songs.map((d) => {
      let coverToUse = d.coverUrl || "";
      if (!coverToUse) {
        if (data.aboutMe?.avatarUrl) coverToUse = data.aboutMe.avatarUrl;
        else if (data.homeCoverUrl) coverToUse = data.homeCoverUrl;
      }
      if (!coverToUse && data.slideshowImages && data.slideshowImages.length > 0) {
        const idStr = String(d.id || "");
        let hash = 0;
        for (let i = 0; i < idStr.length; i++) {
          hash += idStr.charCodeAt(i);
        }
        coverToUse = data.slideshowImages[hash % data.slideshowImages.length];
      }
      if (!coverToUse) {
        coverToUse = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80";
      }
      return {
        id: d.id,
        slug: d.slug,
        title: d.title,
        singer: d.singer,
        author: d.author,
        composer: d.composer,
        coverUrl: formatUrl(coverToUse, data.globalBaseUrl),
        requiresPassword: isUserMember ? false : !!(!d.isReleased && (d.password || data.globalPassword))
      };
    });
    const formattedPlaylist = {
      ...playlist,
      coverUrl: playlist.coverUrl ? formatUrl(playlist.coverUrl, data.globalBaseUrl) : songs[0]?.coverUrl || "",
      password: !!playlist.password,
      hasSecretLink: !!playlist.secretLink,
      secretLink: void 0,
      artistExtension: req.artist?.username
    };
    res.json({ playlist: formattedPlaylist, songs, artistExtension: req.artist?.username });
  });
  app.get("/api/demos/:id", async (req, res) => {
    const data = await loadData(req.artist?.username);
    let demo = data.demos.find((d) => (d.id === req.params.id || d.slug === req.params.id) && !d.deleted);
    if (!demo) return res.status(404).json({ error: "Not found" });
    if (!demo.coverUrl) {
      if (data.aboutMe?.avatarUrl) {
        demo = { ...demo, coverUrl: data.aboutMe.avatarUrl };
      } else if (data.homeCoverUrl) {
        demo = { ...demo, coverUrl: data.homeCoverUrl };
      } else {
        const imagesToUse = data.slideshowImages && data.slideshowImages.length > 0 ? data.slideshowImages : ["https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80"];
        const idStr = String(demo.id || "");
        let hash = 0;
        for (let i = 0; i < idStr.length; i++) {
          hash += idStr.charCodeAt(i);
        }
        demo = { ...demo, coverUrl: imagesToUse[hash % imagesToUse.length] };
      }
    }
    demo = {
      ...demo,
      audioUrl: formatUrl(demo.audioUrl, data.globalBaseUrl),
      coverUrl: formatUrl(demo.coverUrl, data.globalBaseUrl),
      backgroundUrl: formatUrl(demo.backgroundUrl, data.globalBaseUrl),
      templateConfigs: data.templateConfigs || []
    };
    const resolveDemoPasswordSingle = (d, gPass) => {
      let p = d.password;
      if (typeof p === "boolean" || p === "true" || p === "false") {
        p = gPass;
      }
      return p && p !== "false" ? String(p) : gPass ? String(gPass) : null;
    };
    const expectedPassword = demo.linkType === "indirect" ? resolveDemoPasswordSingle(demo, data.globalPassword) : demo.isReleased ? null : resolveDemoPasswordSingle(demo, data.globalPassword);
    const isUserAdmin = isRequestAdmin(req);
    const isUserMember = isRequestMember(req);
    const fromPlaylist = req.query.fromPlaylist === "true";
    const providedSecret = req.query.secret;
    let isValidSecret = !!(demo.secretKey && providedSecret && demo.secretKey === providedSecret);
    if (!isValidSecret && req.query.playlistId && req.query.playlistToken) {
      const playlist = data.playlists?.find((p) => p.id === req.query.playlistId);
      if (playlist) {
        if (playlist.password && playlist.password === req.query.playlistToken || playlist.secretLink && playlist.secretLink === req.query.playlistToken) {
          isValidSecret = true;
        }
      }
    }
    if (expectedPassword && expectedPassword !== req.query.pwd && !isValidSecret && !isUserAdmin && !isUserMember) {
      return res.json({
        id: demo.id,
        title: demo.title,
        singer: demo.singer,
        author: demo.author,
        composer: demo.composer,
        template: demo.template,
        coverUrl: demo.coverUrl,
        backgroundUrl: demo.backgroundUrl,
        globalCoverUrl: formatUrl(data.homeCoverUrl, data.globalBaseUrl),
        slideshowImages: data.slideshowImages || [],
        requiresPassword: true,
        hasPassword: true,
        artistExtension: req.artist?.username
      });
    }
    res.json({ ...demo, artistExtension: req.artist?.username, slideshowImages: data.slideshowImages || [], globalCoverUrl: formatUrl(data.homeCoverUrl, data.globalBaseUrl), requiresPassword: !!expectedPassword && !isValidSecret && !isUserMember, hasPassword: !!expectedPassword });
  });
  app.use("/uploads", import_express.default.static(import_path.default.join(process.cwd(), "public", "uploads")));
  app.use("/uploads", import_express.default.static(import_path.default.join(process.cwd(), "uploads")));
  async function saveAndCloudSyncUploadedFile(localFilePath, artistId, mimeType) {
    const filename = import_path.default.basename(localFilePath);
    const relPath = `uploads/${artistId}/${filename}`;
    let resultUrl = `/uploads/${artistId}/${filename}`;
    if (s3Client) {
      try {
        const fileBuffer = await fs.readFile(localFilePath);
        const command = new PutObjectCommandClass({
          Bucket: r2BucketName,
          Key: relPath,
          Body: fileBuffer,
          ContentType: mimeType
        });
        await s3Client.send(command);
        resultUrl = `${r2PublicDomain}/${relPath}`;
        console.log(`\u2705 [Cloudflare R2 Uploaded] -> ${resultUrl}`);
      } catch (r2Err) {
        console.error(`\u274C [Cloudflare R2 Upload Error]:`, r2Err.message);
      }
    }
    if (artistId === "acxuantai" && !isFirestoreDisabled && firebaseStorage) {
      try {
        const fileBuffer = await fs.readFile(localFilePath);
        const storageRef = (0, import_storage.ref)(firebaseStorage, relPath);
        await (0, import_storage.uploadBytes)(storageRef, fileBuffer, { contentType: mimeType });
        console.log(`\u2705 [Firebase Extra Copy Uploaded for acxuantai]: ${relPath}`);
      } catch (fbErr) {
        console.error(`\u26A0\uFE0F [Firebase Extra Copy Error for acxuantai]:`, fbErr.message);
      }
    }
    return resultUrl;
  }
  app.post("/api/upload", (req, res, next) => {
    upload.single("file")(req, res, (err) => {
      if (err) {
        console.error("Multer error during upload:", err);
        return res.status(413).json({ error: err.message });
      }
      next();
    });
  }, async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const artistId = req.artist?.username || req.artist?.extension || req.artist?.id || "common";
    if (req.file) {
      const uploadDir = import_path.default.join(process.cwd(), "public", "uploads", artistId);
      if (!import_fs.default.existsSync(uploadDir)) {
        import_fs.default.mkdirSync(uploadDir, { recursive: true });
      }
      if (req.file.mimetype.startsWith("image/")) {
        try {
          const isPng = req.file.mimetype === "image/png" || req.file.originalname.toLowerCase().endsWith(".png");
          const ext = isPng ? "png" : "jpg";
          const optimizedFilename = `${req.file.filename.split(".")[0]}-${Date.now()}.${ext}`;
          const optimizedPath = import_path.default.join(uploadDir, optimizedFilename);
          const s = getSharp(req.file.path);
          if (!s) throw new Error("sharp not available");
          let sharpInstance = s.resize({ width: 1600, withoutEnlargement: true });
          if (isPng) {
            sharpInstance = sharpInstance.png({ palette: true, quality: 85 });
          } else {
            sharpInstance = sharpInstance.jpeg({ quality: 80, progressive: true });
          }
          await sharpInstance.toFile(optimizedPath);
          await fs.unlink(req.file.path).catch(() => {
          });
          const mimeType = isPng ? "image/png" : "image/jpeg";
          const finalUrl = await saveAndCloudSyncUploadedFile(optimizedPath, artistId, mimeType);
          return res.json({ url: finalUrl });
        } catch (error) {
          console.error("L\u1ED7i n\xE9n \u1EA3nh:", error);
          const finalUrl = await saveAndCloudSyncUploadedFile(req.file.path, artistId, req.file.mimetype);
          return res.json({ url: finalUrl });
        }
      } else {
        const isWav = req.file.originalname.toLowerCase().endsWith(".wav") || req.file.mimetype.includes("wav") || req.file.mimetype.includes("wave") || req.file.mimetype.includes("x-wav");
        const isM4a = req.file.originalname.toLowerCase().endsWith(".m4a") || req.file.mimetype.includes("m4a") || req.file.mimetype.includes("x-m4a") || req.file.mimetype.includes("audio/mp4");
        if (isWav || isM4a) {
          try {
            const isWavFile = isWav;
            console.log(`\u0110ang ch\u1EA1y c\u01A1 ch\u1EBF t\u1EF1 chuy\u1EC3n \u0111\u1ED5i: File ${isWavFile ? "WAV" : "M4A"} \u0111\u01B0\u1EE3c ph\xE1t hi\u1EC7n (${req.file.originalname}). Kh\u1EDFi \u0111\u1ED9ng FFmpeg \u0111\u1EC3 convert th\xE0nh MP3.`);
            const srcPath = req.file.path;
            const mp3Filename = `${req.file.filename.split(".")[0]}-${Date.now()}.mp3`;
            const mp3Path = import_path.default.join(process.cwd(), "public", "uploads", artistId, mp3Filename);
            if (typeof ffmpeg === "function") {
              await new Promise((resolve, reject) => {
                ffmpeg(srcPath).toFormat("mp3").audioBitrate(320).on("end", () => {
                  console.log(`\u0110\xE3 chuy\u1EC3n \u0111\u1ED5i th\xE0nh c\xF4ng ${isWavFile ? "WAV" : "M4A"} sang MP3 c\u1EE5c b\u1ED9: ${mp3Path}`);
                  resolve();
                }).on("error", (err) => {
                  console.error("L\u1ED7i FFmpeg chuy\u1EC3n \u0111\u1ED5i:", err);
                  reject(err);
                }).save(mp3Path);
              });
              await fs.unlink(srcPath).catch(() => {
              });
              const finalUrl = await saveAndCloudSyncUploadedFile(mp3Path, artistId, "audio/mpeg");
              return res.json({ url: finalUrl });
            } else {
              const finalUrl = await saveAndCloudSyncUploadedFile(req.file.path, artistId, req.file.mimetype);
              return res.json({ url: finalUrl });
            }
          } catch (convertErr) {
            console.error(`L\u1ED7i chuy\u1EC3n \u0111\u1ED5i (${isWav ? ".wav" : ".m4a"} -> .mp3): Kh\xF4i ph\u1EE5c c\u01A1 ch\u1EBF m\u1EB7c \u0111\u1ECBnh.`, convertErr);
            const finalUrl = await saveAndCloudSyncUploadedFile(req.file.path, artistId, req.file.mimetype);
            return res.json({ url: finalUrl });
          }
        } else {
          const finalUrl = await saveAndCloudSyncUploadedFile(req.file.path, artistId, req.file.mimetype);
          return res.json({ url: finalUrl });
        }
      }
    } else {
      res.status(400).json({ error: "Upload failed" });
    }
  });
  app.post("/api/upload-base64", import_express.default.json({ limit: "100mb" }), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const artistId = req.artist?.id || "common";
    try {
      const { image } = req.body;
      if (!image) return res.status(400).json({ error: "No image provided" });
      const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
      const rawBuffer = Buffer.from(base64Data, "base64");
      const filename = `thumb-${Date.now()}.jpg`;
      const filepath = import_path.default.join(process.cwd(), "public", "uploads", artistId, filename);
      await fs.mkdir(import_path.default.dirname(filepath), { recursive: true }).catch(() => {
      });
      const s = getSharp(rawBuffer);
      if (!s) throw new Error("sharp not available");
      const optimizedBuffer = await s.jpeg({ quality: 80, progressive: true }).resize({ width: 1600, withoutEnlargement: true }).toBuffer();
      await fs.writeFile(filepath, optimizedBuffer);
      if (isFirestoreDisabled) {
        res.json({ url: `/uploads/${artistId}/${filename}` });
      } else {
        try {
          const storageRef = (0, import_storage.ref)(firebaseStorage, `uploads/${artistId}/${filename}`);
          await (0, import_storage.uploadBytes)(storageRef, optimizedBuffer, { contentType: "image/jpeg" });
          const cloudUrl = await (0, import_storage.getDownloadURL)(storageRef);
          await fs.unlink(filepath).catch(() => {
          });
          res.json({ url: cloudUrl });
        } catch (firebaseErr) {
          console.log("[Firebase Storage] Base64 upload skipped or failed. Storing locally instead.");
          res.json({ url: `/uploads/${artistId}/${filename}` });
        }
      }
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: "Failed to upload image" });
    }
  });
  app.post("/api/demos/:id/thumbnail", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const data = await loadData(req.artist?.username);
    const idx = data.demos.findIndex((d) => d.id === req.params.id || d.slug === req.params.id);
    if (idx >= 0) {
      data.demos[idx].ogImageUrl = req.body.ogImageUrl;
      await saveData(data);
      return res.json({ success: true });
    }
    res.status(404).json({ error: "Not found" });
  });
  function getRetryDelay(error) {
    try {
      const details = error?.details || error?.status?.details || error?.error?.details;
      if (Array.isArray(details)) {
        for (const detail of details) {
          if (detail?.retryDelay) {
            const match = detail.retryDelay.match(/^([0-9.]+)(s|ms)?$/);
            if (match) {
              const val = parseFloat(match[1]);
              const unit = match[2] || "s";
              return unit === "ms" ? val : val * 1e3;
            }
          }
        }
      }
    } catch (e) {
    }
    try {
      const errMsg = error?.message || error?.error?.message || "";
      const match = errMsg.match(/retry in ([0-9.]+)\s*s/i);
      if (match) {
        return parseFloat(match[1]) * 1e3;
      }
    } catch (e) {
    }
    return null;
  }
  async function generateContentWithRetry(ai, model, contents, config = {}, retries = 5, delay = 1500) {
    let attempt = 0;
    const modelsToTry = ["gemini-3.5-flash", "gemini-3.1-flash-lite"];
    while (attempt < retries) {
      const currentModel = attempt >= 1 ? modelsToTry[attempt % modelsToTry.length] : model;
      try {
        const response = await ai.models.generateContent({
          model: currentModel,
          contents,
          config
        });
        return response;
      } catch (error) {
        attempt++;
        console.warn(`Gemini API attempt ${attempt} failed with model ${currentModel}:`, error?.message || error);
        if (attempt >= retries) {
          throw error;
        }
        let waitTime = delay * Math.pow(2, attempt - 1);
        const detectedDelay = getRetryDelay(error);
        if (detectedDelay !== null) {
          waitTime = detectedDelay + 1500;
          console.log(`Detected 429 Rate Limit. Sleeping for ${waitTime}ms before retry...`);
        }
        await new Promise((resolve) => setTimeout(resolve, waitTime));
      }
    }
  }
  app.post("/api/translate", import_express.default.json(), async (req, res) => {
    const { text, targetLang } = req.body;
    if (!text) return res.json({ translated: "" });
    try {
      const ai = getGoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const targetLanguageName = targetLang === "en" ? "English" : targetLang === "ko" ? "Korean" : targetLang === "ja" ? "Japanese" : targetLang === "th" ? "Thai" : targetLang === "zh" ? "Chinese" : "Vietnamese";
      if (targetLanguageName === "Vietnamese") return res.json({ translated: text });
      const response = await generateContentWithRetry(
        ai,
        "gemini-2.5-flash",
        [
          {
            role: "user",
            parts: [{ text: `Translate the following short text (like a song title or bio) into ${targetLanguageName}. Only output the translation, do not include any quotes, extra words, or markdown. Text to translate:

${text}` }]
          }
        ]
      );
      const translated = response.text?.trim() || text;
      res.json({ translated });
    } catch (error) {
      console.log("Translation fallback (quota or network error):", error?.message);
      res.json({ translated: text });
    }
  });
  app.post("/api/admin/translate-all", import_express.default.json(), async (req, res) => {
    if (!isRequestAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    try {
      const data = await loadData(req.artist?.username);
      const stringsToTranslate = Array.from(new Set([
        data.pageTitle,
        data.artistBio,
        data.tab1Name,
        data.tab2Name,
        data.tab3Name,
        ...(data.demos || []).flatMap((d) => [d.title, d.lyrics, d.composer, d.singer, d.brandBrief, d.brandName]),
        ...(data.playlists || []).flatMap((p) => [p.name, p.description])
      ].filter((s) => s && typeof s === "string" && s.trim().length > 0).map((s) => s.trim())));
      if (stringsToTranslate.length === 0) {
        return res.json({ success: true, message: "Kh\xF4ng c\xF3 d\u1EEF li\u1EC7u n\xE0o c\u1EA7n d\u1ECBch.", data });
      }
      const stringToId = /* @__PURE__ */ new Map();
      const idToString = /* @__PURE__ */ new Map();
      let counter = 1;
      stringsToTranslate.forEach((str) => {
        const id = String(counter++);
        stringToId.set(str, id);
        idToString.set(id, str);
      });
      const geminiInput = {};
      stringToId.forEach((id, str) => {
        geminiInput[id] = str;
      });
      const targetLangs = ["en", "ko", "ja", "th", "zh"];
      const staticTranslations = data.staticTranslations || {};
      const ai = getGoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      await Promise.all(targetLangs.map(async (lang) => {
        const targetLanguageName = lang === "en" ? "English" : lang === "ko" ? "Korean" : lang === "ja" ? "Japanese" : lang === "th" ? "Thai" : "Chinese";
        try {
          const prompt = `Translate the following Vietnamese texts into ${targetLanguageName}.
These are music catalog fields like titles, bios, descriptions, and song lyrics.
The input is a JSON map where the keys are ID numbers and the values are the Vietnamese texts to translate.
Translate each value to ${targetLanguageName}, keeping the exact same ID key.
Maintain exact line breaks (\\n), formatting, and emojis for each translated string.
Return ONLY a valid JSON object of the translated map. Do not wrap in markdown \`\`\`json blocks.

Input:
${JSON.stringify(geminiInput, null, 2)}`;
          const response = await generateContentWithRetry(
            ai,
            "gemini-3.5-flash",
            prompt
          );
          const text = response.text?.trim() || "{}";
          let cleanText = text;
          if (cleanText.startsWith("```")) {
            cleanText = cleanText.replace(/^```json\s*/i, "").replace(/```$/, "").trim();
          }
          let translatedMap = {};
          try {
            translatedMap = JSON.parse(cleanText);
          } catch (jsonErr) {
            console.error(`Failed to parse translation for ${targetLanguageName}:`, cleanText);
          }
          staticTranslations[lang] = staticTranslations[lang] || {};
          Object.entries(translatedMap).forEach(([id, translatedVal]) => {
            const originalStr = idToString.get(id);
            if (originalStr && typeof translatedVal === "string") {
              staticTranslations[lang][originalStr] = translatedVal;
            }
          });
        } catch (langErr) {
          console.error(`Error translating to ${targetLanguageName}:`, langErr.message || langErr);
        }
      }));
      data.staticTranslations = staticTranslations;
      await saveData(data);
      res.json({ success: true, data });
    } catch (err) {
      console.error("Error in translate-all:", err);
      res.status(500).json({ error: err.message || "Internal Server Error" });
    }
  });
  app.post("/api/acp/artists/translate-all", import_express.default.json(), async (req, res) => {
    if (!isRequestMasterAdmin(req)) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const { username } = req.body;
    if (!username) {
      return res.status(400).json({ error: "Thi\u1EBFu username c\u1EE7a ngh\u1EC7 s\u0129!" });
    }
    try {
      const data = await loadData(username);
      const stringsToTranslate = Array.from(new Set([
        data.pageTitle,
        data.artistBio,
        data.tab1Name,
        data.tab2Name,
        data.tab3Name,
        ...(data.demos || []).flatMap((d) => [d.brandBrief, d.brandName]),
        ...(data.playlists || []).flatMap((p) => [p.name, p.title, p.description, p.desc])
      ].filter((s) => s && typeof s === "string" && s.trim().length > 0).map((s) => s.trim())));
      if (stringsToTranslate.length === 0) {
        return res.json({ success: true, message: "Kh\xF4ng c\xF3 d\u1EEF li\u1EC7u n\xE0o c\u1EA7n d\u1ECBch.", data });
      }
      const stringToId = /* @__PURE__ */ new Map();
      const idToString = /* @__PURE__ */ new Map();
      let counter = 1;
      stringsToTranslate.forEach((str) => {
        const id = String(counter++);
        stringToId.set(str, id);
        idToString.set(id, str);
      });
      const geminiInput = {};
      stringToId.forEach((id, str) => {
        geminiInput[id] = str;
      });
      const targetLangs = ["en", "ko", "ja", "th", "zh"];
      const staticTranslations = data.staticTranslations || {};
      const ai = getGoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      await Promise.all(targetLangs.map(async (lang) => {
        const targetLanguageName = lang === "en" ? "English" : lang === "ko" ? "Korean" : lang === "ja" ? "Japanese" : lang === "th" ? "Thai" : "Chinese";
        try {
          const prompt = `Translate the following Vietnamese texts into ${targetLanguageName}.
These are music catalog fields like titles, bios, and descriptions.
The input is a JSON map where the keys are ID numbers and the values are the Vietnamese texts to translate.
Translate each value to ${targetLanguageName}, keeping the exact same ID key.
Maintain exact line breaks (\\n), formatting, and emojis for each translated string.
Return ONLY a valid JSON object of the translated map. Do not wrap in markdown \`\`\`json blocks.

Input:
${JSON.stringify(geminiInput, null, 2)}`;
          const response = await generateContentWithRetry(
            ai,
            "gemini-3.5-flash",
            prompt
          );
          const text = response.text?.trim() || "{}";
          let cleanText = text;
          if (cleanText.startsWith("```")) {
            cleanText = cleanText.replace(/^```json\s*/i, "").replace(/```$/, "").trim();
          }
          let translatedMap = {};
          try {
            translatedMap = JSON.parse(cleanText);
          } catch (jsonErr) {
            console.error(`Failed to parse translation for ${targetLanguageName}:`, cleanText);
          }
          staticTranslations[lang] = staticTranslations[lang] || {};
          Object.entries(translatedMap).forEach(([id, translatedVal]) => {
            const originalStr = idToString.get(id);
            if (originalStr && typeof translatedVal === "string") {
              staticTranslations[lang][originalStr] = translatedVal;
            }
          });
        } catch (langErr) {
          console.error(`Error translating to ${targetLanguageName}:`, langErr.message || langErr);
        }
      }));
      data.staticTranslations = staticTranslations;
      await saveData(username, data);
      res.json({ success: true, data });
    } catch (err) {
      console.error("Error in translate-all:", err);
      res.status(500).json({ error: err.message || "Internal Server Error" });
    }
  });
  const uploadsPath = import_path.default.join(process.cwd(), "public", "uploads");
  app.use("/uploads", import_express.default.static(uploadsPath));
  app.use("/uploads", async (req, res, next) => {
    try {
      const data = await loadData(req.artist?.username);
      if (data.globalBaseUrl) {
        const base = data.globalBaseUrl.startsWith("http") ? data.globalBaseUrl : `https://${data.globalBaseUrl}`;
        const cleanBase = base.replace(/\/$/, "");
        return res.redirect(`${cleanBase}/uploads${req.path}`);
      }
    } catch (e) {
    }
    next();
  });
  let vite;
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = require("vite");
    vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "custom"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath, { index: false }));
  }
  app.get("/demo/:id", (req, res) => {
    const query = req.url.includes("?") ? req.url.substring(req.url.indexOf("?")) : "";
    res.redirect(301, `/song/${req.params.id}${query}`);
  });
  app.get("*", async (req, res, next) => {
    if (req.path.startsWith("/api/")) {
      return res.status(404).json({ error: "API route not found" });
    }
    try {
      const url = req.originalUrl;
      const data = await loadData(req.artist?.username);
      let html = "";
      if (process.env.NODE_ENV !== "production") {
        html = await fs.readFile(import_path.default.join(process.cwd(), "index.html"), "utf-8");
        html = await vite.transformIndexHtml(url, html);
      } else {
        html = await fs.readFile(import_path.default.join(process.cwd(), "dist", "index.html"), "utf-8");
      }
      const host = req.get("x-forwarded-host") || req.get("host") || "";
      const cleanHost = host.replace(/^www\./, "").toLowerCase().trim();
      const parts = cleanHost.split(".");
      const isSubdomain = parts.length >= 3 && artists.some((a) => {
        const sub = parts[0];
        if (a.extension === sub || a.username === sub) return true;
        if (a.extraUsernames) {
          const extras = a.extraUsernames.split(",").map((u) => u.trim().toLowerCase()).filter(Boolean);
          if (extras.includes(sub)) return true;
        }
        return false;
      });
      const isCustomDomain = artists.some((a) => {
        const cd = a.customDomain || "";
        const ew = a.externalWebsiteUrl || "";
        return cd && domainsMatch(cd, host) || ew && domainsMatch(ew, host);
      });
      const cleanPath = url.split("?")[0];
      const segments = cleanPath.split("/").filter(Boolean);
      const firstSegment = segments[0];
      const reserved = ["admin", "acp", "master", "mem", "demo", "song", "playlist", "api", "uploads", "help"];
      const hasArtistPath = firstSegment && !reserved.includes(firstSegment) && artists.some((a) => a.extension === firstSegment || a.username === firstSegment);
      const isMainLandingPage = !isSubdomain && !isCustomDomain && !hasArtistPath;
      let ogTitle = "";
      let ogDesc = "";
      let ogImage = "";
      let faviconUrlToInject = "";
      if (isMainLandingPage) {
        ogTitle = landingConfig.pageTitle || landingConfig.heroTitle || "Chorus";
        ogDesc = landingConfig.heroSubtitle || landingConfig.heroDescription || "CHORUS.VN \xA9 2026 - N\u01A1i nh\u1EEFng ca kh\xFAc b\u1EAFt \u0111\u1EA7u.";
        ogImage = landingConfig.ogImageUrl || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80";
        faviconUrlToInject = landingConfig.faviconUrl || "";
      } else {
        const defaultDesc = data.pageTitle || `Kho nh\u1EA1c c\u1EE7a ${data.artistName || "Ngh\u1EC7 s\u0129"}`;
        ogTitle = data.pageTitle || `Thi\xEAn \u0111\u01B0\u1EDDng \xE2m nh\u1EA1c c\u1EE7a ${data.artistName || "Ngh\u1EC7 s\u0129"}`;
        const initialOgImage = data.ogImageUrl || data.homeCoverUrl || (data.slideshowImages && data.slideshowImages.length > 0 ? data.slideshowImages[0] : "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80");
        ogImage = formatUrl(initialOgImage, data.globalBaseUrl) || "";
        const isHomepage = cleanPath === "/" || cleanPath === "/index.html" || cleanPath === "";
        ogDesc = isHomepage ? `N\u01A1i c\u1EADp nh\u1EADt s\u1EA3n ph\u1EA9m v\xE0 demo c\u1EE7a ${data.artistName || "Ngh\u1EC7 s\u0129"}` : defaultDesc;
        faviconUrlToInject = data.faviconUrl || "";
        let querySongSlug = req.query.song || req.query.demo || "";
        let activeSong = null;
        if (querySongSlug) {
          const decodedSlug = decodeURIComponent(querySongSlug).trim().toLowerCase();
          activeSong = data.demos.find((d) => {
            const fid = String(d.id || "").toLowerCase();
            const fslug = String(d.slug || "").toLowerCase();
            return (fid === decodedSlug || fslug === decodedSlug) && !d.deleted;
          });
        }
        if (!activeSong) {
          const songPathMatch = cleanPath.match(/^\/(?:demo|song)\/([^\/?]+)/i);
          if (songPathMatch) {
            const slug = decodeURIComponent(songPathMatch[1]).trim().toLowerCase();
            activeSong = data.demos.find((d) => {
              const fid = String(d.id || "").toLowerCase();
              const fslug = String(d.slug || "").toLowerCase();
              return (fid === slug || fslug === slug) && !d.deleted;
            });
          }
        }
        if (activeSong) {
          const titleSuffix = activeSong.singer || activeSong.author || activeSong.composer || data.artistName || "Ngh\u1EC7 s\u0129";
          ogTitle = activeSong.isReleased ? `${activeSong.title} - ${titleSuffix}` : `${activeSong.title} - ${titleSuffix} ( demo )`;
          let coverToUse = activeSong.coverUrl || activeSong.ogImageUrl;
          if (!coverToUse) {
            if (data.aboutMe?.avatarUrl) coverToUse = data.aboutMe.avatarUrl;
            else if (data.homeCoverUrl) coverToUse = data.homeCoverUrl;
          }
          if (!coverToUse && data.slideshowImages && data.slideshowImages.length > 0) {
            const idStr = String(activeSong.id || "");
            let hash = 0;
            for (let i = 0; i < idStr.length; i++) {
              hash += idStr.charCodeAt(i);
            }
            coverToUse = data.slideshowImages[hash % data.slideshowImages.length];
          }
          if (!coverToUse) {
            coverToUse = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80";
          }
          ogImage = formatUrl(coverToUse, data.globalBaseUrl) || "";
          ogDesc = defaultDesc;
        }
        const playlistMatch = cleanPath.match(/^\/playlist\/([^\/?]+)/i);
        if (playlistMatch && !activeSong) {
          const playlistId = decodeURIComponent(playlistMatch[1]).trim().toLowerCase();
          if (data.playlists) {
            const playlist = data.playlists.find((p) => String(p.id || "").toLowerCase() === playlistId && !p.deleted);
            if (playlist) {
              ogTitle = `${playlist.title} - ${data.artistName || "Ngh\u1EC7 s\u0129"}`;
              let pCover = playlist.coverUrl;
              if (!pCover) {
                const pSongs = data.demos.filter((d) => !d.deleted && d.status === "public" && d.playlistIds && d.playlistIds.includes(playlist.id));
                if (playlist.songIds && playlist.songIds.length > 0) {
                  pSongs.sort((a, b) => {
                    const indexA = playlist.songIds.indexOf(a.id);
                    const indexB = playlist.songIds.indexOf(b.id);
                    if (indexA === -1 && indexB === -1) return 0;
                    if (indexA === -1) return 1;
                    if (indexB === -1) return -1;
                    return indexA - indexB;
                  });
                }
                if (pSongs.length > 0) {
                  let firstSong = pSongs[0];
                  let firstSongCover = firstSong.coverUrl;
                  if (!firstSongCover && data.slideshowImages && data.slideshowImages.length > 0) {
                    const idStr = String(firstSong.id || "");
                    const hash = Array.from(idStr).reduce((sum, char) => sum + char.charCodeAt(0), 0);
                    firstSongCover = data.slideshowImages[hash % data.slideshowImages.length];
                  }
                  pCover = firstSongCover;
                }
              }
              if (!pCover) {
                pCover = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=500&q=80";
              }
              ogImage = formatUrl(pCover, data.globalBaseUrl) || "";
              ogDesc = defaultDesc;
            }
          }
        }
      }
      if (ogImage && ogImage.startsWith("/")) {
        ogImage = `https://${host}${ogImage}`;
      } else if (ogImage && !ogImage.startsWith("http")) {
        ogImage = `https://${host}${ogImage.startsWith("/") ? "" : "/"}${ogImage}`;
      }
      if (ogImage) {
        ogImage = ogImage.replace(/tài\.com/gi, "xn--ti-jia.com");
        ogImage = ogImage.replace(/ta\u0300i\.com/gi, "xn--ti-jia.com");
        ogImage = ogImage.replace(/t%C3%A0i\.com/gi, "xn--ti-jia.com");
        ogImage = ogImage.replace(/t%c3%a0i\.com/gi, "xn--ti-jia.com");
        ogImage = ogImage.replace(/t\u0300?a\u0300?i\.com/gi, "xn--ti-jia.com");
      }
      let ogUrl = `https://${host}${url}`;
      if (ogUrl) {
        ogUrl = ogUrl.replace(/tài\.com/gi, "xn--ti-jia.com");
        ogUrl = ogUrl.replace(/ta\u0300i\.com/gi, "xn--ti-jia.com");
        ogUrl = ogUrl.replace(/t%C3%A0i\.com/gi, "xn--ti-jia.com");
        ogUrl = ogUrl.replace(/t%c3%a0i\.com/gi, "xn--ti-jia.com");
        ogUrl = ogUrl.replace(/t\u0300?a\u0300?i\.com/gi, "xn--ti-jia.com");
      }
      const escapeHtmlAttr = (str) => {
        if (!str) return "";
        return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      };
      const escapedTitle = escapeHtmlAttr(ogTitle);
      const escapedDesc = escapeHtmlAttr(ogDesc);
      const escapedImage = escapeHtmlAttr(ogImage);
      const escapedUrl = escapeHtmlAttr(ogUrl);
      html = html.replace(/<title>.*?<\/title>/i, `<title>${escapedTitle}</title>`);
      let metaTags = `
        <meta property="og:title" content="${escapedTitle}" />
        <meta property="og:description" content="${escapedDesc}" />
        <meta property="og:image" content="${escapedImage}" />
        <meta property="og:image:secure_url" content="${escapedImage}" />
        <meta property="og:url" content="${escapedUrl}" />
        <meta property="og:site_name" content="t\xE0i.com" />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="${escapedTitle}" />
        <meta name="twitter:description" content="${escapedDesc}" />
        <meta name="twitter:image" content="${escapedImage}" />
      `;
      if (faviconUrlToInject) {
        metaTags += `
        <link rel="icon" href="${escapeHtmlAttr(faviconUrlToInject)}" />`;
      }
      let injectedScripts = "";
      const activeArtist = req.artist;
      if (activeArtist && !isMainLandingPage) {
        injectedScripts += `
    <script>
      window.__ACTIVE_ARTIST_USERNAME__ = ${JSON.stringify(activeArtist.username)};
      window.__ACTIVE_ARTIST_EXTENSION__ = ${JSON.stringify(activeArtist.extension)};
    </script>`;
      }
      html = html.replace(/<\/head>/i, `${metaTags}${injectedScripts}</head>`);
      res.status(200).set({
        "Content-Type": "text/html",
        "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0",
        "Surrogate-Control": "no-store"
      }).end(html);
    } catch (e) {
      if (process.env.NODE_ENV !== "production" && vite) {
        vite.ssrFixStacktrace(e);
      }
      console.error(e);
      res.status(500).end(e.message);
    }
  });
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    syncAllDataToR2().catch((err) => console.error("Error in syncAllDataToR2:", err));
    createSqliteBackup().catch((err) => console.error("Error in initial SQLite backup:", err));
    (async () => {
      try {
        const fileData = JSON.parse(await fs.readFile(getArtistDataFile("acxuantai"), "utf-8"));
        fileData.layoutSections = ["title", "random_song", "about", "bio", "vault", "mv", "spotify"];
        fileData.menuItems = [
          { id: "m1", type: "home", title: "Trang Ch\u1EE7", isVisible: true },
          { id: "m2", type: "about", title: "V\u1EC1 T\xF4i", isVisible: true },
          { id: "m3", type: "bio", title: "Ti\u1EC3u S\u1EED", isVisible: true },
          { id: "m4", type: "demos", title: "Danh S\xE1ch B\xE0i H\xE1t", isVisible: true }
        ];
        await saveData("acxuantai", fileData);
        console.log("\u2705 [Auto-Sync] \u0110\xE3 c\u1EADp nh\u1EADt th\xE0nh c\xF4ng V\u1EC1 T\xF4i v\xE0 Ti\u1EC3u S\u1EED cho acxuantai v\xE0o Firestore & R2!");
      } catch (err) {
        console.error("\u274C Error syncing acxuantai profile:", err.message);
      }
    })();
    setInterval(() => {
      createSqliteBackup().catch((err) => console.error("Error in scheduled SQLite backup:", err));
    }, 24 * 60 * 60 * 1e3);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
